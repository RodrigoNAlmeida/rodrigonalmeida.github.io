/-
# The finite canonical pattern `(P_W, D_W)` attached to a tile set

Formalises §6 (Wang tiles, torus tilings) and §7 (the poset `P_W`, the selected domain
`D_W`, and Lemma 7.1) of the paper.
-/

import MedvedevUndecidability.Frames

set_option linter.unusedVariables false
set_option linter.unusedSectionVars false

universe u v

namespace MU

/-! ## Wang tiles and torus tilings -/

/-- A doubly periodic (torus) tiling by a tile set `T` with colour functions
`w, e, s, n`.  Instead of `ℤ_m × ℤ_ℓ` we use an `m`-, `ℓ`-periodic map on `ℕ × ℕ`,
which is the same thing and much lighter to reason with. -/
structure TorusTiling {T C : Type} (cw ce cs cn : T → C) where
  m : Nat
  l : Nat
  hm : 0 < m
  hl : 0 < l
  tile : Nat → Nat → T
  perH : ∀ a b, tile (a + m) b = tile a b
  perV : ∀ a b, tile a (b + l) = tile a b
  matchH : ∀ a b, ce (tile a b) = cw (tile (a + 1) b)
  matchV : ∀ a b, cn (tile a b) = cs (tile a (b + 1))

namespace TorusTiling

variable {T C : Type} {cw ce cs cn : T → C}

/-- Horizontal periodicity for arbitrary multiples of the period. -/
theorem perH_mul (τ : TorusTiling cw ce cs cn) (k a b : Nat) :
    τ.tile (a + k * τ.m) b = τ.tile a b := by
  induction k with
  | zero => simp
  | succ j ih =>
    have h : a + (j + 1) * τ.m = (a + j * τ.m) + τ.m := by
      rw [Nat.succ_mul]; omega
    rw [h, τ.perH, ih]

theorem perV_mul (τ : TorusTiling cw ce cs cn) (k a b : Nat) :
    τ.tile a (b + k * τ.l) = τ.tile a b := by
  induction k with
  | zero => simp
  | succ j ih =>
    have h : b + (j + 1) * τ.l = (b + j * τ.l) + τ.l := by
      rw [Nat.succ_mul]; omega
    rw [h, τ.perV, ih]

theorem tile_mod_H (τ : TorusTiling cw ce cs cn) (x b : Nat) :
    τ.tile x b = τ.tile (x % τ.m) b := by
  have h : x % τ.m + (x / τ.m) * τ.m = x := Nat.mod_add_div' x τ.m
  calc τ.tile x b = τ.tile (x % τ.m + (x / τ.m) * τ.m) b := by rw [h]
    _ = τ.tile (x % τ.m) b := τ.perH_mul _ _ _

theorem tile_mod_V (τ : TorusTiling cw ce cs cn) (a y : Nat) :
    τ.tile a y = τ.tile a (y % τ.l) := by
  have h : y % τ.l + (y / τ.l) * τ.l = y := Nat.mod_add_div' y τ.l
  calc τ.tile a y = τ.tile a (y % τ.l + (y / τ.l) * τ.l) := by rw [h]
    _ = τ.tile a (y % τ.l) := τ.perV_mul _ _ _

/-- The tiling depends on the first coordinate only through its residue mod `m`. -/
theorem congrH (τ : TorusTiling cw ce cs cn) {a a' : Nat} (h : a % τ.m = a' % τ.m) (b : Nat) :
    τ.tile a b = τ.tile a' b := by
  rw [τ.tile_mod_H a b, τ.tile_mod_H a' b, h]

theorem congrV (τ : TorusTiling cw ce cs cn) (a : Nat) {b b' : Nat} (h : b % τ.l = b' % τ.l) :
    τ.tile a b = τ.tile a b' := by
  rw [τ.tile_mod_V a b, τ.tile_mod_V a b', h]

/-- `τ` uses every tile of `T`. -/
def Surjective (τ : TorusTiling cw ce cs cn) : Prop := ∀ t : T, ∃ a b, τ.tile a b = t

end TorusTiling

/-- `PER`: the tile set has *some* finite torus tiling. -/
def HasTorusTiling {T C : Type} (cw ce cs cn : T → C) : Prop :=
  Nonempty (TorusTiling cw ce cs cn)

/-! ## The poset `P_W` -/

/-- The four *role points*: `H₀, H₁, V₀, V₁`. -/
inductive Role where
  | H : Bool → Role
  | V : Bool → Role

/-- Index for the three relation points in each direction.
`dflt` is `R₀₀` (resp. `S₀₀`); `out i` is the output of the direction leaving phase `i`,
so `out false = R₀₁` and `out true = R₁₀`. -/
inductive RelIdx where
  | dflt : RelIdx
  | out : Bool → RelIdx

/-- The points of `P_W`. -/
inductive Pt (T : Type) where
  /-- the root `r` -/
  | root : Pt T
  /-- a role point `X ∈ {H₀,H₁,V₀,V₁}` -/
  | rol : Role → Pt T
  /-- the shield `d_X` -/
  | shd : Role → Pt T
  /-- the guard `g_X` -/
  | grd : Role → Pt T
  /-- a horizontal relation point `R_ab` -/
  | Rel : RelIdx → Pt T
  /-- a vertical relation point `S_ab` -/
  | Sel : RelIdx → Pt T
  /-- a tile point `T_{ij,t}` -/
  | Tl : Bool → Bool → T → Pt T

namespace Pt

variable {T : Type}

/-- The order of `P_W`.  Reading off §7.1: `r < g_X < d_X < X`, the relation and tile
points are covers of the root whose covers are the two indicated roles, and there are no
other comparabilities. -/
def ple : Pt T → Pt T → Prop
  | root,     _ => True
  | rol X,    q => q = rol X
  | shd X,    q => q = shd X ∨ q = rol X
  | grd X,    q => q = grd X ∨ q = shd X ∨ q = rol X
  | Rel k,    q => q = Rel k ∨ q = rol (.H false) ∨ q = rol (.H true)
  | Sel k,    q => q = Sel k ∨ q = rol (.V false) ∨ q = rol (.V true)
  | Tl i j t, q => q = Tl i j t ∨ q = rol (.H i) ∨ q = rol (.V j)

instance instPoset : Poset (Pt T) where
  le := ple
  le_refl := by
    intro a
    cases a <;> simp [ple]
  le_trans := by
    intro a b c hab hbc
    cases a with
    | root => trivial
    | rol X => cases hab; exact hbc
    | shd X =>
      rcases hab with rfl | rfl
      · exact hbc
      · cases hbc; exact Or.inr rfl
    | grd X =>
      rcases hab with rfl | rfl | rfl
      · exact hbc
      · rcases hbc with rfl | rfl
        · exact Or.inr (Or.inl rfl)
        · exact Or.inr (Or.inr rfl)
      · cases hbc; exact Or.inr (Or.inr rfl)
    | Rel k =>
      rcases hab with rfl | rfl | rfl
      · exact hbc
      · cases hbc; exact Or.inr (Or.inl rfl)
      · cases hbc; exact Or.inr (Or.inr rfl)
    | Sel k =>
      rcases hab with rfl | rfl | rfl
      · exact hbc
      · cases hbc; exact Or.inr (Or.inl rfl)
      · cases hbc; exact Or.inr (Or.inr rfl)
    | Tl i j t =>
      rcases hab with rfl | rfl | rfl
      · exact hbc
      · cases hbc; exact Or.inr (Or.inl rfl)
      · cases hbc; exact Or.inr (Or.inr rfl)
  le_antisymm := by
    intro a b hab hba
    cases a <;> cases b <;> simp_all [ple]

theorem le_def {p q : Pt T} : p ≤ q ↔ ple p q := Iff.rfl

/-- The root is the least element. -/
theorem root_le (p : Pt T) : (root : Pt T) ≤ p := trivial

/-- Nothing but the root is below the root. -/
theorem le_root {p : Pt T} (h : p ≤ (root : Pt T)) : p = root := by
  cases p <;> simp_all [le_def, ple]

/-- Role points are maximal. -/
theorem rol_le {X : Role} {q : Pt T} (h : (rol X : Pt T) ≤ q) : q = rol X := h

/-- Every point lies below a role point. -/
theorem exists_rol_ge (p : Pt T) : ∃ X, p ≤ rol X := by
  cases p with
  | root => exact ⟨.H false, trivial⟩
  | rol X => exact ⟨X, Poset.le_refl _⟩
  | shd X => exact ⟨X, Or.inr rfl⟩
  | grd X => exact ⟨X, Or.inr (Or.inr rfl)⟩
  | Rel k => exact ⟨.H false, Or.inr (Or.inl rfl)⟩
  | Sel k => exact ⟨.V false, Or.inr (Or.inl rfl)⟩
  | Tl i j t => exact ⟨.H i, Or.inr (Or.inl rfl)⟩

/-- The maximal points of `P_W` are exactly the role points. -/
theorem maximal_iff {p : Pt T} : (∀ q, p ≤ q → q = p) ↔ ∃ X, p = rol X := by
  constructor
  · intro h
    obtain ⟨X, hX⟩ := exists_rol_ge p
    exact ⟨X, (h _ hX).symm⟩
  · intro ⟨X, hX⟩ q hq
    subst hX
    exact rol_le hq

/-- `p` is a cover of the root: nothing lies strictly between. -/
def IsRootCover (z : Pt T) : Prop := z ≠ root ∧ ∀ p, p ≤ z → p = root ∨ p = z

theorem rootCover_grd (X : Role) : IsRootCover (grd X : Pt T) := by
  refine ⟨by simp, ?_⟩
  intro p hp
  cases p <;> simp_all [le_def, ple]

theorem rootCover_Rel (k : RelIdx) : IsRootCover (Rel k : Pt T) := by
  refine ⟨by simp, ?_⟩
  intro p hp
  cases p <;> simp_all [le_def, ple]

theorem rootCover_Sel (k : RelIdx) : IsRootCover (Sel k : Pt T) := by
  refine ⟨by simp, ?_⟩
  intro p hp
  cases p <;> simp_all [le_def, ple]

theorem rootCover_Tl (i j : Bool) (t : T) : IsRootCover (Tl i j t : Pt T) := by
  refine ⟨by simp, ?_⟩
  intro p hp
  cases p <;> simp_all [le_def, ple]

/-- The only point strictly below the shield `d_X` other than the root is the guard `g_X`. -/
theorem le_shd {p : Pt T} {X : Role} (h : p ≤ shd X) : p = root ∨ p = grd X ∨ p = shd X := by
  cases p <;> simp_all [le_def, ple]

/-! ### Which roles lie above a point -/

/-- `rolesAbove p X` says the role point `X` lies above `p`; by `maximal_iff` these are
exactly the elements of `Max(↑p)`. -/
def rolesAbove (p : Pt T) (X : Role) : Prop := p ≤ rol X

@[simp] theorem rolesAbove_root (X : Role) : rolesAbove (root : Pt T) X := trivial
@[simp] theorem rolesAbove_rol (X Y : Role) : rolesAbove (rol X : Pt T) Y ↔ Y = X := by
  simp [rolesAbove, le_def, ple]
@[simp] theorem rolesAbove_shd (X Y : Role) : rolesAbove (shd X : Pt T) Y ↔ Y = X := by
  simp [rolesAbove, le_def, ple]
@[simp] theorem rolesAbove_grd (X Y : Role) : rolesAbove (grd X : Pt T) Y ↔ Y = X := by
  simp [rolesAbove, le_def, ple]
@[simp] theorem rolesAbove_Rel (k : RelIdx) (Y : Role) :
    rolesAbove (Rel k : Pt T) Y ↔ (Y = .H false ∨ Y = .H true) := by
  simp [rolesAbove, le_def, ple]
@[simp] theorem rolesAbove_Sel (k : RelIdx) (Y : Role) :
    rolesAbove (Sel k : Pt T) Y ↔ (Y = .V false ∨ Y = .V true) := by
  simp [rolesAbove, le_def, ple]
@[simp] theorem rolesAbove_Tl (i j : Bool) (t : T) (Y : Role) :
    rolesAbove (Tl i j t : Pt T) Y ↔ (Y = .H i ∨ Y = .V j) := by
  simp [rolesAbove, le_def, ple]

end Pt

/-! ## Finiteness of `P_W` -/

instance : FinE Role where
  elems := [.H false, .H true, .V false, .V true]
  complete := by intro X; cases X with
    | H b => cases b <;> simp
    | V b => cases b <;> simp

instance : FinE RelIdx where
  elems := [.dflt, .out false, .out true]
  complete := by intro k; cases k with
    | dflt => simp
    | out b => cases b <;> simp

instance instFinEPt {T : Type} [FinE T] : FinE (Pt T) where
  elems :=
    [Pt.root,
     Pt.rol (.H false), Pt.rol (.H true), Pt.rol (.V false), Pt.rol (.V true),
     Pt.shd (.H false), Pt.shd (.H true), Pt.shd (.V false), Pt.shd (.V true),
     Pt.grd (.H false), Pt.grd (.H true), Pt.grd (.V false), Pt.grd (.V true),
     Pt.Rel .dflt, Pt.Rel (.out false), Pt.Rel (.out true),
     Pt.Sel .dflt, Pt.Sel (.out false), Pt.Sel (.out true)]
    ++ (FinE.elems.map (Pt.Tl false false))
    ++ (FinE.elems.map (Pt.Tl false true))
    ++ (FinE.elems.map (Pt.Tl true false))
    ++ (FinE.elems.map (Pt.Tl true true))
  complete := by
    intro p
    cases p with
    | root => simp
    | rol X => cases X with | H b => cases b <;> simp | V b => cases b <;> simp
    | shd X => cases X with | H b => cases b <;> simp | V b => cases b <;> simp
    | grd X => cases X with | H b => cases b <;> simp | V b => cases b <;> simp
    | Rel k => cases k with | dflt => simp | out b => cases b <;> simp
    | Sel k => cases k with | dflt => simp | out b => cases b <;> simp
    | Tl i j t =>
      cases i <;> cases j <;>
        simp only [List.mem_append, List.mem_map] <;>
        first
        | exact Or.inl (Or.inl (Or.inl (Or.inr ⟨t, FinE.complete t, rfl⟩)))
        | exact Or.inl (Or.inl (Or.inr ⟨t, FinE.complete t, rfl⟩))
        | exact Or.inl (Or.inr ⟨t, FinE.complete t, rfl⟩)
        | exact Or.inr ⟨t, FinE.complete t, rfl⟩

end MU
