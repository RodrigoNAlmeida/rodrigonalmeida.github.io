/-
# Completeness: a torus tiling yields a partial morphism

Formalises §9 of the paper: the calibrated supports (S1)–(S7), Lemma 9.1 (calibration),
Lemma 9.2 (support realization), Lemma 9.3 (outside-point principle, proved in `Core`),
the global ZCDC verification of §9.2, and Proposition 9.4.
-/

import MedvedevUndecidability.Soundness

set_option linter.unusedVariables false
set_option linter.unusedSectionVars false

namespace MU

open Pt

/-! ## `Fin n` is finite -/

def finUpto : (n k : Nat) → k ≤ n → List (Fin n)
  | _, 0, _ => []
  | n, (k + 1), h =>
      (⟨k, Nat.lt_of_lt_of_le (Nat.lt_succ_self k) h⟩ : Fin n) :: finUpto n k (Nat.le_of_succ_le h)

theorem mem_finUpto : ∀ (n k : Nat) (h : k ≤ n) (a : Fin n), a.val < k → a ∈ finUpto n k h := by
  intro n k
  induction k with
  | zero => intro h a ha; omega
  | succ j ih =>
    intro h a ha
    by_cases hj : a.val < j
    · exact List.mem_cons.mpr (Or.inr (ih (Nat.le_of_succ_le h) a hj))
    · refine List.mem_cons.mpr (Or.inl (Fin.ext ?_))
      show a.val = j
      omega

instance instFinEFin (n : Nat) : FinE (Fin n) where
  elems := finUpto n n (Nat.le_refl n)
  complete := fun a => mem_finUpto n n (Nat.le_refl n) a a.isLt

/-! ## Cyclic successor on a block index -/

def zsucc {M : Nat} (hM : 0 < M) (a : Fin M) : Fin M := ⟨(a.val + 1) % M, Nat.mod_lt _ hM⟩

theorem zsucc_val {M : Nat} (hM : 0 < M) (a : Fin M) :
    (zsucc hM a).val = if a.val + 1 = M then 0 else a.val + 1 := by
  have ha := a.isLt
  show (a.val + 1) % M = _
  by_cases h : a.val + 1 = M
  · rw [if_pos h, h, Nat.mod_self]
  · rw [if_neg h]
    exact Nat.mod_eq_of_lt (by omega)

/-- The successor is congruent to `+1` modulo any divisor of the block length. -/
theorem zsucc_mod {M : Nat} (hM : 0 < M) (m : Nat) (hm : 0 < m) (hdvd : ∃ c, M = m * c)
    (a : Fin M) : (zsucc hM a).val % m = (a.val + 1) % m := by
  obtain ⟨c, hc⟩ := hdvd
  have ha := a.isLt
  rw [zsucc_val]
  by_cases h : a.val + 1 = M
  · rw [if_pos h, h, hc]
    have : m * c % m = 0 := by
      rw [Nat.mul_comm]
      exact Nat.mul_mod_left c m
    rw [this]
    exact (Nat.zero_mod m).symm
  · rw [if_neg h]

theorem zsucc_ne {M : Nat} (hM : 0 < M) (h2 : 2 ≤ M) (a : Fin M) : zsucc hM a ≠ a := by
  intro he
  have ha := a.isLt
  have hv : (zsucc hM a).val = a.val := congrArg Fin.val he
  rw [zsucc_val] at hv
  by_cases h : a.val + 1 = M
  · rw [if_pos h] at hv; omega
  · rw [if_neg h] at hv; omega

theorem zsucc_not_double {M : Nat} (hM : 0 < M) (h3 : 3 ≤ M) {a b : Fin M}
    (hab : b = zsucc hM a) (hba : a = zsucc hM b) : False := by
  have ha := a.isLt
  have hb := b.isLt
  have h1 : b.val = (zsucc hM a).val := congrArg Fin.val hab
  have h2 : a.val = (zsucc hM b).val := congrArg Fin.val hba
  rw [zsucc_val] at h1 h2
  by_cases e1 : a.val + 1 = M
  · rw [if_pos e1] at h1
    by_cases e2 : b.val + 1 = M
    · rw [if_pos e2] at h2; omega
    · rw [if_neg e2] at h2; omega
  · rw [if_neg e1] at h1
    by_cases e2 : b.val + 1 = M
    · rw [if_pos e2] at h2; omega
    · rw [if_neg e2] at h2; omega

/-! ## The carrier `Ω = H₀ ⊔ H₁ ⊔ V₀ ⊔ V₁` -/

inductive Om (M L : Nat) where
  | h : Bool → Fin M → Om M L
  | v : Bool → Fin L → Om M L

instance instFinEOm (M L : Nat) : FinE (Om M L) where
  elems :=
    ((FinE.elems : List (Fin M)).map (Om.h false) ++ (FinE.elems : List (Fin M)).map (Om.h true))
    ++ ((FinE.elems : List (Fin L)).map (Om.v false) ++ (FinE.elems : List (Fin L)).map (Om.v true))
  complete := by
    intro z
    refine List.mem_append.mpr ?_
    cases z with
    | h i p =>
      refine Or.inl (List.mem_append.mpr ?_)
      cases i
      · exact Or.inl (List.mem_map.mpr ⟨p, FinE.complete p, rfl⟩)
      · exact Or.inr (List.mem_map.mpr ⟨p, FinE.complete p, rfl⟩)
    | v j q =>
      refine Or.inr (List.mem_append.mpr ?_)
      cases j
      · exact Or.inl (List.mem_map.mpr ⟨q, FinE.complete q, rfl⟩)
      · exact Or.inr (List.mem_map.mpr ⟨q, FinE.complete q, rfl⟩)

section Blocks

variable {M L : Nat} (hM : 0 < M) (hL : 0 < L)

/-- The whole horizontal block `H_i`, as a face. -/
def blockH (i : Bool) : Face (Om M L) :=
  ⟨fun z => ∃ a, z = Om.h i a, ⟨Om.h i ⟨0, hM⟩, ⟨⟨0, hM⟩, rfl⟩⟩⟩

/-- The whole vertical block `V_j`, as a face. -/
def blockV (j : Bool) : Face (Om M L) :=
  ⟨fun z => ∃ b, z = Om.v j b, ⟨Om.v j ⟨0, hL⟩, ⟨⟨0, hL⟩, rfl⟩⟩⟩

/-- The whole of `Ω`, as a face (support (S7) of the root). -/
def omegaF : Face (Om M L) := ⟨fun _ => True, ⟨Om.h false ⟨0, hM⟩, trivial⟩⟩

@[simp] theorem blockH_carrier (i : Bool) (z : Om M L) :
    (blockH hM i).carrier z ↔ ∃ a, z = Om.h i a := Iff.rfl

@[simp] theorem blockV_carrier (j : Bool) (z : Om M L) :
    (blockV (M := M) hL j).carrier z ↔ ∃ b, z = Om.v j b := Iff.rfl

@[simp] theorem omegaF_carrier (z : Om M L) : (omegaF (L := L) hM).carrier z := trivial

end Blocks

/-! ## The calibrated support families (S1)–(S7) -/

section Supports

variable {T C : Type} {cw ce cs cn : T → C}

/-- The support families `Σ_p ⊆ P*(Ω)` of §9.1. -/
inductive Sg {M L : Nat} (hM : 0 < M) (hL : 0 < L) (τ : TorusTiling cw ce cs cn) :
    Pt T → Face (Om M L) → Prop where
  /-- (S7) -/
  | root : Sg hM hL τ Pt.root (omegaF hM)
  /-- (S1), horizontal -/
  | rolH (i : Bool) (a : Fin M) : Sg hM hL τ (Pt.rol (.H i)) (Face.pt (Om.h i a))
  /-- (S1), vertical -/
  | rolV (j : Bool) (b : Fin L) : Sg hM hL τ (Pt.rol (.V j)) (Face.pt (Om.v j b))
  /-- (S2), horizontal -/
  | shdH (i : Bool) (a a' : Fin M) (h : a ≠ a') :
      Sg hM hL τ (Pt.shd (.H i)) (Face.pr (Om.h i a) (Om.h i a'))
  /-- (S2), vertical -/
  | shdV (j : Bool) (b b' : Fin L) (h : b ≠ b') :
      Sg hM hL τ (Pt.shd (.V j)) (Face.pr (Om.v j b) (Om.v j b'))
  /-- (S3), horizontal -/
  | grdH (i : Bool) : Sg hM hL τ (Pt.grd (.H i)) (blockH hM i)
  /-- (S3), vertical -/
  | grdV (j : Bool) : Sg hM hL τ (Pt.grd (.V j)) (blockV hL j)
  /-- (S4), the two successor matchings -/
  | relOut (i : Bool) (a : Fin M) :
      Sg hM hL τ (Pt.Rel (.out i)) (Face.pr (Om.h i a) (Om.h (!i) (zsucc hM a)))
  /-- (S4), the default `R₀₀`-pairs -/
  | relDflt (a b : Fin M) (h1 : ¬ (b = zsucc hM a)) (h2 : ¬ (a = zsucc hM b)) :
      Sg hM hL τ (Pt.Rel .dflt) (Face.pr (Om.h false a) (Om.h true b))
  /-- (S5), the two successor matchings -/
  | selOut (j : Bool) (b : Fin L) :
      Sg hM hL τ (Pt.Sel (.out j)) (Face.pr (Om.v j b) (Om.v (!j) (zsucc hL b)))
  /-- (S5), the default `S₀₀`-pairs -/
  | selDflt (a b : Fin L) (h1 : ¬ (b = zsucc hL a)) (h2 : ¬ (a = zsucc hL b)) :
      Sg hM hL τ (Pt.Sel .dflt) (Face.pr (Om.v false a) (Om.v true b))
  /-- (S6), the cell supports -/
  | tile (i j : Bool) (a : Fin M) (b : Fin L) :
      Sg hM hL τ (Pt.Tl i j (τ.tile a.val b.val)) (Face.pr (Om.h i a) (Om.v j b))

/-- `Act(S) = {p : some support of p is contained in S}`. -/
def Act {M L : Nat} (hM : 0 < M) (hL : 0 < L) (τ : TorusTiling cw ce cs cn)
    (S : Face (Om M L)) : Set (Pt T) := fun p => ∃ K, Sg hM hL τ p K ∧ S ≤ K

theorem Act_mono {M L : Nat} {hM : 0 < M} {hL : 0 < L} {τ : TorusTiling cw ce cs cn}
    {S S' : Face (Om M L)} (h : S ≤ S') : Act hM hL τ S' ⊆ᵈ Act (T := T) hM hL τ S := by
  rintro p ⟨K, hK, hSK⟩
  exact ⟨K, hK, Poset.le_trans h hSK⟩

end Supports

/-! ## Elementary face identities -/

section FaceLemmas

variable {Ω : Type}

theorem eq_pt_elim {w : Ω} {H : Face Ω} (h : H = Face.pt w) (z : Ω) (hz : H.carrier z) :
    z = w := by
  rw [h] at hz; exact hz

theorem eq_pr_elim {u u' : Ω} {H : Face Ω} (h : H = Face.pr u u') (z : Ω) (hz : H.carrier z) :
    z = u ∨ z = u' := by
  rw [h] at hz; exact hz

theorem pr_mem_left (u u' : Ω) : (Face.pr u u').carrier u := Or.inl rfl
theorem pr_mem_right (u u' : Ω) : (Face.pr u u').carrier u' := Or.inr rfl
theorem pt_mem (w : Ω) : (Face.pt w).carrier w := rfl

theorem le_pr {S : Face Ω} {u u' : Ω} (hu : S.carrier u) (hu' : S.carrier u') :
    S ≤ Face.pr u u' := by
  intro z hz
  rcases hz with rfl | rfl
  · exact hu
  · exact hu'

end FaceLemmas


/-! ## Lemma 9.2: support realization -/

section Realization

variable {Om' : Type} {P : Type} [Poset P] [FinE P]

/-- `Act(S)` for an abstract support family. -/
def ActG (Sg' : P → Face Om' → Prop) (S : Face Om') : Set P :=
  fun q => ∃ K, Sg' q K ∧ S ≤ K

theorem ActG_mono {Sg' : P → Face Om' → Prop} {S S' : Face Om'} (h : S ≤ S') :
    ActG Sg' S' ⊆ᵈ ActG Sg' S := by
  rintro p ⟨K, hK, hSK⟩
  exact ⟨K, hK, Poset.le_trans h hSK⟩

/-- **Lemma 9.2** (Support realization).  A calibrated family of supports realizes an onto
partial Esakia morphism whose cone images are exactly the activation sets. -/
theorem support_realization (Sg' : P → Face Om' → Prop)
    (hne : ∀ p, ∃ H, Sg' p H)
    (hcal : ∀ p H, Sg' p H → ActG Sg' H = up p) :
    ∃ f : Face Om' → Option P,
      IsPEM f ∧ POnto f ∧ (∀ S, coneImg f S = ActG Sg' S) ∧
      (∀ S p, f S = some p ↔ ActG Sg' S = up p) := by
  have hfex : ∀ S : Face Om', ∃ o : Option P, ∀ p, o = some p ↔ ActG Sg' S = up p := by
    intro S
    by_cases h : ∃ p, ActG Sg' S = up p
    · obtain ⟨p, hp⟩ := h
      refine ⟨some p, fun q => ⟨fun hq => ?_, fun hq => ?_⟩⟩
      · have hpq : p = q := Option.some.inj hq
        rw [← hpq]; exact hp
      · have huq : (up p : Set P) = up q := hp.symm.trans hq
        rw [up_inj huq]
    · exact ⟨none, fun p => ⟨fun h' => absurd h' (by simp), fun h' => absurd ⟨p, h'⟩ h⟩⟩
  obtain ⟨f, hf⟩ : ∃ f : Face Om' → Option P, ∀ S p, f S = some p ↔ ActG Sg' S = up p :=
    ⟨fun S => Classical.choose (hfex S), fun S => Classical.choose_spec (hfex S)⟩
  have hcone : ∀ S, coneImg f S = ActG Sg' S := by
    intro S
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨Tf, hST, hfT⟩
      have hT : ActG Sg' Tf = up q := (hf Tf q).mp hfT
      have hq : ActG Sg' Tf q := by rw [hT]; exact Poset.le_refl q
      exact ActG_mono hST q hq
    · rintro ⟨K, hK, hSK⟩
      exact ⟨K, hSK, (hf K q).mpr (hcal q K hK)⟩
  refine ⟨f, ⟨?_, ?_, ?_⟩, ?_, hcone, hf⟩
  · -- (PE1)
    intro x z p q hxz hx hz
    have h1 : ActG Sg' z = up q := (hf z q).mp hz
    have h2 : ActG Sg' x = up p := (hf x p).mp hx
    have hqz : ActG Sg' z q := by rw [h1]; exact Poset.le_refl q
    have hqx : ActG Sg' x q := ActG_mono hxz q hqz
    rw [h2] at hqx
    exact hqx
  · -- (PE2)
    intro x p q hx hpq
    have h2 : ActG Sg' x = up p := (hf x p).mp hx
    have hq : ActG Sg' x q := by rw [h2]; exact hpq
    rw [← hcone] at hq
    exact hq
  · -- (PE3)
    intro x
    constructor
    · rintro ⟨p, hp⟩
      exact ⟨p, by rw [hcone]; exact (hf x p).mp hp⟩
    · rintro ⟨y, hy⟩
      rw [hcone] at hy
      exact ⟨y, (hf x y).mpr hy⟩
  · -- onto
    intro p
    obtain ⟨H, hH⟩ := hne p
    exact ⟨H, (hf H p).mpr (hcal p H hH)⟩

end Realization


/-! ## Which points a given face supports

Every support is a singleton, a two-element face, a whole block, or `Ω`.  The lemmas below
identify, for each of these shapes, exactly which points it can support.  This is the
combinatorial content behind the calibration lemma.
-/

section Classify

variable {T C : Type} {cw ce cs cn : T → C} {M L : Nat}
  {hM : 0 < M} {hL : 0 < L} {τ : TorusTiling cw ce cs cn}

theorem three_not_two {α : Type} {z0 z1 z2 u u' : α} (h0 : z0 = u ∨ z0 = u')
    (h1 : z1 = u ∨ z1 = u') (h2 : z2 = u ∨ z2 = u') : z0 = z1 ∨ z0 = z2 ∨ z1 = z2 := by
  rcases h0 with h0 | h0 <;> rcases h1 with h1 | h1 <;> rcases h2 with h2 | h2
  · exact Or.inl (h0.trans h1.symm)
  · exact Or.inl (h0.trans h1.symm)
  · exact Or.inr (Or.inl (h0.trans h2.symm))
  · exact Or.inr (Or.inr (h1.trans h2.symm))
  · exact Or.inr (Or.inr (h1.trans h2.symm))
  · exact Or.inr (Or.inl (h0.trans h2.symm))
  · exact Or.inl (h0.trans h1.symm)
  · exact Or.inl (h0.trans h1.symm)

/-- The role of a coordinate. -/
def roleOfOm {M L : Nat} : Om M L → Role
  | Om.h i _ => .H i
  | Om.v j _ => .V j

/-- Only a role point has a singleton support. -/
theorem Sg_singleton {q : Pt T} {K : Face (Om M L)} {w : Om M L} (hM3 : 3 ≤ M) (hL3 : 3 ≤ L)
    (h : Sg hM hL τ q K) (hall : ∀ z, K.carrier z → z = w) : q = Pt.rol (roleOfOm w) := by
  cases h with
  | root =>
    have e1 := hall (Om.h false ⟨0, hM⟩) trivial
    have e2 := hall (Om.v false ⟨0, hL⟩) trivial
    exact absurd (e1.trans e2.symm) (by simp)
  | rolH i a => rw [← hall (Om.h i a) rfl]; rfl
  | rolV j b => rw [← hall (Om.v j b) rfl]; rfl
  | shdH i a a' haa =>
    have e1 := hall (Om.h i a) (Or.inl rfl)
    have e2 := hall (Om.h i a') (Or.inr rfl)
    exact absurd (Om.h.inj (e1.trans e2.symm)).2 haa
  | shdV j b b' hbb =>
    have e1 := hall (Om.v j b) (Or.inl rfl)
    have e2 := hall (Om.v j b') (Or.inr rfl)
    exact absurd (Om.v.inj (e1.trans e2.symm)).2 hbb
  | grdH i =>
    have e1 := hall (Om.h i ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    have e2 := hall (Om.h i ⟨1, by omega⟩) ⟨⟨1, by omega⟩, rfl⟩
    have hv : (0 : Nat) = 1 := congrArg Fin.val (Om.h.inj (e1.trans e2.symm)).2
    exact absurd hv (by omega)
  | grdV j =>
    have e1 := hall (Om.v j ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    have e2 := hall (Om.v j ⟨1, by omega⟩) ⟨⟨1, by omega⟩, rfl⟩
    have hv : (0 : Nat) = 1 := congrArg Fin.val (Om.v.inj (e1.trans e2.symm)).2
    exact absurd hv (by omega)
  | relOut i a =>
    have e1 := hall (Om.h i a) (Or.inl rfl)
    have e2 := hall (Om.h (!i) (zsucc hM a)) (Or.inr rfl)
    exact absurd ((Om.h.inj (e1.trans e2.symm)).1).symm (bool_not_ne i)
  | relDflt a b h1 h2 =>
    have e1 := hall (Om.h false a) (Or.inl rfl)
    have e2 := hall (Om.h true b) (Or.inr rfl)
    exact absurd (Om.h.inj (e1.trans e2.symm)).1 (by simp)
  | selOut j b =>
    have e1 := hall (Om.v j b) (Or.inl rfl)
    have e2 := hall (Om.v (!j) (zsucc hL b)) (Or.inr rfl)
    exact absurd ((Om.v.inj (e1.trans e2.symm)).1).symm (bool_not_ne j)
  | selDflt a b h1 h2 =>
    have e1 := hall (Om.v false a) (Or.inl rfl)
    have e2 := hall (Om.v true b) (Or.inr rfl)
    exact absurd (Om.v.inj (e1.trans e2.symm)).1 (by simp)
  | tile i j a b =>
    have e1 := hall (Om.h i a) (Or.inl rfl)
    have e2 := hall (Om.v j b) (Or.inr rfl)
    exact absurd (e1.trans e2.symm) (by simp)

/-- A support contained in a horizontal block can only be a role, shield or guard support
of that block. -/
theorem Sg_in_blockH {q : Pt T} {K : Face (Om M L)} {i : Bool} (hM3 : 3 ≤ M) (hL3 : 3 ≤ L)
    (h : Sg hM hL τ q K) (hsub : ∀ z, K.carrier z → ∃ a, z = Om.h i a) :
    q = Pt.rol (.H i) ∨ q = Pt.shd (.H i) ∨ q = Pt.grd (.H i) := by
  cases h with
  | root => obtain ⟨a, ha⟩ := hsub (Om.v false ⟨0, hL⟩) trivial; exact absurd ha (by simp)
  | rolH i' a =>
    obtain ⟨c, hc⟩ := hsub (Om.h i' a) rfl
    rw [(Om.h.inj hc).1]; exact Or.inl rfl
  | rolV j b => obtain ⟨c, hc⟩ := hsub (Om.v j b) rfl; exact absurd hc (by simp)
  | shdH i' a a' haa =>
    obtain ⟨c, hc⟩ := hsub (Om.h i' a) (Or.inl rfl)
    rw [(Om.h.inj hc).1]; exact Or.inr (Or.inl rfl)
  | shdV j b b' hbb => obtain ⟨c, hc⟩ := hsub (Om.v j b) (Or.inl rfl); exact absurd hc (by simp)
  | grdH i' =>
    obtain ⟨c, hc⟩ := hsub (Om.h i' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    rw [(Om.h.inj hc).1]; exact Or.inr (Or.inr rfl)
  | grdV j =>
    obtain ⟨c, hc⟩ := hsub (Om.v j ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    exact absurd hc (by simp)
  | relOut i' a =>
    obtain ⟨c, hc⟩ := hsub (Om.h i' a) (Or.inl rfl)
    obtain ⟨d, hd⟩ := hsub (Om.h (!i') (zsucc hM a)) (Or.inr rfl)
    exact absurd (((Om.h.inj hd).1).trans ((Om.h.inj hc).1).symm) (bool_not_ne i')
  | relDflt a b h1 h2 =>
    obtain ⟨c, hc⟩ := hsub (Om.h false a) (Or.inl rfl)
    obtain ⟨d, hd⟩ := hsub (Om.h true b) (Or.inr rfl)
    exact absurd (((Om.h.inj hc).1).trans ((Om.h.inj hd).1).symm) (by simp)
  | selOut j b => obtain ⟨c, hc⟩ := hsub (Om.v j b) (Or.inl rfl); exact absurd hc (by simp)
  | selDflt a b h1 h2 =>
    obtain ⟨c, hc⟩ := hsub (Om.v false a) (Or.inl rfl); exact absurd hc (by simp)
  | tile i' j a b => obtain ⟨c, hc⟩ := hsub (Om.v j b) (Or.inr rfl); exact absurd hc (by simp)

theorem Sg_in_blockV {q : Pt T} {K : Face (Om M L)} {j : Bool} (hM3 : 3 ≤ M) (hL3 : 3 ≤ L)
    (h : Sg hM hL τ q K) (hsub : ∀ z, K.carrier z → ∃ b, z = Om.v j b) :
    q = Pt.rol (.V j) ∨ q = Pt.shd (.V j) ∨ q = Pt.grd (.V j) := by
  cases h with
  | root => obtain ⟨a, ha⟩ := hsub (Om.h false ⟨0, hM⟩) trivial; exact absurd ha (by simp)
  | rolH i a => obtain ⟨c, hc⟩ := hsub (Om.h i a) rfl; exact absurd hc (by simp)
  | rolV j' b =>
    obtain ⟨c, hc⟩ := hsub (Om.v j' b) rfl
    rw [(Om.v.inj hc).1]; exact Or.inl rfl
  | shdH i a a' haa => obtain ⟨c, hc⟩ := hsub (Om.h i a) (Or.inl rfl); exact absurd hc (by simp)
  | shdV j' b b' hbb =>
    obtain ⟨c, hc⟩ := hsub (Om.v j' b) (Or.inl rfl)
    rw [(Om.v.inj hc).1]; exact Or.inr (Or.inl rfl)
  | grdH i =>
    obtain ⟨c, hc⟩ := hsub (Om.h i ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    exact absurd hc (by simp)
  | grdV j' =>
    obtain ⟨c, hc⟩ := hsub (Om.v j' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    rw [(Om.v.inj hc).1]; exact Or.inr (Or.inr rfl)
  | relOut i a => obtain ⟨c, hc⟩ := hsub (Om.h i a) (Or.inl rfl); exact absurd hc (by simp)
  | relDflt a b h1 h2 =>
    obtain ⟨c, hc⟩ := hsub (Om.h false a) (Or.inl rfl); exact absurd hc (by simp)
  | selOut j' b =>
    obtain ⟨c, hc⟩ := hsub (Om.v j' b) (Or.inl rfl)
    obtain ⟨d, hd⟩ := hsub (Om.v (!j') (zsucc hL b)) (Or.inr rfl)
    exact absurd (((Om.v.inj hd).1).trans ((Om.v.inj hc).1).symm) (bool_not_ne j')
  | selDflt a b h1 h2 =>
    obtain ⟨c, hc⟩ := hsub (Om.v false a) (Or.inl rfl)
    obtain ⟨d, hd⟩ := hsub (Om.v true b) (Or.inr rfl)
    exact absurd (((Om.v.inj hc).1).trans ((Om.v.inj hd).1).symm) (by simp)
  | tile i j' a b => obtain ⟨c, hc⟩ := hsub (Om.h i a) (Or.inl rfl); exact absurd hc (by simp)

end Classify


section ClassifyPairs

variable {T C : Type} {cw ce cs cn : T → C} {M L : Nat}
  {hM : 0 < M} {hL : 0 < L} {τ : TorusTiling cw ce cs cn}

/-- A same-block horizontal pair supports only the shield `d_{H_i}`. -/
theorem Sg_pair_HH_same {q : Pt T} {K : Face (Om M L)} (hM3 : 3 ≤ M) (hL3 : 3 ≤ L)
    (h : Sg hM hL τ q K) {i : Bool} {a a' : Fin M} (haa : a ≠ a')
    (hK : K = Face.pr (Om.h i a) (Om.h i a')) : q = Pt.shd (.H i) := by
  cases h with
  | root => rcases eq_pr_elim hK (Om.v false ⟨0, hL⟩) trivial with e | e <;> simp at e
  | rolH i' c =>
    have e1 := eq_pt_elim hK.symm (Om.h i a) (Or.inl rfl)
    have e2 := eq_pt_elim hK.symm (Om.h i a') (Or.inr rfl)
    exact absurd (Om.h.inj (e1.trans e2.symm)).2 haa
  | rolV j' c =>
    have e1 := eq_pt_elim hK.symm (Om.h i a) (Or.inl rfl)
    simp at e1
  | shdH i' c c' hcc =>
    rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e | e <;> rw [(Om.h.inj e).1]
  | shdV j' c c' hcc => rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e | e <;> simp at e
  | grdH i' =>
    have e0 := eq_pr_elim hK (Om.h i' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    have e1 := eq_pr_elim hK (Om.h i' ⟨1, by omega⟩) ⟨⟨1, by omega⟩, rfl⟩
    have e2 := eq_pr_elim hK (Om.h i' ⟨2, by omega⟩) ⟨⟨2, by omega⟩, rfl⟩
    rcases three_not_two e0 e1 e2 with e | e | e
    · have hv : (0 : Nat) = 1 := congrArg Fin.val (Om.h.inj e).2
      exact absurd hv (by omega)
    · have hv : (0 : Nat) = 2 := congrArg Fin.val (Om.h.inj e).2
      exact absurd hv (by omega)
    · have hv : (1 : Nat) = 2 := congrArg Fin.val (Om.h.inj e).2
      exact absurd hv (by omega)
  | grdV j' =>
    rcases eq_pr_elim hK (Om.v j' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩ with e | e <;> simp at e
  | relOut i' c =>
    have hi1 : i' = i := by
      rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e | e <;> exact (Om.h.inj e).1
    have hi2 : (!i') = i := by
      rcases eq_pr_elim hK (Om.h (!i') (zsucc hM c)) (Or.inr rfl) with e | e <;> exact (Om.h.inj e).1
    exact absurd (hi2.trans hi1.symm) (bool_not_ne i')
  | relDflt c d h1 h2 =>
    have hi1 : false = i := by
      rcases eq_pr_elim hK (Om.h false c) (Or.inl rfl) with e | e <;> exact (Om.h.inj e).1
    have hi2 : true = i := by
      rcases eq_pr_elim hK (Om.h true d) (Or.inr rfl) with e | e <;> exact (Om.h.inj e).1
    exact absurd (hi1.trans hi2.symm) (by simp)
  | selOut j' c => rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e | e <;> simp at e
  | selDflt c d h1 h2 =>
    rcases eq_pr_elim hK (Om.v false c) (Or.inl rfl) with e | e <;> simp at e
  | tile i' j' c d => rcases eq_pr_elim hK (Om.v j' d) (Or.inr rfl) with e | e <;> simp at e

/-- A successor pair supports only the output relation point `R_i`. -/
theorem Sg_pair_HH_out {q : Pt T} {K : Face (Om M L)} (hM3 : 3 ≤ M) (hL3 : 3 ≤ L)
    (h : Sg hM hL τ q K) {i : Bool} {a : Fin M}
    (hK : K = Face.pr (Om.h i a) (Om.h (!i) (zsucc hM a))) : q = Pt.Rel (.out i) := by
  cases h with
  | root => rcases eq_pr_elim hK (Om.v false ⟨0, hL⟩) trivial with e | e <;> simp at e
  | rolH i' c =>
    have e1 := eq_pt_elim hK.symm (Om.h i a) (Or.inl rfl)
    have e2 := eq_pt_elim hK.symm (Om.h (!i) (zsucc hM a)) (Or.inr rfl)
    exact absurd ((Om.h.inj (e2.trans e1.symm)).1) (bool_not_ne i)
  | rolV j' c =>
    have e1 := eq_pt_elim hK.symm (Om.h i a) (Or.inl rfl)
    simp at e1
  | shdH i' c c' hcc =>
    rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e1 | e1 <;>
      rcases eq_pr_elim hK (Om.h i' c') (Or.inr rfl) with e2 | e2
    · exact absurd ((Om.h.inj e1).2.trans (Om.h.inj e2).2.symm) hcc
    · exact absurd (((Om.h.inj e1).1.symm).trans (Om.h.inj e2).1) (fun hh => bool_not_ne i hh.symm)
    · exact absurd (((Om.h.inj e2).1.symm).trans (Om.h.inj e1).1) (fun hh => bool_not_ne i hh.symm)
    · exact absurd ((Om.h.inj e1).2.trans (Om.h.inj e2).2.symm) hcc
  | shdV j' c c' hcc => rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e | e <;> simp at e
  | grdH i' =>
    have e0 := eq_pr_elim hK (Om.h i' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    have e1 := eq_pr_elim hK (Om.h i' ⟨1, by omega⟩) ⟨⟨1, by omega⟩, rfl⟩
    have e2 := eq_pr_elim hK (Om.h i' ⟨2, by omega⟩) ⟨⟨2, by omega⟩, rfl⟩
    rcases three_not_two e0 e1 e2 with e | e | e
    · have hv : (0 : Nat) = 1 := congrArg Fin.val (Om.h.inj e).2
      exact absurd hv (by omega)
    · have hv : (0 : Nat) = 2 := congrArg Fin.val (Om.h.inj e).2
      exact absurd hv (by omega)
    · have hv : (1 : Nat) = 2 := congrArg Fin.val (Om.h.inj e).2
      exact absurd hv (by omega)
  | grdV j' =>
    rcases eq_pr_elim hK (Om.v j' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩ with e | e <;> simp at e
  | relOut i' c =>
    rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e1 | e1
    · rw [(Om.h.inj e1).1]
    · rcases eq_pr_elim hK (Om.h (!i') (zsucc hM c)) (Or.inr rfl) with e2 | e2
      · -- c = zsucc a and zsucc c = a
        exact absurd (zsucc_not_double hM hM3 ((Om.h.inj e1).2) ((Om.h.inj e2).2).symm) (by simp)
      · exact absurd ((Om.h.inj e2).1) (fun hh => bool_not_ne i' (by
          have : i' = i := by
            have h1 : (!i') = (!i) := hh
            cases i' <;> cases i <;> simp_all
          rw [this]
          have h2 : i' = (!i) := (Om.h.inj e1).1
          rw [this] at h2
          exact h2.symm))
  | relDflt c d h1 h2 =>
    rcases eq_pr_elim hK (Om.h false c) (Or.inl rfl) with e1 | e1 <;>
      rcases eq_pr_elim hK (Om.h true d) (Or.inr rfl) with e2 | e2
    · exact absurd ((Om.h.inj e1).1.trans (Om.h.inj e2).1.symm) (by simp)
    · -- c = a, d = zsucc a, i = false
      exact absurd ((Om.h.inj e2).2.trans (congrArg (zsucc hM) (Om.h.inj e1).2).symm) h1
    · exact absurd ((Om.h.inj e1).2.trans (congrArg (zsucc hM) (Om.h.inj e2).2).symm) h2
    · exact absurd ((Om.h.inj e1).1.trans (Om.h.inj e2).1.symm) (by simp)
  | selOut j' c => rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e | e <;> simp at e
  | selDflt c d h1 h2 =>
    rcases eq_pr_elim hK (Om.v false c) (Or.inl rfl) with e | e <;> simp at e
  | tile i' j' c d => rcases eq_pr_elim hK (Om.v j' d) (Or.inr rfl) with e | e <;> simp at e

/-- A non-successor mixed horizontal pair supports only the default point `R₀₀`. -/
theorem Sg_pair_HH_dflt {q : Pt T} {K : Face (Om M L)} (hM3 : 3 ≤ M) (hL3 : 3 ≤ L)
    (h : Sg hM hL τ q K) {a b : Fin M} (hab : ¬ (b = zsucc hM a)) (hba : ¬ (a = zsucc hM b))
    (hK : K = Face.pr (Om.h false a) (Om.h true b)) : q = Pt.Rel .dflt := by
  cases h with
  | root => rcases eq_pr_elim hK (Om.v false ⟨0, hL⟩) trivial with e | e <;> simp at e
  | rolH i' c =>
    have e1 := eq_pt_elim hK.symm (Om.h false a) (Or.inl rfl)
    have e2 := eq_pt_elim hK.symm (Om.h true b) (Or.inr rfl)
    exact absurd (Om.h.inj (e1.trans e2.symm)).1 (by simp)
  | rolV j' c =>
    have e1 := eq_pt_elim hK.symm (Om.h false a) (Or.inl rfl)
    simp at e1
  | shdH i' c c' hcc =>
    rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e1 | e1 <;>
      rcases eq_pr_elim hK (Om.h i' c') (Or.inr rfl) with e2 | e2
    · exact absurd ((Om.h.inj e1).2.trans (Om.h.inj e2).2.symm) hcc
    · exact absurd (((Om.h.inj e1).1.symm).trans (Om.h.inj e2).1) (by simp)
    · exact absurd (((Om.h.inj e2).1.symm).trans (Om.h.inj e1).1) (by simp)
    · exact absurd ((Om.h.inj e1).2.trans (Om.h.inj e2).2.symm) hcc
  | shdV j' c c' hcc => rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e | e <;> simp at e
  | grdH i' =>
    have e0 := eq_pr_elim hK (Om.h i' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    have e1 := eq_pr_elim hK (Om.h i' ⟨1, by omega⟩) ⟨⟨1, by omega⟩, rfl⟩
    have e2 := eq_pr_elim hK (Om.h i' ⟨2, by omega⟩) ⟨⟨2, by omega⟩, rfl⟩
    rcases three_not_two e0 e1 e2 with e | e | e
    · have hv : (0 : Nat) = 1 := congrArg Fin.val (Om.h.inj e).2
      exact absurd hv (by omega)
    · have hv : (0 : Nat) = 2 := congrArg Fin.val (Om.h.inj e).2
      exact absurd hv (by omega)
    · have hv : (1 : Nat) = 2 := congrArg Fin.val (Om.h.inj e).2
      exact absurd hv (by omega)
  | grdV j' =>
    rcases eq_pr_elim hK (Om.v j' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩ with e | e <;> simp at e
  | relOut i' c =>
    rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e1 | e1 <;>
      rcases eq_pr_elim hK (Om.h (!i') (zsucc hM c)) (Or.inr rfl) with e2 | e2
    · exact absurd (((Om.h.inj e2).1).trans ((Om.h.inj e1).1).symm) (bool_not_ne i')
    · -- i' = false, c = a, zsucc c = b
      exact absurd (((Om.h.inj e2).2).symm.trans (congrArg (zsucc hM) (Om.h.inj e1).2)) hab
    · -- i' = true, c = b, zsucc c = a
      exact absurd (((Om.h.inj e2).2).symm.trans (congrArg (zsucc hM) (Om.h.inj e1).2)) hba
    · exact absurd (((Om.h.inj e2).1).trans ((Om.h.inj e1).1).symm) (bool_not_ne i')
  | relDflt c d h1 h2 => rfl
  | selOut j' c => rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e | e <;> simp at e
  | selDflt c d h1 h2 =>
    rcases eq_pr_elim hK (Om.v false c) (Or.inl rfl) with e | e <;> simp at e
  | tile i' j' c d => rcases eq_pr_elim hK (Om.v j' d) (Or.inr rfl) with e | e <;> simp at e

/-- A cell pair supports only its tile point. -/
theorem Sg_pair_HV {q : Pt T} {K : Face (Om M L)} (hM3 : 3 ≤ M) (hL3 : 3 ≤ L)
    (h : Sg hM hL τ q K) {i j : Bool} {a : Fin M} {b : Fin L}
    (hK : K = Face.pr (Om.h i a) (Om.v j b)) : q = Pt.Tl i j (τ.tile a.val b.val) := by
  cases h with
  | root =>
    have e0 := eq_pr_elim hK (Om.h i ⟨0, by omega⟩) trivial
    have e1 := eq_pr_elim hK (Om.h i ⟨1, by omega⟩) trivial
    rcases e0 with e0 | e0
    · rcases e1 with e1 | e1
      · have hv : (0 : Nat) = 1 := congrArg Fin.val (Om.h.inj (e0.trans e1.symm)).2
        exact absurd hv (by omega)
      · simp at e1
    · simp at e0
  | rolH i' c =>
    have e1 := eq_pt_elim hK.symm (Om.h i a) (Or.inl rfl)
    have e2 := eq_pt_elim hK.symm (Om.v j b) (Or.inr rfl)
    exact absurd (e1.trans e2.symm) (by simp)
  | rolV j' c =>
    have e1 := eq_pt_elim hK.symm (Om.h i a) (Or.inl rfl)
    have e2 := eq_pt_elim hK.symm (Om.v j b) (Or.inr rfl)
    exact absurd (e1.trans e2.symm) (by simp)
  | shdH i' c c' hcc =>
    rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e1 | e1
    · rcases eq_pr_elim hK (Om.h i' c') (Or.inr rfl) with e2 | e2
      · exact absurd ((Om.h.inj e1).2.trans (Om.h.inj e2).2.symm) hcc
      · simp at e2
    · simp at e1
  | shdV j' c c' hcc =>
    rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e1 | e1
    · simp at e1
    · rcases eq_pr_elim hK (Om.v j' c') (Or.inr rfl) with e2 | e2
      · simp at e2
      · exact absurd ((Om.v.inj e1).2.trans (Om.v.inj e2).2.symm) hcc
  | grdH i' =>
    have e0 := eq_pr_elim hK (Om.h i' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    have e1 := eq_pr_elim hK (Om.h i' ⟨1, by omega⟩) ⟨⟨1, by omega⟩, rfl⟩
    rcases e0 with e0 | e0
    · rcases e1 with e1 | e1
      · have hv : (0 : Nat) = 1 := congrArg Fin.val (Om.h.inj (e0.trans e1.symm)).2
        exact absurd hv (by omega)
      · simp at e1
    · simp at e0
  | grdV j' =>
    have e0 := eq_pr_elim hK (Om.v j' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    have e1 := eq_pr_elim hK (Om.v j' ⟨1, by omega⟩) ⟨⟨1, by omega⟩, rfl⟩
    rcases e0 with e0 | e0
    · simp at e0
    · rcases e1 with e1 | e1
      · simp at e1
      · have hv : (0 : Nat) = 1 := congrArg Fin.val (Om.v.inj (e0.trans e1.symm)).2
        exact absurd hv (by omega)
  | relOut i' c =>
    rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e1 | e1
    · rcases eq_pr_elim hK (Om.h (!i') (zsucc hM c)) (Or.inr rfl) with e2 | e2
      · exact absurd (((Om.h.inj e2).1).trans ((Om.h.inj e1).1).symm) (bool_not_ne i')
      · simp at e2
    · simp at e1
  | relDflt c d h1 h2 =>
    rcases eq_pr_elim hK (Om.h false c) (Or.inl rfl) with e1 | e1
    · rcases eq_pr_elim hK (Om.h true d) (Or.inr rfl) with e2 | e2
      · exact absurd (((Om.h.inj e1).1).trans ((Om.h.inj e2).1).symm) (by simp)
      · simp at e2
    · simp at e1
  | selOut j' c =>
    rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e1 | e1
    · simp at e1
    · rcases eq_pr_elim hK (Om.v (!j') (zsucc hL c)) (Or.inr rfl) with e2 | e2
      · simp at e2
      · exact absurd (((Om.v.inj e2).1).trans ((Om.v.inj e1).1).symm) (bool_not_ne j')
  | selDflt c d h1 h2 =>
    rcases eq_pr_elim hK (Om.v false c) (Or.inl rfl) with e1 | e1
    · simp at e1
    · rcases eq_pr_elim hK (Om.v true d) (Or.inr rfl) with e2 | e2
      · simp at e2
      · exact absurd (((Om.v.inj e1).1).trans ((Om.v.inj e2).1).symm) (by simp)
  | tile i' j' c d =>
    rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e1 | e1
    · rcases eq_pr_elim hK (Om.v j' d) (Or.inr rfl) with e2 | e2
      · simp at e2
      · rw [(Om.h.inj e1).1, (Om.h.inj e1).2, (Om.v.inj e2).1, (Om.v.inj e2).2]
    · simp at e1

end ClassifyPairs


section ClassifyPairsV

variable {T C : Type} {cw ce cs cn : T → C} {M L : Nat}
  {hM : 0 < M} {hL : 0 < L} {τ : TorusTiling cw ce cs cn}

/-- A same-block vertical pair supports only the shield `d_{V_j}`. -/
theorem Sg_pair_VV_same {q : Pt T} {K : Face (Om M L)} (hM3 : 3 ≤ M) (hL3 : 3 ≤ L)
    (h : Sg hM hL τ q K) {j : Bool} {b b' : Fin L} (hbb : b ≠ b')
    (hK : K = Face.pr (Om.v j b) (Om.v j b')) : q = Pt.shd (.V j) := by
  cases h with
  | root => rcases eq_pr_elim hK (Om.h false ⟨0, hM⟩) trivial with e | e <;> simp at e
  | rolH i' c =>
    have e1 := eq_pt_elim hK.symm (Om.v j b) (Or.inl rfl)
    simp at e1
  | rolV j' c =>
    have e1 := eq_pt_elim hK.symm (Om.v j b) (Or.inl rfl)
    have e2 := eq_pt_elim hK.symm (Om.v j b') (Or.inr rfl)
    exact absurd (Om.v.inj (e1.trans e2.symm)).2 hbb
  | shdH i' c c' hcc => rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e | e <;> simp at e
  | shdV j' c c' hcc =>
    rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e | e <;> rw [(Om.v.inj e).1]
  | grdH i' =>
    rcases eq_pr_elim hK (Om.h i' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩ with e | e <;> simp at e
  | grdV j' =>
    have e0 := eq_pr_elim hK (Om.v j' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    have e1 := eq_pr_elim hK (Om.v j' ⟨1, by omega⟩) ⟨⟨1, by omega⟩, rfl⟩
    have e2 := eq_pr_elim hK (Om.v j' ⟨2, by omega⟩) ⟨⟨2, by omega⟩, rfl⟩
    rcases three_not_two e0 e1 e2 with e | e | e
    · have hv : (0 : Nat) = 1 := congrArg Fin.val (Om.v.inj e).2
      exact absurd hv (by omega)
    · have hv : (0 : Nat) = 2 := congrArg Fin.val (Om.v.inj e).2
      exact absurd hv (by omega)
    · have hv : (1 : Nat) = 2 := congrArg Fin.val (Om.v.inj e).2
      exact absurd hv (by omega)
  | relOut i' c => rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e | e <;> simp at e
  | relDflt c d h1 h2 =>
    rcases eq_pr_elim hK (Om.h false c) (Or.inl rfl) with e | e <;> simp at e
  | selOut j' c =>
    have hj1 : j' = j := by
      rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e | e <;> exact (Om.v.inj e).1
    have hj2 : (!j') = j := by
      rcases eq_pr_elim hK (Om.v (!j') (zsucc hL c)) (Or.inr rfl) with e | e <;> exact (Om.v.inj e).1
    exact absurd (hj2.trans hj1.symm) (bool_not_ne j')
  | selDflt c d h1 h2 =>
    have hj1 : false = j := by
      rcases eq_pr_elim hK (Om.v false c) (Or.inl rfl) with e | e <;> exact (Om.v.inj e).1
    have hj2 : true = j := by
      rcases eq_pr_elim hK (Om.v true d) (Or.inr rfl) with e | e <;> exact (Om.v.inj e).1
    exact absurd (hj1.trans hj2.symm) (by simp)
  | tile i' j' c d => rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e | e <;> simp at e

/-- A vertical successor pair supports only the output relation point `S_j`. -/
theorem Sg_pair_VV_out {q : Pt T} {K : Face (Om M L)} (hM3 : 3 ≤ M) (hL3 : 3 ≤ L)
    (h : Sg hM hL τ q K) {j : Bool} {b : Fin L}
    (hK : K = Face.pr (Om.v j b) (Om.v (!j) (zsucc hL b))) : q = Pt.Sel (.out j) := by
  cases h with
  | root => rcases eq_pr_elim hK (Om.h false ⟨0, hM⟩) trivial with e | e <;> simp at e
  | rolH i' c =>
    have e1 := eq_pt_elim hK.symm (Om.v j b) (Or.inl rfl)
    simp at e1
  | rolV j' c =>
    have e1 := eq_pt_elim hK.symm (Om.v j b) (Or.inl rfl)
    have e2 := eq_pt_elim hK.symm (Om.v (!j) (zsucc hL b)) (Or.inr rfl)
    exact absurd ((Om.v.inj (e2.trans e1.symm)).1) (bool_not_ne j)
  | shdH i' c c' hcc => rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e | e <;> simp at e
  | shdV j' c c' hcc =>
    rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e1 | e1 <;>
      rcases eq_pr_elim hK (Om.v j' c') (Or.inr rfl) with e2 | e2
    · exact absurd ((Om.v.inj e1).2.trans (Om.v.inj e2).2.symm) hcc
    · exact absurd (((Om.v.inj e1).1.symm).trans (Om.v.inj e2).1) (fun hh => bool_not_ne j hh.symm)
    · exact absurd (((Om.v.inj e2).1.symm).trans (Om.v.inj e1).1) (fun hh => bool_not_ne j hh.symm)
    · exact absurd ((Om.v.inj e1).2.trans (Om.v.inj e2).2.symm) hcc
  | grdH i' =>
    rcases eq_pr_elim hK (Om.h i' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩ with e | e <;> simp at e
  | grdV j' =>
    have e0 := eq_pr_elim hK (Om.v j' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    have e1 := eq_pr_elim hK (Om.v j' ⟨1, by omega⟩) ⟨⟨1, by omega⟩, rfl⟩
    have e2 := eq_pr_elim hK (Om.v j' ⟨2, by omega⟩) ⟨⟨2, by omega⟩, rfl⟩
    rcases three_not_two e0 e1 e2 with e | e | e
    · have hv : (0 : Nat) = 1 := congrArg Fin.val (Om.v.inj e).2
      exact absurd hv (by omega)
    · have hv : (0 : Nat) = 2 := congrArg Fin.val (Om.v.inj e).2
      exact absurd hv (by omega)
    · have hv : (1 : Nat) = 2 := congrArg Fin.val (Om.v.inj e).2
      exact absurd hv (by omega)
  | relOut i' c => rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e | e <;> simp at e
  | relDflt c d h1 h2 =>
    rcases eq_pr_elim hK (Om.h false c) (Or.inl rfl) with e | e <;> simp at e
  | selOut j' c =>
    rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e1 | e1
    · rw [(Om.v.inj e1).1]
    · rcases eq_pr_elim hK (Om.v (!j') (zsucc hL c)) (Or.inr rfl) with e2 | e2
      · exact absurd (zsucc_not_double hL hL3 ((Om.v.inj e1).2) ((Om.v.inj e2).2).symm) (by simp)
      · exact absurd ((Om.v.inj e2).1) (fun hh => bool_not_ne j' (by
          have hjj : j' = j := by
            have h1 : (!j') = (!j) := hh
            cases j' <;> cases j <;> simp_all
          rw [hjj]
          have h2 : j' = (!j) := (Om.v.inj e1).1
          rw [hjj] at h2
          exact h2.symm))
  | selDflt c d h1 h2 =>
    rcases eq_pr_elim hK (Om.v false c) (Or.inl rfl) with e1 | e1 <;>
      rcases eq_pr_elim hK (Om.v true d) (Or.inr rfl) with e2 | e2
    · exact absurd ((Om.v.inj e1).1.trans (Om.v.inj e2).1.symm) (by simp)
    · exact absurd ((Om.v.inj e2).2.trans (congrArg (zsucc hL) (Om.v.inj e1).2).symm) h1
    · exact absurd ((Om.v.inj e1).2.trans (congrArg (zsucc hL) (Om.v.inj e2).2).symm) h2
    · exact absurd ((Om.v.inj e1).1.trans (Om.v.inj e2).1.symm) (by simp)
  | tile i' j' c d => rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e | e <;> simp at e

/-- A non-successor mixed vertical pair supports only the default point `S₀₀`. -/
theorem Sg_pair_VV_dflt {q : Pt T} {K : Face (Om M L)} (hM3 : 3 ≤ M) (hL3 : 3 ≤ L)
    (h : Sg hM hL τ q K) {a b : Fin L} (hab : ¬ (b = zsucc hL a)) (hba : ¬ (a = zsucc hL b))
    (hK : K = Face.pr (Om.v false a) (Om.v true b)) : q = Pt.Sel .dflt := by
  cases h with
  | root => rcases eq_pr_elim hK (Om.h false ⟨0, hM⟩) trivial with e | e <;> simp at e
  | rolH i' c =>
    have e1 := eq_pt_elim hK.symm (Om.v false a) (Or.inl rfl)
    simp at e1
  | rolV j' c =>
    have e1 := eq_pt_elim hK.symm (Om.v false a) (Or.inl rfl)
    have e2 := eq_pt_elim hK.symm (Om.v true b) (Or.inr rfl)
    exact absurd (Om.v.inj (e1.trans e2.symm)).1 (by simp)
  | shdH i' c c' hcc => rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e | e <;> simp at e
  | shdV j' c c' hcc =>
    rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e1 | e1 <;>
      rcases eq_pr_elim hK (Om.v j' c') (Or.inr rfl) with e2 | e2
    · exact absurd ((Om.v.inj e1).2.trans (Om.v.inj e2).2.symm) hcc
    · exact absurd (((Om.v.inj e1).1.symm).trans (Om.v.inj e2).1) (by simp)
    · exact absurd (((Om.v.inj e2).1.symm).trans (Om.v.inj e1).1) (by simp)
    · exact absurd ((Om.v.inj e1).2.trans (Om.v.inj e2).2.symm) hcc
  | grdH i' =>
    rcases eq_pr_elim hK (Om.h i' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩ with e | e <;> simp at e
  | grdV j' =>
    have e0 := eq_pr_elim hK (Om.v j' ⟨0, by omega⟩) ⟨⟨0, by omega⟩, rfl⟩
    have e1 := eq_pr_elim hK (Om.v j' ⟨1, by omega⟩) ⟨⟨1, by omega⟩, rfl⟩
    have e2 := eq_pr_elim hK (Om.v j' ⟨2, by omega⟩) ⟨⟨2, by omega⟩, rfl⟩
    rcases three_not_two e0 e1 e2 with e | e | e
    · have hv : (0 : Nat) = 1 := congrArg Fin.val (Om.v.inj e).2
      exact absurd hv (by omega)
    · have hv : (0 : Nat) = 2 := congrArg Fin.val (Om.v.inj e).2
      exact absurd hv (by omega)
    · have hv : (1 : Nat) = 2 := congrArg Fin.val (Om.v.inj e).2
      exact absurd hv (by omega)
  | relOut i' c => rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e | e <;> simp at e
  | relDflt c d h1 h2 =>
    rcases eq_pr_elim hK (Om.h false c) (Or.inl rfl) with e | e <;> simp at e
  | selOut j' c =>
    rcases eq_pr_elim hK (Om.v j' c) (Or.inl rfl) with e1 | e1 <;>
      rcases eq_pr_elim hK (Om.v (!j') (zsucc hL c)) (Or.inr rfl) with e2 | e2
    · exact absurd (((Om.v.inj e2).1).trans ((Om.v.inj e1).1).symm) (bool_not_ne j')
    · exact absurd (((Om.v.inj e2).2).symm.trans (congrArg (zsucc hL) (Om.v.inj e1).2)) hab
    · exact absurd (((Om.v.inj e2).2).symm.trans (congrArg (zsucc hL) (Om.v.inj e1).2)) hba
    · exact absurd (((Om.v.inj e2).1).trans ((Om.v.inj e1).1).symm) (bool_not_ne j')
  | selDflt c d h1 h2 => rfl
  | tile i' j' c d => rcases eq_pr_elim hK (Om.h i' c) (Or.inl rfl) with e | e <;> simp at e

end ClassifyPairsV


/-! ## Lemma 9.1: calibration -/

section Calibration

variable {T C : Type} {cw ce cs cn : T → C} {M L : Nat}
  {hM : 0 < M} {hL : 0 < L} {τ : TorusTiling cw ce cs cn}

/-- Every point of `P_W` has a support.  Surjectivity of the tiling is exactly what makes
this true for the tile points. -/
theorem Sg_exists (hM2 : 2 ≤ M) (hL2 : 2 ≤ L) (hmM : τ.m ≤ M) (hlL : τ.l ≤ L)
    (hsurj : τ.Surjective) (q : Pt T) : ∃ K, Sg hM hL τ q K := by
  have h0M : (0 : Nat) < M := by omega
  have h1M : (1 : Nat) < M := by omega
  have h0L : (0 : Nat) < L := by omega
  have h1L : (1 : Nat) < L := by omega
  have hne01M : (⟨0, h0M⟩ : Fin M) ≠ ⟨1, h1M⟩ := by
    intro he
    have hv : (0 : Nat) = 1 := congrArg Fin.val he
    omega
  have hne01L : (⟨0, h0L⟩ : Fin L) ≠ ⟨1, h1L⟩ := by
    intro he
    have hv : (0 : Nat) = 1 := congrArg Fin.val he
    omega
  cases q with
  | root => exact ⟨_, Sg.root⟩
  | rol X =>
    cases X with
    | H i => exact ⟨_, Sg.rolH i ⟨0, h0M⟩⟩
    | V j => exact ⟨_, Sg.rolV j ⟨0, h0L⟩⟩
  | shd X =>
    cases X with
    | H i => exact ⟨_, Sg.shdH i ⟨0, h0M⟩ ⟨1, h1M⟩ hne01M⟩
    | V j => exact ⟨_, Sg.shdV j ⟨0, h0L⟩ ⟨1, h1L⟩ hne01L⟩
  | grd X =>
    cases X with
    | H i => exact ⟨_, Sg.grdH i⟩
    | V j => exact ⟨_, Sg.grdV j⟩
  | Rel k =>
    cases k with
    | out i => exact ⟨_, Sg.relOut i ⟨0, h0M⟩⟩
    | dflt =>
      refine ⟨_, Sg.relDflt (⟨0, h0M⟩ : Fin M) ⟨0, h0M⟩ ?_ ?_⟩ <;>
        exact fun he => zsucc_ne hM hM2 ⟨0, h0M⟩ he.symm
  | Sel k =>
    cases k with
    | out j => exact ⟨_, Sg.selOut j ⟨0, h0L⟩⟩
    | dflt =>
      refine ⟨_, Sg.selDflt (⟨0, h0L⟩ : Fin L) ⟨0, h0L⟩ ?_ ?_⟩ <;>
        exact fun he => zsucc_ne hL hL2 ⟨0, h0L⟩ he.symm
  | Tl i j t =>
    obtain ⟨x, y, hxy⟩ := hsurj t
    have hx : x % τ.m < M := by have := Nat.mod_lt x τ.hm; omega
    have hy : y % τ.l < L := by have := Nat.mod_lt y τ.hl; omega
    have het : τ.tile ((⟨x % τ.m, hx⟩ : Fin M).val) ((⟨y % τ.l, hy⟩ : Fin L).val) = t := by
      show τ.tile (x % τ.m) (y % τ.l) = t
      calc τ.tile (x % τ.m) (y % τ.l)
          = τ.tile x (y % τ.l) := τ.congrH (Nat.mod_eq_of_lt (Nat.mod_lt x τ.hm)) _
        _ = τ.tile x y := τ.congrV x (Nat.mod_eq_of_lt (Nat.mod_lt y τ.hl))
        _ = t := hxy
    exact ⟨_, het ▸ Sg.tile i j ⟨x % τ.m, hx⟩ ⟨y % τ.l, hy⟩⟩

/-- **Lemma 9.1** (Calibration).  For every `p` and every support `H ∈ Σ_p`,
`Act(H) = ↑p`. -/
theorem calibration (hM3 : 3 ≤ M) (hL3 : 3 ≤ L) (hmM : τ.m ≤ M) (hlL : τ.l ≤ L)
    (hsurj : τ.Surjective) {p : Pt T} {K : Face (Om M L)} (h : Sg hM hL τ p K) :
    ActG (Sg hM hL τ) K = up p := by
  have h0M : (0 : Nat) < M := by omega
  have h1M : (1 : Nat) < M := by omega
  have h0L : (0 : Nat) < L := by omega
  have h1L : (1 : Nat) < L := by omega
  have hne01M : (⟨0, h0M⟩ : Fin M) ≠ ⟨1, h1M⟩ := by
    intro he
    have hv : (0 : Nat) = 1 := congrArg Fin.val he
    omega
  have hne01L : (⟨0, h0L⟩ : Fin L) ≠ ⟨1, h1L⟩ := by
    intro he
    have hv : (0 : Nat) = 1 := congrArg Fin.val he
    omega
  cases h with
  | root =>
    refine Set.ext fun q => ⟨fun _ => trivial, fun _ => ?_⟩
    obtain ⟨K', hK'⟩ := Sg_exists (by omega) (by omega) hmM hlL hsurj q
    exact ⟨K', hK', fun z _ => trivial⟩
  | rolH i a =>
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨K', hK', hsub⟩
      have := Sg_singleton hM3 hL3 hK' (fun z hz => hsub z hz)
      rw [this]; exact Poset.le_refl _
    · intro hq
      rw [rol_le hq]
      exact ⟨_, Sg.rolH i a, Poset.le_refl _⟩
  | rolV j b =>
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨K', hK', hsub⟩
      have := Sg_singleton hM3 hL3 hK' (fun z hz => hsub z hz)
      rw [this]; exact Poset.le_refl _
    · intro hq
      rw [rol_le hq]
      exact ⟨_, Sg.rolV j b, Poset.le_refl _⟩
  | shdH i a a' haa =>
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨K', hK', hsub⟩
      rcases face_sub_pair hsub with rfl | rfl | rfl
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]; exact Or.inr rfl
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]; exact Or.inr rfl
      · rw [Sg_pair_HH_same hM3 hL3 hK' haa rfl]; exact Or.inl rfl
    · rintro (rfl | rfl)
      · exact ⟨_, Sg.shdH i a a' haa, Poset.le_refl _⟩
      · exact ⟨_, Sg.rolH i a, Face.le_pt (Or.inl rfl)⟩
  | shdV j b b' hbb =>
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨K', hK', hsub⟩
      rcases face_sub_pair hsub with rfl | rfl | rfl
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]; exact Or.inr rfl
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]; exact Or.inr rfl
      · rw [Sg_pair_VV_same hM3 hL3 hK' hbb rfl]; exact Or.inl rfl
    · rintro (rfl | rfl)
      · exact ⟨_, Sg.shdV j b b' hbb, Poset.le_refl _⟩
      · exact ⟨_, Sg.rolV j b, Face.le_pt (Or.inl rfl)⟩
  | grdH i =>
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨K', hK', hsub⟩
      rcases Sg_in_blockH hM3 hL3 hK' (fun z hz => hsub z hz) with rfl | rfl | rfl
      · exact Or.inr (Or.inr rfl)
      · exact Or.inr (Or.inl rfl)
      · exact Or.inl rfl
    · rintro (rfl | rfl | rfl)
      · exact ⟨_, Sg.grdH i, Poset.le_refl _⟩
      · exact ⟨_, Sg.shdH i ⟨0, h0M⟩ ⟨1, h1M⟩ hne01M,
          le_pr ⟨⟨0, h0M⟩, rfl⟩ ⟨⟨1, h1M⟩, rfl⟩⟩
      · exact ⟨_, Sg.rolH i ⟨0, h0M⟩, Face.le_pt ⟨⟨0, h0M⟩, rfl⟩⟩
  | grdV j =>
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨K', hK', hsub⟩
      rcases Sg_in_blockV hM3 hL3 hK' (fun z hz => hsub z hz) with rfl | rfl | rfl
      · exact Or.inr (Or.inr rfl)
      · exact Or.inr (Or.inl rfl)
      · exact Or.inl rfl
    · rintro (rfl | rfl | rfl)
      · exact ⟨_, Sg.grdV j, Poset.le_refl _⟩
      · exact ⟨_, Sg.shdV j ⟨0, h0L⟩ ⟨1, h1L⟩ hne01L,
          le_pr ⟨⟨0, h0L⟩, rfl⟩ ⟨⟨1, h1L⟩, rfl⟩⟩
      · exact ⟨_, Sg.rolV j ⟨0, h0L⟩, Face.le_pt ⟨⟨0, h0L⟩, rfl⟩⟩
  | relOut i a =>
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨K', hK', hsub⟩
      rcases face_sub_pair hsub with rfl | rfl | rfl
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]
        exact Or.inr (by cases i <;> simp [roleOfOm])
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]
        exact Or.inr (by cases i <;> simp [roleOfOm])
      · rw [Sg_pair_HH_out hM3 hL3 hK' rfl]; exact Or.inl rfl
    · rintro (rfl | rfl | rfl)
      · exact ⟨_, Sg.relOut i a, Poset.le_refl _⟩
      · cases i
        · exact ⟨_, Sg.rolH false a, Face.le_pt (Or.inl rfl)⟩
        · exact ⟨_, Sg.rolH false (zsucc hM a), Face.le_pt (Or.inr rfl)⟩
      · cases i
        · exact ⟨_, Sg.rolH true (zsucc hM a), Face.le_pt (Or.inr rfl)⟩
        · exact ⟨_, Sg.rolH true a, Face.le_pt (Or.inl rfl)⟩
  | relDflt a b h1 h2 =>
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨K', hK', hsub⟩
      rcases face_sub_pair hsub with rfl | rfl | rfl
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]; exact Or.inr (Or.inl rfl)
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]; exact Or.inr (Or.inr rfl)
      · rw [Sg_pair_HH_dflt hM3 hL3 hK' h1 h2 rfl]; exact Or.inl rfl
    · rintro (rfl | rfl | rfl)
      · exact ⟨_, Sg.relDflt a b h1 h2, Poset.le_refl _⟩
      · exact ⟨_, Sg.rolH false a, Face.le_pt (Or.inl rfl)⟩
      · exact ⟨_, Sg.rolH true b, Face.le_pt (Or.inr rfl)⟩
  | selOut j b =>
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨K', hK', hsub⟩
      rcases face_sub_pair hsub with rfl | rfl | rfl
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]
        exact Or.inr (by cases j <;> simp [roleOfOm])
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]
        exact Or.inr (by cases j <;> simp [roleOfOm])
      · rw [Sg_pair_VV_out hM3 hL3 hK' rfl]; exact Or.inl rfl
    · rintro (rfl | rfl | rfl)
      · exact ⟨_, Sg.selOut j b, Poset.le_refl _⟩
      · cases j
        · exact ⟨_, Sg.rolV false b, Face.le_pt (Or.inl rfl)⟩
        · exact ⟨_, Sg.rolV false (zsucc hL b), Face.le_pt (Or.inr rfl)⟩
      · cases j
        · exact ⟨_, Sg.rolV true (zsucc hL b), Face.le_pt (Or.inr rfl)⟩
        · exact ⟨_, Sg.rolV true b, Face.le_pt (Or.inl rfl)⟩
  | selDflt a b h1 h2 =>
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨K', hK', hsub⟩
      rcases face_sub_pair hsub with rfl | rfl | rfl
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]; exact Or.inr (Or.inl rfl)
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]; exact Or.inr (Or.inr rfl)
      · rw [Sg_pair_VV_dflt hM3 hL3 hK' h1 h2 rfl]; exact Or.inl rfl
    · rintro (rfl | rfl | rfl)
      · exact ⟨_, Sg.selDflt a b h1 h2, Poset.le_refl _⟩
      · exact ⟨_, Sg.rolV false a, Face.le_pt (Or.inl rfl)⟩
      · exact ⟨_, Sg.rolV true b, Face.le_pt (Or.inr rfl)⟩
  | tile i j a b =>
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨K', hK', hsub⟩
      rcases face_sub_pair hsub with rfl | rfl | rfl
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]; exact Or.inr (Or.inl rfl)
      · rw [Sg_singleton hM3 hL3 hK' (fun z hz => hz)]; exact Or.inr (Or.inr rfl)
      · rw [Sg_pair_HV hM3 hL3 hK' rfl]; exact Or.inl rfl
    · rintro (rfl | rfl | rfl)
      · exact ⟨_, Sg.tile i j a b, Poset.le_refl _⟩
      · exact ⟨_, Sg.rolH i a, Face.le_pt (Or.inl rfl)⟩
      · exact ⟨_, Sg.rolV j b, Face.le_pt (Or.inr rfl)⟩

end Calibration


/-! ## Inverting the support relation on the point index -/

section Inversion

variable {T C : Type} {cw ce cs cn : T → C} {M L : Nat}
  {hM : 0 < M} {hL : 0 < L} {τ : TorusTiling cw ce cs cn}
  {q : Pt T} {K : Face (Om M L)}

theorem Sg_inv_rolH (h : Sg hM hL τ q K) {i : Bool} (hq : q = Pt.rol (.H i)) :
    ∃ a, K = Face.pt (Om.h i a) := by
  cases h
  case rolH i' a =>
    have : i' = i := Role.H.inj (Pt.rol.inj hq)
    subst this; exact ⟨a, rfl⟩
  all_goals simp at hq

theorem Sg_inv_rolV (h : Sg hM hL τ q K) {j : Bool} (hq : q = Pt.rol (.V j)) :
    ∃ b, K = Face.pt (Om.v j b) := by
  cases h
  case rolV j' b =>
    have : j' = j := Role.V.inj (Pt.rol.inj hq)
    subst this; exact ⟨b, rfl⟩
  all_goals simp at hq

theorem Sg_inv_grdH (h : Sg hM hL τ q K) {i : Bool} (hq : q = Pt.grd (.H i)) :
    K = blockH hM i := by
  cases h
  case grdH i' =>
    have : i' = i := Role.H.inj (Pt.grd.inj hq)
    subst this; rfl
  all_goals simp at hq

theorem Sg_inv_grdV (h : Sg hM hL τ q K) {j : Bool} (hq : q = Pt.grd (.V j)) :
    K = blockV hL j := by
  cases h
  case grdV j' =>
    have : j' = j := Role.V.inj (Pt.grd.inj hq)
    subst this; rfl
  all_goals simp at hq

theorem Sg_inv_relOut (h : Sg hM hL τ q K) {i : Bool} (hq : q = Pt.Rel (.out i)) :
    ∃ a, K = Face.pr (Om.h i a) (Om.h (!i) (zsucc hM a)) := by
  cases h
  case relOut i' a =>
    have : i' = i := RelIdx.out.inj (Pt.Rel.inj hq)
    subst this; exact ⟨a, rfl⟩
  all_goals simp at hq

theorem Sg_inv_relDflt (h : Sg hM hL τ q K) (hq : q = Pt.Rel .dflt) :
    ∃ a b, K = Face.pr (Om.h false a) (Om.h true b) := by
  cases h
  case relDflt a b h1 h2 => exact ⟨a, b, rfl⟩
  all_goals simp at hq

theorem Sg_inv_selOut (h : Sg hM hL τ q K) {j : Bool} (hq : q = Pt.Sel (.out j)) :
    ∃ b, K = Face.pr (Om.v j b) (Om.v (!j) (zsucc hL b)) := by
  cases h
  case selOut j' b =>
    have : j' = j := RelIdx.out.inj (Pt.Sel.inj hq)
    subst this; exact ⟨b, rfl⟩
  all_goals simp at hq

theorem Sg_inv_selDflt (h : Sg hM hL τ q K) (hq : q = Pt.Sel .dflt) :
    ∃ a b, K = Face.pr (Om.v false a) (Om.v true b) := by
  cases h
  case selDflt a b h1 h2 => exact ⟨a, b, rfl⟩
  all_goals simp at hq

theorem Sg_inv_tile (h : Sg hM hL τ q K) {i j : Bool} {t : T} (hq : q = Pt.Tl i j t) :
    ∃ a b, τ.tile a.val b.val = t ∧ K = Face.pr (Om.h i a) (Om.v j b) := by
  cases h
  case tile i' j' a b =>
    obtain ⟨e1, e2, e3⟩ := Pt.Tl.inj hq
    subst e1; subst e2
    exact ⟨a, b, e3, rfl⟩
  all_goals simp at hq

end Inversion


/-! ## §9.2  The global ZCDC verification -/

section ZCDCsec

variable {T C : Type} [FinE T] {cw ce cs cn : T → C} {M L : Nat}
  {hM : 0 < M} {hL : 0 < L} {τ : TorusTiling cw ce cs cn}

/-- Every mixed horizontal pair carries a relation colour. -/
theorem mixed_colour_H (a b : Fin M) :
    ∃ k, Sg hM hL τ (Pt.Rel k) (Face.pr (Om.h false a) (Om.h true b)) := by
  by_cases h1 : b = zsucc hM a
  · subst h1
    exact ⟨.out false, Sg.relOut false a⟩
  · by_cases h2 : a = zsucc hM b
    · subst h2
      refine ⟨.out true, ?_⟩
      have hs : Sg hM hL τ (Pt.Rel (.out true))
          (Face.pr (Om.h true b) (Om.h false (zsucc hM b))) := Sg.relOut true b
      rw [Face.pr_comm] at hs
      exact hs
    · exact ⟨.dflt, Sg.relDflt a b h1 h2⟩

/-- Every mixed vertical pair carries a relation colour. -/
theorem mixed_colour_V (a b : Fin L) :
    ∃ k, Sg hM hL τ (Pt.Sel k) (Face.pr (Om.v false a) (Om.v true b)) := by
  by_cases h1 : b = zsucc hL a
  · subst h1
    exact ⟨.out false, Sg.selOut false a⟩
  · by_cases h2 : a = zsucc hL b
    · subst h2
      refine ⟨.out true, ?_⟩
      have hs : Sg hM hL τ (Pt.Sel (.out true))
          (Face.pr (Om.v true b) (Om.v false (zsucc hL b))) := Sg.selOut true b
      rw [Face.pr_comm] at hs
      exact hs
    · exact ⟨.dflt, Sg.selDflt a b h1 h2⟩

/-- **§9.2**: the realized morphism satisfies every closed-domain condition in `D_W`. -/
theorem zcdc_holds (hdM : ∃ c, M = τ.m * c) (hdL : ∃ c, L = τ.l * c)
    {f : Face (Om M L) → Option (Pt T)}
    (hcone : ∀ S, coneImg f S = ActG (Sg hM hL τ) S) :
    ZCDC f (DW cw ce cs cn) := by
  intro S hS hDD
  rw [hcone S] at hDD
  obtain ⟨U, W, hUW, hanti, hsubUW, ⟨p1, hp1C, hp1U, hp1W⟩, ⟨p2, hp2C, hp2W, hp2U⟩⟩ := hDD
  obtain ⟨hUup, hWup⟩ := lemma_7_1 U W hUW
  have key : ∀ q, ActG (Sg hM hL τ) S q → ¬ (U q ∨ W q) → False := by
    intro q hq hnq
    obtain ⟨pm, hpm, hpmW⟩ := outside_minimal (isUpset_union hUup hWup) hq hnq
    exact hpmW (hsubUW pm hpm)
  have hvertH : ∀ i : Bool, ActG (Sg hM hL τ) S (rol (.H i)) → ∃ a, S.carrier (Om.h i a) := by
    rintro i ⟨K, hK, hSK⟩
    obtain ⟨a, rfl⟩ := Sg_inv_rolH hK rfl
    exact ⟨a, hSK _ rfl⟩
  have hvertV : ∀ j : Bool, ActG (Sg hM hL τ) S (rol (.V j)) → ∃ b, S.carrier (Om.v j b) := by
    rintro j ⟨K, hK, hSK⟩
    obtain ⟨b, rfl⟩ := Sg_inv_rolV hK rfl
    exact ⟨b, hSK _ rfl⟩
  rcases hUW with ⟨X, Y, hd, rfl, rfl⟩ | ⟨i, rfl, rfl⟩ | ⟨j, rfl, rfl⟩
              | ⟨i, j, t, rfl, rfl⟩ | ⟨i, j, t, rfl, rfl⟩
  · -- pair-filling cut: the mixed pair of the two witnesses carries a binary colour
    have hAX : ActG (Sg hM hL τ) S (rol X) := (hp1U : p1 = rol X) ▸ hp1C.1
    have hAY : ActG (Sg hM hL τ) S (rol Y) := (hp2W : p2 = rol Y) ▸ hp2C.1
    rcases hd with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨i, j, rfl, rfl⟩
    · obtain ⟨a, ha⟩ := hvertH false hAX
      obtain ⟨b, hb⟩ := hvertH true hAY
      obtain ⟨k, hk⟩ := mixed_colour_H (hM := hM) (hL := hL) (τ := τ) a b
      exact key (Pt.Rel k) ⟨_, hk, le_pr ha hb⟩ (by rintro (h | h) <;> simp [Set.sing] at h)
    · obtain ⟨a, ha⟩ := hvertV false hAX
      obtain ⟨b, hb⟩ := hvertV true hAY
      obtain ⟨k, hk⟩ := mixed_colour_V (hM := hM) (hL := hL) (τ := τ) a b
      exact key (Pt.Sel k) ⟨_, hk, le_pr ha hb⟩ (by rintro (h | h) <;> simp [Set.sing] at h)
    · obtain ⟨a, ha⟩ := hvertH i hAX
      obtain ⟨b, hb⟩ := hvertV j hAY
      exact key (Pt.Tl i j (τ.tile a.val b.val)) ⟨_, Sg.tile i j a b, le_pr ha hb⟩
        (by rintro (h | h) <;> simp [Set.sing] at h)
  · -- horizontal serial cut
    have h1 := (sUH_iff i p1).mp hp1U
    have h3 : p1 = grd (.H (!i)) ∨ p1 = Rel (.out i) := by
      by_contra hc
      exact hp1W ((sVH_iff i p1).mpr ⟨h1.1, hc⟩)
    have hp1g : p1 = grd (.H (!i)) := by
      rcases h3 with h | h
      · exact h
      · exact absurd (Or.inl h) h1.2
    have g1 := (sVH_iff i p2).mp hp2W
    have g3 : p2 = Rel (.out i) ∨ p2 = Rel .dflt ∨ p2 = Rel (.out (!i)) := by
      by_contra hc
      exact hp2U ((sUH_iff i p2).mpr ⟨g1.1, hc⟩)
    have hp2N : p2 = Rel .dflt ∨ p2 = Rel (.out (!i)) := by
      rcases g3 with h | h | h
      · exact absurd (Or.inr h) g1.2
      · exact Or.inl h
      · exact Or.inr h
    have hblock : ∀ c : Fin M, S.carrier (Om.h (!i) c) := by
      obtain ⟨K, hK, hSK⟩ := (hp1g ▸ hp1C.1 : ActG (Sg hM hL τ) S (grd (.H (!i))))
      rw [Sg_inv_grdH hK rfl] at hSK
      exact fun c => hSK _ ⟨c, rfl⟩
    have hsrc : ∃ α : Fin M, S.carrier (Om.h i α) := by
      rcases hp2N with h | h
      · obtain ⟨K, hK, hSK⟩ := (h ▸ hp2C.1 : ActG (Sg hM hL τ) S (Rel .dflt))
        obtain ⟨a, b, rfl⟩ := Sg_inv_relDflt hK rfl
        cases i
        · exact ⟨a, hSK _ (Or.inl rfl)⟩
        · exact ⟨b, hSK _ (Or.inr rfl)⟩
      · obtain ⟨K, hK, hSK⟩ := (h ▸ hp2C.1 : ActG (Sg hM hL τ) S (Rel (.out (!i))))
        obtain ⟨c, rfl⟩ := Sg_inv_relOut hK rfl
        have hnn : (!(!i)) = i := by cases i <;> rfl
        refine ⟨zsucc hM c, ?_⟩
        have hmem := hSK (Om.h (!(!i)) (zsucc hM c)) (Or.inr rfl)
        rw [hnn] at hmem
        exact hmem
    obtain ⟨α, hα⟩ := hsrc
    refine key (Pt.Rel (.out i)) ⟨_, Sg.relOut i α, le_pr hα (hblock (zsucc hM α))⟩ ?_
    rintro (h | h)
    · exact ((sUH_iff i _).mp h).2 (Or.inl rfl)
    · exact ((sVH_iff i _).mp h).2 (Or.inr rfl)
  · -- vertical serial cut
    have h1 := (sUV_iff j p1).mp hp1U
    have h3 : p1 = grd (.V (!j)) ∨ p1 = Sel (.out j) := by
      by_contra hc
      exact hp1W ((sVV_iff j p1).mpr ⟨h1.1, hc⟩)
    have hp1g : p1 = grd (.V (!j)) := by
      rcases h3 with h | h
      · exact h
      · exact absurd (Or.inl h) h1.2
    have g1 := (sVV_iff j p2).mp hp2W
    have g3 : p2 = Sel (.out j) ∨ p2 = Sel .dflt ∨ p2 = Sel (.out (!j)) := by
      by_contra hc
      exact hp2U ((sUV_iff j p2).mpr ⟨g1.1, hc⟩)
    have hp2N : p2 = Sel .dflt ∨ p2 = Sel (.out (!j)) := by
      rcases g3 with h | h | h
      · exact absurd (Or.inr h) g1.2
      · exact Or.inl h
      · exact Or.inr h
    have hblock : ∀ c : Fin L, S.carrier (Om.v (!j) c) := by
      obtain ⟨K, hK, hSK⟩ := (hp1g ▸ hp1C.1 : ActG (Sg hM hL τ) S (grd (.V (!j))))
      rw [Sg_inv_grdV hK rfl] at hSK
      exact fun c => hSK _ ⟨c, rfl⟩
    have hsrc : ∃ β : Fin L, S.carrier (Om.v j β) := by
      rcases hp2N with h | h
      · obtain ⟨K, hK, hSK⟩ := (h ▸ hp2C.1 : ActG (Sg hM hL τ) S (Sel .dflt))
        obtain ⟨a, b, rfl⟩ := Sg_inv_selDflt hK rfl
        cases j
        · exact ⟨a, hSK _ (Or.inl rfl)⟩
        · exact ⟨b, hSK _ (Or.inr rfl)⟩
      · obtain ⟨K, hK, hSK⟩ := (h ▸ hp2C.1 : ActG (Sg hM hL τ) S (Sel (.out (!j))))
        obtain ⟨c, rfl⟩ := Sg_inv_selOut hK rfl
        have hnn : (!(!j)) = j := by cases j <;> rfl
        refine ⟨zsucc hL c, ?_⟩
        have hmem := hSK (Om.v (!(!j)) (zsucc hL c)) (Or.inr rfl)
        rw [hnn] at hmem
        exact hmem
    obtain ⟨β, hβ⟩ := hsrc
    refine key (Pt.Sel (.out j)) ⟨_, Sg.selOut j β, le_pr hβ (hblock (zsucc hL β))⟩ ?_
    rintro (h | h)
    · exact ((sUV_iff j _).mp h).2 (Or.inl rfl)
    · exact ((sVV_iff j _).mp h).2 (Or.inr rfl)
  · -- horizontal compatibility cut
    have h1 := (cUH_iff i j t p1).mp hp1U
    have h3 : p1 = Rel (.out i) ∨ p1 = shd (.H i) ∨ p1 = grd (.H i) ∨ GH cw ce i j t p1 := by
      by_contra hc
      exact hp1W ((cVH_iff i j t p1).mpr ⟨h1.1, hc⟩)
    have hp1R : p1 = Rel (.out i) := by
      rcases h3 with h | h | h | h
      · exact h
      · exact absurd (Or.inr (Or.inl h)) h1.2
      · exact absurd (Or.inr (Or.inr (Or.inl h))) h1.2
      · exact absurd (Or.inr (Or.inr (Or.inr h))) h1.2
    have g1 := (cVH_iff i j t p2).mp hp2W
    have g3 : p2 = Tl i j t ∨ p2 = shd (.H i) ∨ p2 = grd (.H i) ∨ GH cw ce i j t p2 := by
      by_contra hc
      exact hp2U ((cUH_iff i j t p2).mpr ⟨g1.1, hc⟩)
    have hp2T : p2 = Tl i j t := by
      rcases g3 with h | h | h | h
      · exact h
      · exact absurd (Or.inr (Or.inl h)) g1.2
      · exact absurd (Or.inr (Or.inr (Or.inl h))) g1.2
      · exact absurd (Or.inr (Or.inr (Or.inr h))) g1.2
    obtain ⟨K1, hK1, hS1⟩ := (hp1R ▸ hp1C.1 : ActG (Sg hM hL τ) S (Rel (.out i)))
    obtain ⟨α, rfl⟩ := Sg_inv_relOut hK1 rfl
    obtain ⟨K2, hK2, hS2⟩ := (hp2T ▸ hp2C.1 : ActG (Sg hM hL τ) S (Tl i j t))
    obtain ⟨γ, β, hγβ, rfl⟩ := Sg_inv_tile hK2 rfl
    have hα : S.carrier (Om.h i α) := hS1 _ (Or.inl rfl)
    have hα' : S.carrier (Om.h (!i) (zsucc hM α)) := hS1 _ (Or.inr rfl)
    have hγ : S.carrier (Om.h i γ) := hS2 _ (Or.inl rfl)
    have hβ : S.carrier (Om.v j β) := hS2 _ (Or.inr rfl)
    by_cases hαγ : α = γ
    · subst hαγ
      refine key (Pt.Tl (!i) j (τ.tile (zsucc hM α).val β.val))
        ⟨_, Sg.tile (!i) j (zsucc hM α) β, le_pr hα' hβ⟩ ?_
      have hcomp : ce t = cw (τ.tile (zsucc hM α).val β.val) := by
        rw [← hγβ, τ.congrH (zsucc_mod hM τ.m τ.hm hdM α) β.val]
        exact τ.matchH α.val β.val
      have hGmem : GH cw ce i j t (Pt.Tl (!i) j (τ.tile (zsucc hM α).val β.val)) :=
        ⟨_, rfl, hcomp⟩
      rintro (h | h)
      · exact ((cUH_iff i j t _).mp h).2 (Or.inr (Or.inr (Or.inr hGmem)))
      · exact ((cVH_iff i j t _).mp h).2 (Or.inr (Or.inr (Or.inr hGmem)))
    · refine key (Pt.shd (.H i)) ⟨_, Sg.shdH i α γ hαγ, le_pr hα hγ⟩ ?_
      rintro (h | h)
      · exact ((cUH_iff i j t _).mp h).2 (Or.inr (Or.inl rfl))
      · exact ((cVH_iff i j t _).mp h).2 (Or.inr (Or.inl rfl))
  · -- vertical compatibility cut
    have h1 := (cUV_iff i j t p1).mp hp1U
    have h3 : p1 = Sel (.out j) ∨ p1 = shd (.V j) ∨ p1 = grd (.V j) ∨ GV cs cn i j t p1 := by
      by_contra hc
      exact hp1W ((cVV_iff i j t p1).mpr ⟨h1.1, hc⟩)
    have hp1S : p1 = Sel (.out j) := by
      rcases h3 with h | h | h | h
      · exact h
      · exact absurd (Or.inr (Or.inl h)) h1.2
      · exact absurd (Or.inr (Or.inr (Or.inl h))) h1.2
      · exact absurd (Or.inr (Or.inr (Or.inr h))) h1.2
    have g1 := (cVV_iff i j t p2).mp hp2W
    have g3 : p2 = Tl i j t ∨ p2 = shd (.V j) ∨ p2 = grd (.V j) ∨ GV cs cn i j t p2 := by
      by_contra hc
      exact hp2U ((cUV_iff i j t p2).mpr ⟨g1.1, hc⟩)
    have hp2T : p2 = Tl i j t := by
      rcases g3 with h | h | h | h
      · exact h
      · exact absurd (Or.inr (Or.inl h)) g1.2
      · exact absurd (Or.inr (Or.inr (Or.inl h))) g1.2
      · exact absurd (Or.inr (Or.inr (Or.inr h))) g1.2
    obtain ⟨K1, hK1, hS1⟩ := (hp1S ▸ hp1C.1 : ActG (Sg hM hL τ) S (Sel (.out j)))
    obtain ⟨β0, rfl⟩ := Sg_inv_selOut hK1 rfl
    obtain ⟨K2, hK2, hS2⟩ := (hp2T ▸ hp2C.1 : ActG (Sg hM hL τ) S (Tl i j t))
    obtain ⟨γ, β, hγβ, rfl⟩ := Sg_inv_tile hK2 rfl
    have hβ0 : S.carrier (Om.v j β0) := hS1 _ (Or.inl rfl)
    have hβ0' : S.carrier (Om.v (!j) (zsucc hL β0)) := hS1 _ (Or.inr rfl)
    have hγ : S.carrier (Om.h i γ) := hS2 _ (Or.inl rfl)
    have hβ : S.carrier (Om.v j β) := hS2 _ (Or.inr rfl)
    by_cases hb : β0 = β
    · subst hb
      refine key (Pt.Tl i (!j) (τ.tile γ.val (zsucc hL β0).val))
        ⟨_, Sg.tile i (!j) γ (zsucc hL β0), le_pr hγ hβ0'⟩ ?_
      have hcomp : cn t = cs (τ.tile γ.val (zsucc hL β0).val) := by
        rw [← hγβ, τ.congrV γ.val (zsucc_mod hL τ.l τ.hl hdL β0)]
        exact τ.matchV γ.val β0.val
      have hGmem : GV cs cn i j t (Pt.Tl i (!j) (τ.tile γ.val (zsucc hL β0).val)) :=
        ⟨_, rfl, hcomp⟩
      rintro (h | h)
      · exact ((cUV_iff i j t _).mp h).2 (Or.inr (Or.inr (Or.inr hGmem)))
      · exact ((cVV_iff i j t _).mp h).2 (Or.inr (Or.inr (Or.inr hGmem)))
    · refine key (Pt.shd (.V j)) ⟨_, Sg.shdV j β0 β hb, le_pr hβ0 hβ⟩ ?_
      rintro (h | h)
      · exact ((cUV_iff i j t _).mp h).2 (Or.inr (Or.inl rfl))
      · exact ((cVV_iff i j t _).mp h).2 (Or.inr (Or.inl rfl))

end ZCDCsec


/-! ## Proposition 9.4 -/

/-- **Proposition 9.4** (Completeness).  If `W` has a finite torus tiling using every tile
of `W`, then `E(P_W, D_W)` holds.

The carrier is `Ω = H₀ ⊔ H₁ ⊔ V₀ ⊔ V₁` with `|H_i| = 3m` and `|V_j| = 3ℓ`; the factor `3`
is what makes the two successor matchings disjoint and leaves room for default pairs. -/
theorem prop_9_4 {T C : Type} [FinE T] {cw ce cs cn : T → C}
    (τ : TorusTiling cw ce cs cn) (hsurj : τ.Surjective) :
    EPD (Pt T) (DW cw ce cs cn) := by
  have hm := τ.hm
  have hl := τ.hl
  have hM : 0 < 3 * τ.m := by omega
  have hL : 0 < 3 * τ.l := by omega
  have hM3 : 3 ≤ 3 * τ.m := by omega
  have hL3 : 3 ≤ 3 * τ.l := by omega
  have hmM : τ.m ≤ 3 * τ.m := by omega
  have hlL : τ.l ≤ 3 * τ.l := by omega
  have hdM : ∃ c, 3 * τ.m = τ.m * c := ⟨3, by omega⟩
  have hdL : ∃ c, 3 * τ.l = τ.l * c := ⟨3, by omega⟩
  obtain ⟨f, hpem, honto, hcone, hf⟩ :=
    support_realization (Sg hM hL τ)
      (fun q => Sg_exists (by omega) (by omega) hmM hlL hsurj q)
      (fun p H hH => calibration hM3 hL3 hmM hlL hsurj hH)
  refine ⟨Om (3 * τ.m) (3 * τ.l), instFinEOm _ _, ⟨Om.h false ⟨0, hM⟩⟩, f, hpem, honto, ?_,
          zcdc_holds hdM hdL hcone⟩
  intro S
  obtain ⟨w, hw⟩ := S.ne
  refine ⟨Face.pt w, Face.le_pt hw, ?_⟩
  cases w with
  | h i a => exact ⟨_, (hf _ _).mpr (calibration hM3 hL3 hmM hlL hsurj (Sg.rolH i a))⟩
  | v j b => exact ⟨_, (hf _ _).mpr (calibration hM3 hL3 hmM hlL hsurj (Sg.rolV j b))⟩

end MU
