/-
# Core infrastructure

Self-contained support library for the formalisation of
*Notes on undecidability of Medvedev's logic*.

This file depends only on the **Lean 4 core library** — no Mathlib, no Batteries.
(The build environment for this session has no access to Mathlib's build cache, and
building Mathlib from source on the available hardware is not feasible, so the whole
development is written against `Init` only.)

Everything here is classical: `Classical.choice`, `propext` and `funext` are used freely.
-/

set_option linter.unusedVariables false
set_option linter.unusedSectionVars false

universe u v w

namespace MU

/-! ## A few tactics that live in Mathlib, re-derived from core -/

/-- Proof by contradiction. (Mathlib's `by_contra`, rebuilt from `Classical.byContradiction`.) -/
macro "by_contra " h:ident : tactic =>
  `(tactic| (refine Classical.byContradiction ?_
             intro $h:ident))

/-! ## Sets, as predicates -/

/-- A subset of `α`, represented as a predicate. -/
def Set (α : Type u) : Type u := α → Prop

namespace Set

variable {α : Type u}

instance : Membership α (Set α) := ⟨fun s a => s a⟩

@[simp] theorem mem_def {s : Set α} {a : α} : (a ∈ s) = s a := rfl

/-- Extensionality for sets. -/
theorem ext {s t : Set α} (h : ∀ a, s a ↔ t a) : s = t :=
  funext fun a => propext (h a)

def univ : Set α := fun _ => True
def emptySet : Set α := fun _ => False
def union (s t : Set α) : Set α := fun a => s a ∨ t a
def inter (s t : Set α) : Set α := fun a => s a ∧ t a
def diff (s t : Set α) : Set α := fun a => s a ∧ ¬ t a
def compl (s : Set α) : Set α := fun a => ¬ s a
def sing (a : α) : Set α := fun b => b = a
def pair (a b : α) : Set α := fun c => c = a ∨ c = b
def Subset (s t : Set α) : Prop := ∀ a, s a → t a

end Set

open Set

/-- Set union. -/
infixl:65 " ∪ᵈ " => Set.union
/-- Set intersection. -/
infixl:70 " ∩ᵈ " => Set.inter
/-- Set difference. -/
infixl:70 " \\ᵈ " => Set.diff
/-- Set inclusion. -/
infix:50 " ⊆ᵈ " => Set.Subset

/-! ## Finite types

We record finiteness by an explicit exhaustive list. This is all the finiteness we ever
need, and it keeps every argument constructive-in-shape and Mathlib-free.
-/

/-- `α` is finite: there is a list containing every element. -/
class FinE (α : Type u) where
  elems : List α
  complete : ∀ a : α, a ∈ elems

/-! ## Subtypes of a finite type are finite -/

theorem exists_subElems {V : Type} (p : V → Prop) : ∀ l : List V,
    ∃ l' : List {a : V // p a}, ∀ (a : V) (h : p a), a ∈ l → (⟨a, h⟩ : {x // p x}) ∈ l' := by
  intro l
  induction l with
  | nil => exact ⟨[], by intro a h hm; simp at hm⟩
  | cons b t ih =>
    obtain ⟨l', hl'⟩ := ih
    by_cases hb : p b
    · refine ⟨⟨b, hb⟩ :: l', ?_⟩
      intro a h hm
      rcases List.mem_cons.mp hm with rfl | hm'
      · exact List.mem_cons.mpr (Or.inl rfl)
      · exact List.mem_cons.mpr (Or.inr (hl' a h hm'))
    · refine ⟨l', ?_⟩
      intro a h hm
      rcases List.mem_cons.mp hm with rfl | hm'
      · exact absurd h hb
      · exact hl' a h hm'

noncomputable instance finE_subtype {V : Type} [FinE V] (p : V → Prop) :
    FinE {a : V // p a} :=
  Classical.choice (by
    obtain ⟨l', hl'⟩ := exists_subElems p (FinE.elems : List V)
    exact ⟨⟨l', fun a => hl' a.val a.property (FinE.complete a.val)⟩⟩)

/-! ## Pigeonhole -/

/-- **Pigeonhole.** Any `Nat`-indexed family of elements of a list repeats. -/
theorem pigeonhole {α : Type u} :
    ∀ (l : List α) (f : Nat → α), (∀ n, f n ∈ l) → ∃ i j, i < j ∧ f i = f j := by
  intro l
  induction l with
  | nil =>
    intro f h
    exact absurd (h 0) (by simp)
  | cons a t ih =>
    intro f h
    by_cases htwice : ∃ i j, i < j ∧ f i = a ∧ f j = a
    · obtain ⟨i, j, hij, hi, hj⟩ := htwice
      exact ⟨i, j, hij, by rw [hi, hj]⟩
    · by_cases hex : ∃ n, f n = a
      · obtain ⟨k, hk⟩ := hex
        have hgt : ∀ n, k < n → f n ≠ a := fun n hn hfn => htwice ⟨k, n, hn, hk, hfn⟩
        have h' : ∀ n, f (k + 1 + n) ∈ t := by
          intro n
          rcases List.mem_cons.mp (h (k + 1 + n)) with h1 | h1
          · exact absurd h1 (hgt _ (by omega))
          · exact h1
        obtain ⟨i, j, hij, hfe⟩ := ih (fun n => f (k + 1 + n)) h'
        exact ⟨k + 1 + i, k + 1 + j, by omega, hfe⟩
      · have hne : ∀ n, f n ≠ a := fun n hn => hex ⟨n, hn⟩
        refine ih f ?_
        intro n
        rcases List.mem_cons.mp (h n) with h1 | h1
        · exact absurd h1 (hne n)
        · exact h1

theorem FinE.exists_repeat {α : Type u} [FinE α] (f : Nat → α) :
    ∃ i j, i < j ∧ f i = f j :=
  pigeonhole FinE.elems f (fun n => FinE.complete (f n))

/-! ## Iteration -/

/-- `iter g n x = gⁿ(x)`. -/
def iter {α : Type u} (g : α → α) : Nat → α → α
  | 0,     x => x
  | n + 1, x => g (iter g n x)

theorem iter_add {α : Type u} (g : α → α) (m n : Nat) (x : α) :
    iter g (m + n) x = iter g n (iter g m x) := by
  induction n with
  | zero => rfl
  | succ k ih => show g (iter g (m + k) x) = g (iter g k (iter g m x)); rw [ih]

/-- Any self-map of a finite type has a periodic point inside any forward-invariant
nonempty subset. -/
theorem exists_periodic_in {α : Type u} [FinE α] (g : α → α) (Q : Set α)
    (hg : ∀ x, Q x → Q (g x)) (x₀ : α) (hx₀ : Q x₀) :
    ∃ (x : α) (k : Nat), 0 < k ∧ Q x ∧ iter g k x = x := by
  obtain ⟨i, j, hij, he⟩ := FinE.exists_repeat (fun n => iter g n x₀)
  have hQ : ∀ n, Q (iter g n x₀) := by
    intro n
    induction n with
    | zero => exact hx₀
    | succ k ih => exact hg _ ih
  refine ⟨iter g i x₀, j - i, by omega, hQ i, ?_⟩
  have h1 : i + (j - i) = j := by omega
  calc iter g (j - i) (iter g i x₀) = iter g (i + (j - i)) x₀ := (iter_add g i (j - i) x₀).symm
    _ = iter g j x₀ := by rw [h1]
    _ = iter g i x₀ := he.symm

/-! ## Posets -/

/-- A partial order, spelled out so that we do not need Mathlib's order hierarchy. -/
class Poset (α : Type u) extends LE α where
  le_refl : ∀ a : α, a ≤ a
  le_trans : ∀ {a b c : α}, a ≤ b → b ≤ c → a ≤ c
  le_antisymm : ∀ {a b : α}, a ≤ b → b ≤ a → a = b

namespace Poset

variable {α : Type u} [Poset α]

/-- Strict order. -/
def lt (a b : α) : Prop := a ≤ b ∧ a ≠ b

instance : LT α := ⟨lt⟩

theorem lt_iff {a b : α} : a < b ↔ (a ≤ b ∧ a ≠ b) := Iff.rfl

theorem le_of_lt {a b : α} (h : a < b) : a ≤ b := h.1

theorem ne_of_lt {a b : α} (h : a < b) : a ≠ b := h.2

theorem lt_trans {a b c : α} (h₁ : a < b) (h₂ : b < c) : a < c := by
  refine ⟨le_trans h₁.1 h₂.1, ?_⟩
  intro hac
  exact h₂.2 (le_antisymm h₂.1 (hac ▸ h₁.1))

theorem lt_irrefl (a : α) : ¬ (a < a) := fun h => h.2 rfl

/-- No infinite strictly descending chain in a finite poset. -/
theorem no_descent {α : Type u} [Poset α] [FinE α] (f : Nat → α)
    (hd : ∀ n, f (n + 1) < f n) : False := by
  have key : ∀ i j, i < j → f j < f i := by
    intro i j hij
    induction j with
    | zero => omega
    | succ k ih =>
      by_cases hk : i < k
      · exact lt_trans (hd k) (ih hk)
      · have hik : i = k := by omega
        subst hik
        exact hd i
  obtain ⟨i, j, hij, he⟩ := FinE.exists_repeat f
  exact (key i j hij).2 he.symm

end Poset

open Poset

/-! ## Upsets, antichains, minimal and maximal points -/

section Order

variable {α : Type u} [Poset α]

/-- The principal upset `↑p`. -/
def up (p : α) : Set α := fun q => p ≤ q

/-- The principal downset `↓p`. -/
def dn (p : α) : Set α := fun q => q ≤ p

def IsUpset (A : Set α) : Prop := ∀ x y, A x → x ≤ y → A y

def IsDownset (A : Set α) : Prop := ∀ x y, A x → y ≤ x → A y

def IsAntichain (A : Set α) : Prop := ∀ x y, A x → A y → x ≤ y → x = y

theorem isUpset_up (p : α) : IsUpset (up p) := fun _ _ h hxy => Poset.le_trans h hxy

theorem isUpset_union {A B : Set α} (hA : IsUpset A) (hB : IsUpset B) : IsUpset (A ∪ᵈ B) := by
  intro x y hx hxy
  rcases hx with h | h
  · exact Or.inl (hA x y h hxy)
  · exact Or.inr (hB x y h hxy)

/-- `p` is a minimal element of `A`. -/
def Minimal (A : Set α) (p : α) : Prop := A p ∧ ∀ q, A q → q ≤ p → q = p

/-- `p` is a maximal element of `A`. -/
def Maximal (A : Set α) (p : α) : Prop := A p ∧ ∀ q, A q → p ≤ q → q = p

/-- The set of minimal points of `A`, written `min A` in the paper. -/
def minSet (A : Set α) : Set α := Minimal A

/-- The set of maximal points of `A`, written `Max A` in the paper. -/
def maxSet (A : Set α) : Set α := Maximal A

theorem minSet_antichain (A : Set α) : IsAntichain (minSet A) := by
  intro x y hx hy hxy
  exact hy.2 x hx.1 hxy

theorem minSet_sub (A : Set α) : minSet A ⊆ᵈ A := fun _ h => h.1

variable [FinE α]

/-- In a finite poset every element of `A` lies above a minimal element of `A`. -/
theorem exists_minimal_le {A : Set α} {p : α} (hp : A p) : ∃ q, Minimal A q ∧ q ≤ p := by
  by_contra hcon
  have hstep : ∀ x : α, A x → x ≤ p → ∃ y, (A y ∧ y ≤ p) ∧ y ≤ x ∧ y ≠ x := by
    intro x hx hxp
    by_cases hmin : Minimal A x
    · exact absurd ⟨x, hmin, hxp⟩ hcon
    · have hnall : ¬ ∀ q, A q → q ≤ x → q = x := fun h => hmin ⟨hx, h⟩
      have hex : ∃ q, A q ∧ q ≤ x ∧ q ≠ x := by
        by_contra h2
        exact hnall (fun q hq hqx => by
          by_contra hne
          exact h2 ⟨q, hq, hqx, hne⟩)
      obtain ⟨q, hq, hqx, hne⟩ := hex
      exact ⟨q, ⟨hq, Poset.le_trans hqx hxp⟩, hqx, hne⟩
  have hS : ∀ s : {x : α // A x ∧ x ≤ p},
      ∃ t : {x : α // A x ∧ x ≤ p}, t.val ≤ s.val ∧ t.val ≠ s.val := by
    intro s
    obtain ⟨y, hy, hyx, hne⟩ := hstep s.val s.property.1 s.property.2
    exact ⟨⟨y, hy⟩, hyx, hne⟩
  let nxt : {x : α // A x ∧ x ≤ p} → {x : α // A x ∧ x ≤ p} := fun s => Classical.choose (hS s)
  have hnxt : ∀ s, (nxt s).val ≤ s.val ∧ (nxt s).val ≠ s.val := fun s => Classical.choose_spec (hS s)
  let c : Nat → {x : α // A x ∧ x ≤ p} :=
    fun n => Nat.rec (⟨p, hp, Poset.le_refl p⟩ : {x : α // A x ∧ x ≤ p}) (fun _ s => nxt s) n
  exact Poset.no_descent (fun n => (c n).val) (fun n => hnxt (c n))

/-- In a finite poset every element of `A` lies below a maximal element of `A`. -/
theorem exists_maximal_ge {A : Set α} {p : α} (hp : A p) : ∃ q, Maximal A q ∧ p ≤ q := by
  by_contra hcon
  have hstep : ∀ x : α, A x → p ≤ x → ∃ y, (A y ∧ p ≤ y) ∧ x ≤ y ∧ y ≠ x := by
    intro x hx hpx
    by_cases hmax : Maximal A x
    · exact absurd ⟨x, hmax, hpx⟩ hcon
    · have hnall : ¬ ∀ q, A q → x ≤ q → q = x := fun h => hmax ⟨hx, h⟩
      have hex : ∃ q, A q ∧ x ≤ q ∧ q ≠ x := by
        by_contra h2
        exact hnall (fun q hq hqx => by
          by_contra hne
          exact h2 ⟨q, hq, hqx, hne⟩)
      obtain ⟨q, hq, hxq, hne⟩ := hex
      exact ⟨q, ⟨hq, Poset.le_trans hpx hxq⟩, hxq, hne⟩
  have hS : ∀ s : {x : α // A x ∧ p ≤ x},
      ∃ t : {x : α // A x ∧ p ≤ x}, s.val ≤ t.val ∧ t.val ≠ s.val := by
    intro s
    obtain ⟨y, hy, hxy, hne⟩ := hstep s.val s.property.1 s.property.2
    exact ⟨⟨y, hy⟩, hxy, hne⟩
  let nxt : {x : α // A x ∧ p ≤ x} → {x : α // A x ∧ p ≤ x} := fun s => Classical.choose (hS s)
  have hnxt : ∀ s, s.val ≤ (nxt s).val ∧ (nxt s).val ≠ s.val := fun s => Classical.choose_spec (hS s)
  let c : Nat → {x : α // A x ∧ p ≤ x} :=
    fun n => Nat.rec (⟨p, hp, Poset.le_refl p⟩ : {x : α // A x ∧ p ≤ x}) (fun _ s => nxt s) n
  -- the chain descends in the opposite order; reuse `no_descent` on the reversed order
  have key : ∀ i j, i < j → (c i).val < (c j).val := by
    intro i j hij
    induction j with
    | zero => omega
    | succ k ih =>
      by_cases hk : i < k
      · exact Poset.lt_trans (ih hk) ⟨(hnxt (c k)).1, fun h => (hnxt (c k)).2 h.symm⟩
      · have hik : i = k := by omega
        subst hik
        exact ⟨(hnxt (c i)).1, fun h => (hnxt (c i)).2 h.symm⟩
  obtain ⟨i, j, hij, he⟩ := FinE.exists_repeat (fun n => (c n).val)
  exact (key i j hij).2 he

/-- **Outside-point principle** (Lemma 9.3 of the paper, in general form).
If some point of `A` lies outside an upset `W`, then some *minimal* point of `A` does. -/
theorem outside_minimal {A W : Set α} (hW : IsUpset W) {q : α} (hq : A q) (hqW : ¬ W q) :
    ∃ p, Minimal A p ∧ ¬ W p := by
  obtain ⟨p, hpm, hpq⟩ := exists_minimal_le hq
  exact ⟨p, hpm, fun hp => hqW (hW p q hp hpq)⟩

end Order

end MU
