/-
# Medvedev frames, partial Esakia morphisms, and the criterion `E(P,D)`

Formalises §2, §3 and §5 of the paper.

The Medvedev frame `M_n = (P*([n]), ⊇)` is realised as `Face V` for a finite nonempty
carrier `V`: the nonempty subsets of `V`, ordered by **reverse inclusion**.  (Taking an
abstract finite carrier rather than `Fin n` is harmless: any bijection `V ≃ Fin n` induces
an isomorphism `M_V ≅ M_n`, and every notion below is defined purely order-theoretically.)
-/

import MedvedevUndecidability.Core

set_option linter.unusedVariables false
set_option linter.unusedSectionVars false

universe u v w

namespace MU

/-! ## Faces -/

/-- A point of the Medvedev frame over `V`: a nonempty subset of `V`. -/
structure Face (V : Type u) where
  carrier : Set V
  ne : ∃ a, carrier a

namespace Face

variable {V : Type u}

theorem eq_of_carrier_eq : ∀ {S T : Face V}, S.carrier = T.carrier → S = T
  | ⟨_, _⟩, ⟨_, _⟩, h => by subst h; rfl

/-- `S ≤ T` in the Medvedev frame means `S ⊇ T`. -/
instance instPoset : Poset (Face V) where
  le S T := ∀ a, T.carrier a → S.carrier a
  le_refl := fun _ _ h => h
  le_trans := fun h₁ h₂ a ha => h₁ a (h₂ a ha)
  le_antisymm := fun {S T} h₁ h₂ =>
    eq_of_carrier_eq (Set.ext fun a => ⟨fun h => h₂ a h, fun h => h₁ a h⟩)

theorem le_def {S T : Face V} : S ≤ T ↔ ∀ a, T.carrier a → S.carrier a := Iff.rfl

/-- The singleton face `{a}`. -/
def pt (a : V) : Face V := ⟨fun b => b = a, ⟨a, rfl⟩⟩

@[simp] theorem pt_carrier (a b : V) : (pt a).carrier b ↔ b = a := Iff.rfl

/-- Every singleton lies above every face containing the point. -/
theorem le_pt {S : Face V} {a : V} (h : S.carrier a) : S ≤ pt a := by
  intro b hb
  cases hb
  exact h

theorem pt_le {a : V} {S : Face V} (h : pt a ≤ S) : ∀ b, S.carrier b → b = a := fun b hb => h b hb

/-- The two-element face `{a,b}`. -/
def pr (a b : V) : Face V := ⟨fun c => c = a ∨ c = b, ⟨a, Or.inl rfl⟩⟩

@[simp] theorem pr_carrier (a b c : V) : (pr a b).carrier c ↔ (c = a ∨ c = b) := Iff.rfl

theorem pr_comm (a b : V) : pr a b = pr b a :=
  eq_of_carrier_eq (Set.ext fun _ => ⟨fun h => h.symm, fun h => h.symm⟩)

/-- Adjoining a point to a face. -/
def cons (a : V) (S : Face V) : Face V := ⟨fun c => c = a ∨ S.carrier c, ⟨a, Or.inl rfl⟩⟩

@[simp] theorem cons_carrier (a : V) (S : Face V) (c : V) :
    (cons a S).carrier c ↔ (c = a ∨ S.carrier c) := Iff.rfl

end Face

/-! ## Partial maps and partial Esakia morphisms

We represent a partial map `X ⇀ P` as a total map `X → Option P`. -/

section PEM

variable {X : Type u} [Poset X] {P : Type v} [Poset P]

/-- `x ∈ dom(f)`. -/
def PDom (f : X → Option P) (x : X) : Prop := ∃ p, f x = some p

/-- The image of a set of points under a partial map. -/
def pimg (f : X → Option P) (A : Set X) : Set P := fun p => ∃ x, A x ∧ f x = some p

/-- `f[↑x]`, written `A_f(x)` in §5 of the paper. -/
def coneImg (f : X → Option P) (x : X) : Set P := pimg f (up x)

theorem coneImg_mono {f : X → Option P} {x y : X} (h : x ≤ y) :
    coneImg f y ⊆ᵈ coneImg f x := by
  intro p hp
  obtain ⟨z, hz, hfz⟩ := hp
  exact ⟨z, Poset.le_trans h hz, hfz⟩

theorem self_mem_coneImg {f : X → Option P} {x : X} {p : P} (h : f x = some p) :
    coneImg f x p := ⟨x, Poset.le_refl x, h⟩

/-- **Definition 3.1** (finite form).  Clauses (PE4) and (PE5) are automatic for finite
posets — see `pe4_automatic` and `pe5_automatic` below — so a *partial Esakia morphism*
between finite posets is exactly (PE1)–(PE3). -/
structure IsPEM (f : X → Option P) : Prop where
  /-- (PE1) monotonicity on the domain. -/
  pe1 : ∀ {x z : X} {p q : P}, x ≤ z → f x = some p → f z = some q → p ≤ q
  /-- (PE2) the back condition. -/
  pe2 : ∀ {x : X} {p : P} (q : P), f x = some p → p ≤ q → ∃ z, x ≤ z ∧ f z = some q
  /-- (PE3) the domain is exactly the set of points whose cone image is principal. -/
  pe3 : ∀ {x : X}, PDom f x ↔ ∃ y : P, coneImg f x = up y

namespace IsPEM

variable {f : X → Option P}

/-- On the domain, the cone image is the principal upset of the value. -/
theorem coneImg_eq (hf : IsPEM f) {x : X} {p : P} (hx : f x = some p) :
    coneImg f x = up p := by
  refine Set.ext fun q => ⟨fun hq => ?_, fun hq => ?_⟩
  · obtain ⟨z, hz, hfz⟩ := hq
    exact hf.pe1 hz hx hfz
  · obtain ⟨z, hz, hfz⟩ := hf.pe2 q hx hq
    exact ⟨z, hz, hfz⟩

/-- `A_f(x)` is always an upset (Proposition 5.1(i)). -/
theorem coneImg_isUpset (hf : IsPEM f) (x : X) : IsUpset (coneImg f x) := by
  intro p q hp hpq
  obtain ⟨z, hz, hfz⟩ := hp
  obtain ⟨w, hw, hfw⟩ := hf.pe2 q hfz hpq
  exact ⟨w, Poset.le_trans hz hw, hfw⟩

end IsPEM

/-- `f` is cofinal. -/
def Cofinal (f : X → Option P) : Prop := ∀ x : X, ∃ z, x ≤ z ∧ PDom f z

/-- `f` is onto. -/
def POnto (f : X → Option P) : Prop := ∀ p : P, ∃ x, f x = some p

/-! ### (PE4) and (PE5) are automatic -/

/-- (PE4): on a finite (hence discrete) Esakia space every set is closed. -/
theorem pe4_automatic (f : X → Option P) (x : X) : True := trivial

/-- (PE5): `X \ ↓ f⁻¹(P \ U)` is always an upset, being the complement of a downset.
This is why (PE5) carries no information in the finite case. -/
theorem pe5_automatic (f : X → Option P) (U : Set P) :
    IsUpset (fun x : X => ¬ ∃ z, x ≤ z ∧ ∃ p, f z = some p ∧ ¬ U p) := by
  intro x y hx hxy hy
  obtain ⟨z, hz, hp⟩ := hy
  exact hx ⟨z, Poset.le_trans hxy hz, hp⟩

/-! ### The Zakharyaschev closed-domain condition -/

/-- `𝒟_{U,V}`: the antichains `C ⊆ U ∪ V` meeting both `U \ V` and `V \ U`. -/
def DUV (U W : Set P) (C : Set P) : Prop :=
  IsAntichain C ∧ (∀ p, C p → U p ∨ W p) ∧ (∃ p, C p ∧ U p ∧ ¬ W p) ∧ (∃ p, C p ∧ W p ∧ ¬ U p)

/-- `𝒟_D = ⋃_{(U,W) ∈ D} 𝒟_{U,W}`, for a finite family `D` of pairs of upsets. -/
def DD (D : Set P → Set P → Prop) (C : Set P) : Prop := ∃ U W, D U W ∧ DUV U W C

/-- **Definition 3.2**: `f` satisfies `ZCDC(𝒟_D)`. -/
def ZCDC (f : X → Option P) (D : Set P → Set P → Prop) : Prop :=
  ∀ x : X, ¬ PDom f x → ¬ DD D (minSet (coneImg f x))

end PEM

/-! ## Proposition 5.1: the exact face recurrence -/

section FaceRec

variable {X : Type u} [Poset X] {P : Type v} [Poset P] [FinE P] {f : X → Option P}

theorem minSet_up (p : P) : minSet (up p) = Set.sing p := by
  refine Set.ext fun q => ⟨fun hq => ?_, fun hq => ?_⟩
  · exact (hq.2 p (Poset.le_refl p) hq.1).symm
  · cases hq
    exact ⟨Poset.le_refl p, fun r hr hrp => Poset.le_antisymm hrp hr⟩

theorem up_inj {p q : P} (h : up p = up q) : p = q := by
  have h1 : (up p) q := by rw [h]; exact Poset.le_refl q
  have h2 : (up q) p := by rw [← h]; exact Poset.le_refl p
  exact Poset.le_antisymm h1 h2

/-- A finite upset with a unique minimal point is the principal upset of that point. -/
theorem upset_of_unique_min {A : Set P} (hA : IsUpset A) {p : P}
    (h : minSet A = Set.sing p) : A = up p := by
  refine Set.ext fun q => ⟨fun hq => ?_, fun hq => ?_⟩
  · obtain ⟨m, hm, hmq⟩ := exists_minimal_le hq
    have : (minSet A) m := hm
    rw [h] at this
    cases this
    exact hmq
  · have hp : A p := by
      have : (minSet A) p := by rw [h]; rfl
      exact this.1
    exact hA p q hp hq

/-- **Proposition 5.1(ii)**: `S ∈ dom(f)` exactly when `λ_f(S)` is a singleton, and then
`f(S)` is its unique element. -/
theorem prop51_ii (hf : IsPEM f) (x : X) :
    PDom f x ↔ ∃ p, minSet (coneImg f x) = Set.sing p := by
  constructor
  · intro ⟨p, hp⟩
    exact ⟨p, by rw [hf.coneImg_eq hp, minSet_up]⟩
  · intro ⟨p, hp⟩
    have := upset_of_unique_min (hf.coneImg_isUpset x) hp
    exact hf.pe3.mpr ⟨p, this⟩

theorem prop51_ii_val (hf : IsPEM f) {x : X} {p : P}
    (hp : minSet (coneImg f x) = Set.sing p) (hx : PDom f x) : f x = some p := by
  obtain ⟨q, hq⟩ := hx
  have h1 : coneImg f x = up q := hf.coneImg_eq hq
  rw [h1, minSet_up] at hp
  have : p = q := by
    have : (Set.sing q) p := by rw [hp]; rfl
    exact this
  rw [hq, this]

/-- **Proposition 5.1(iv)**: for `S ∉ dom(f)`, ZCDC is exactly the requirement
`λ_f(S) ∉ 𝒟_D`. -/
theorem prop51_iv (D : Set P → Set P → Prop) :
    ZCDC f D ↔ ∀ x, ¬ PDom f x → ¬ DD D (minSet (coneImg f x)) := Iff.rfl

end FaceRec

/-! ## The criterion `E(P,D)` -/

/-- `E(P,D)`: for some `n ≥ 1` there is an onto cofinal partial Esakia morphism
`M_n ⇀ P` satisfying all the closed-domain conditions coming from `D`.

(Definition just before Corollary 4.2 of the paper.) -/
def EPD (P : Type v) [Poset P] (D : Set P → Set P → Prop) : Prop :=
  ∃ (V : Type) (_ : FinE V) (_ : Nonempty V) (f : Face V → Option P),
    IsPEM f ∧ POnto f ∧ Cofinal f ∧ ZCDC f D

end MU
