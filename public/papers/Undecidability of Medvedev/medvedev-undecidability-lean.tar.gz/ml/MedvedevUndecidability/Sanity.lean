/-
# Non-vacuity checks

A formalisation can be vacuously true if a definition is accidentally unsatisfiable
(then everything about it is provable) or accidentally trivial (then nothing is being
said).  These two checks rule both out for `EPD (Pt T) (DW ...)`:

* `sanity_epd`     — a one-tile set whose colours match does satisfy `E(P_W, D_W)`;
  so the conjunction "partial Esakia morphism + onto + cofinal + `ZCDC(D_W)`" is
  *satisfiable*, hence Soundness (`prop_8_5`) is not vacuous.
* `sanity_not_epd` — a one-tile set whose east colour differs from its west colour does
  *not* satisfy `E(P_W, D_W)`; so `ZCDC(D_W)` genuinely constrains, hence Completeness
  (`prop_9_4`) is not trivial.
-/

import MedvedevUndecidability.Reduction

set_option linter.unusedVariables false
set_option linter.unusedSectionVars false

namespace MU

instance : FinE Unit where
  elems := [()]
  complete := by intro a; cases a; simp

/-! ## A tile set that does tile -/

/-- One tile, all four colours equal: it tiles the `1 × 1` torus. -/
def unitTiling : TorusTiling (fun _ : Unit => ()) (fun _ : Unit => ())
    (fun _ : Unit => ()) (fun _ : Unit => ()) where
  m := 1
  l := 1
  hm := Nat.one_pos
  hl := Nat.one_pos
  tile := fun _ _ => ()
  perH := fun _ _ => rfl
  perV := fun _ _ => rfl
  matchH := fun _ _ => rfl
  matchV := fun _ _ => rfl

theorem unitTiling_surjective : unitTiling.Surjective := by
  intro t
  cases t
  exact ⟨0, 0, rfl⟩

/-- `E(P_W, D_W)` is satisfiable: the whole bundle of conditions in `EPD` (partial Esakia
morphism, onto, cofinal, `ZCDC(D_W)`) has a model. -/
theorem sanity_epd :
    EPD (Pt Unit) (DW (fun _ : Unit => ()) (fun _ : Unit => ())
                      (fun _ : Unit => ()) (fun _ : Unit => ())) :=
  prop_9_4 unitTiling unitTiling_surjective

/-! ## A tile set that does not tile -/

/-- One tile whose east colour differs from its west colour: no torus tiling exists. -/
theorem sanity_no_tiling :
    ¬ HasTorusTiling (fun _ : Unit => false) (fun _ : Unit => true)
                     (fun _ : Unit => false) (fun _ : Unit => false) := by
  rintro ⟨τ⟩
  have h := τ.matchH 0 0
  exact absurd h (by simp)

/-- Consequently `E(P_W, D_W)` fails for that tile set: the closed-domain conditions are
not vacuous. -/
theorem sanity_not_epd :
    ¬ EPD (Pt Unit) (DW (fun _ : Unit => false) (fun _ : Unit => true)
                        (fun _ : Unit => false) (fun _ : Unit => false)) :=
  fun h => sanity_no_tiling (epd_to_tiling h)

end MU
