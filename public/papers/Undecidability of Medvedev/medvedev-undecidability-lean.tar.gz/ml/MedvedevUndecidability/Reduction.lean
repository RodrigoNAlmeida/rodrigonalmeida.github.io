/-
# The undecidability reduction

Formalises Lemma 6.1 and Theorem 10.1 of the paper.

The two results that the paper *cites* rather than proves are kept as explicit hypotheses,
never as `axiom`s, so that every theorem below is unconditionally true of any pair
`(NotML, criterion)` satisfying them:

* `criterion` is Corollary 4.2 of the paper — Bezhanishvili–Bezhanishvili's canonical
  formula criterion (Theorem 3.3) combined with the principal-cone normalization
  (Lemma 4.1).  `NotML P D` reads "the bounded canonical formula `ρ(Up(P), D)` is *not*
  a theorem of Medvedev's logic".

* The undecidability of the periodic domino problem (Gurevich–Koryakov) is *not* used
  here at all: it enters only in the final computability-theoretic step, which this
  development does not formalise (see the README).
-/

import MedvedevUndecidability.Completeness
import MedvedevUndecidability.Normalization

set_option linter.unusedVariables false
set_option linter.unusedSectionVars false

namespace MU

/-! ## Lemma 6.1: passing to the range of a tiling -/

section Lemma61

variable {T C : Type} {cw ce cs cn : T → C}

/-- The colour functions restricted to a subset of the tile set. -/
abbrev resW (cw : T → C) (p : T → Prop) : {t // p t} → C := fun x => cw x.val

/-- A torus tiling by a subset of `W` is in particular a torus tiling by `W`. -/
def TorusTiling.lift {p : T → Prop}
    (τ' : TorusTiling (resW cw p) (resW ce p) (resW cs p) (resW cn p)) :
    TorusTiling cw ce cs cn where
  m := τ'.m
  l := τ'.l
  hm := τ'.hm
  hl := τ'.hl
  tile := fun a b => (τ'.tile a b).val
  perH := fun a b => congrArg Subtype.val (τ'.perH a b)
  perV := fun a b => congrArg Subtype.val (τ'.perV a b)
  matchH := fun a b => τ'.matchH a b
  matchV := fun a b => τ'.matchV a b

/-- **Lemma 6.1** (Surjective range).  A tile set has a finite torus tiling if and only if
some nonempty subset has a finite torus tiling whose range is that whole subset. -/
theorem lemma_6_1 :
    HasTorusTiling cw ce cs cn ↔
      ∃ (p : T → Prop) (τ' : TorusTiling (resW cw p) (resW ce p) (resW cs p) (resW cn p)),
        τ'.Surjective := by
  constructor
  · rintro ⟨τ⟩
    refine ⟨fun t => ∃ a b, τ.tile a b = t, ?_⟩
    refine ⟨{ m := τ.m, l := τ.l, hm := τ.hm, hl := τ.hl,
              tile := fun a b => ⟨τ.tile a b, ⟨a, b, rfl⟩⟩,
              perH := fun a b => Subtype.ext (τ.perH a b),
              perV := fun a b => Subtype.ext (τ.perV a b),
              matchH := fun a b => τ.matchH a b,
              matchV := fun a b => τ.matchV a b }, ?_⟩
    rintro ⟨t, a, b, hab⟩
    exact ⟨a, b, Subtype.ext hab⟩
  · rintro ⟨p, τ', -⟩
    exact ⟨τ'.lift⟩

end Lemma61

/-! ## Theorem 10.1: the tiling equivalence -/

section Reduction

variable {T C : Type} [FinE T] {cw ce cs cn : T → C}

/-- **Proposition 8.5**, unpacked: a witness for `E(P_W, D_W)` yields a torus tiling. -/
theorem epd_to_tiling (h : EPD (Pt T) (DW cw ce cs cn)) : HasTorusTiling cw ce cs cn := by
  obtain ⟨V, instV, hne, f, hpem, honto, hcof, hz⟩ := h
  exact prop_8_5 hpem hcof honto hz

/-- The cited external input, in the shape of **Theorem 3.3** (Bezhanishvili–Bezhanishvili's
canonical-formula criterion), specialised to Medvedev frames.

`NotML P D` reads "the bounded canonical formula `ρ(Up(P), D)` is *not* a theorem of
Medvedev's logic".  The right-hand side is the dual condition of Theorem 3.3: some closed
upset of some Medvedev frame carries an onto cofinal partial Esakia morphism onto `P`
satisfying `ZCDC(𝒟_D)`. -/
def IsCanonicalCriterion
    (NotML : ∀ (P : Type) [Poset P] [FinE P], (Set P → Set P → Prop) → Prop) : Prop :=
  ∀ (P : Type) [Poset P] [FinE P] (r : P), (∀ q, r ≤ q) → ∀ D,
    NotML P D ↔
      ∃ (V : Type) (_ : FinE V) (_ : Nonempty V) (Y : Set (Face V)), IsUpset Y ∧
        ∃ f : {S : Face V // Y S} → Option P, IsPEM f ∧ POnto f ∧ Cofinal f ∧ ZCDC f D

/-- **Corollary 4.2** (Exact Medvedev criterion).  Theorem 3.3 plus the principal-cone
normalization (Lemma 4.1) removes the closed upset from the criterion. -/
theorem corollary_4_2
    {NotML : ∀ (P : Type) [Poset P] [FinE P], (Set P → Set P → Prop) → Prop}
    (hcrit : IsCanonicalCriterion NotML)
    (P : Type) [Poset P] [FinE P] (r : P) (hr : ∀ q, r ≤ q) (D : Set P → Set P → Prop) :
    NotML P D ↔ EPD P D :=
  (hcrit P r hr D).trans (upsetWitness_iff_epd hr D)

/-- **Theorem 10.1** (Tiling equivalence).  For every finite tile set `W`,

  `W ∈ PER  ⟺  ∃ ∅ ≠ W' ⊆ W with ρ_{W'} ∉ ML`. -/
theorem theorem_10_1
    {NotML : ∀ (P : Type) [Poset P] [FinE P], (Set P → Set P → Prop) → Prop}
    (hcrit : IsCanonicalCriterion NotML) :
    HasTorusTiling cw ce cs cn ↔
      ∃ p : T → Prop, (∃ t, p t) ∧
        NotML (Pt {t // p t}) (DW (resW cw p) (resW ce p) (resW cs p) (resW cn p)) := by
  constructor
  · intro h
    obtain ⟨p, τ', hsurj⟩ := lemma_6_1.mp h
    refine ⟨p, ⟨(τ'.tile 0 0).val, (τ'.tile 0 0).property⟩, ?_⟩
    exact (corollary_4_2 hcrit (Pt {t // p t}) Pt.root Pt.root_le _).mpr (prop_9_4 τ' hsurj)
  · rintro ⟨p, hp, hNot⟩
    have hE := (corollary_4_2 hcrit (Pt {t // p t}) Pt.root Pt.root_le _).mp hNot
    obtain ⟨τ'⟩ := epd_to_tiling hE
    exact ⟨τ'.lift⟩

end Reduction

end MU
