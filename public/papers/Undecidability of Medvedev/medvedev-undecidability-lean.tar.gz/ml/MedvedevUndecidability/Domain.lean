/-
# The selected domain `D_W`

Formalises §7.2 (pair-filling cuts), §7.3 (serial cuts), §7.4 (compatibility cuts) and
Lemma 7.1 (legitimacy of the domain).
-/

import MedvedevUndecidability.PosetW

set_option linter.unusedVariables false
set_option linter.unusedSectionVars false

namespace MU

open Pt

/-! ## A general upset criterion

`P° \ F` is an upset as soon as `F` is downward closed inside `P°`.
-/

section Upsets

variable {T : Type}

/-- `P°_W = P_W \ {r}`. -/
def Pcirc : Set (Pt T) := fun p => p ≠ root

theorem upset_compl (F : Set (Pt T)) (hF : ∀ z p, F z → p ≤ z → p ≠ root → F p) :
    IsUpset (fun p => p ≠ root ∧ ¬ F p) := by
  intro p q hp hpq
  refine ⟨fun h => hp.1 (le_root (h ▸ hpq)), fun hq => hp.2 (hF q p hq hpq hp.1)⟩

/-- Singletons of role points are upsets, the role points being maximal. -/
theorem upset_sing_rol (X : Role) : IsUpset (Set.sing (rol X) : Set (Pt T)) := by
  intro p q hp hpq
  have : p = rol X := hp
  subst this
  exact (rol_le hpq).symm ▸ rfl

end Upsets

/-! ## The three families of cuts -/

section Cuts

variable {T C : Type} (cw ce cs cn : T → C)

/-- The six designated role pairs of §7.2. -/
def Desig : Role → Role → Prop := fun X Y =>
  (X = .H false ∧ Y = .H true) ∨ (X = .V false ∧ Y = .V true) ∨
  (∃ i j, X = .H i ∧ Y = .V j)

/-! ### Serial cuts (§7.3) -/

/-- Horizontal nonoutputs for the direction leaving phase `i`: `{R₀₀, R_{out(¬i)}}`. -/
def NH (i : Bool) : Set (Pt T) := fun p => p = Rel .dflt ∨ p = Rel (.out (!i))

/-- Vertical nonoutputs for the direction leaving phase `j`. -/
def NV (j : Bool) : Set (Pt T) := fun p => p = Sel .dflt ∨ p = Sel (.out (!j))

/-- `I = P° \ ({g_Y, Q} ∪ N)`. -/
def sI (gY Q : Pt T) (N : Set (Pt T)) : Set (Pt T) :=
  fun p => p ≠ root ∧ ¬ (p = gY ∨ p = Q ∨ N p)

/-- `U = I ∪ {g_Y}`. -/
def sU (gY Q : Pt T) (N : Set (Pt T)) : Set (Pt T) := fun p => sI gY Q N p ∨ p = gY

/-- `V = I ∪ N`. -/
def sV (gY Q : Pt T) (N : Set (Pt T)) : Set (Pt T) := fun p => sI gY Q N p ∨ N p

/-! ### Compatibility cuts (§7.4) -/

/-- `G^H_{ij,t} = {T_{1-i,j,t'} : e(t) = w(t')}`. -/
def GH (i j : Bool) (t : T) : Set (Pt T) := fun p => ∃ t', p = Tl (!i) j t' ∧ ce t = cw t'

/-- `G^V_{ij,t} = {T_{i,1-j,t'} : n(t) = s(t')}`. -/
def GV (i j : Bool) (t : T) : Set (Pt T) := fun p => ∃ t', p = Tl i (!j) t' ∧ cn t = cs t'

/-- `I^H_{ij,t} = P° \ ({R_i, T_{ij,t}, d_{H_i}, g_{H_i}} ∪ G^H_{ij,t})`. -/
def cIH (i j : Bool) (t : T) : Set (Pt T) := fun p =>
  p ≠ root ∧ ¬ (p = Rel (.out i) ∨ p = Tl i j t ∨ p = shd (.H i) ∨ p = grd (.H i)
                ∨ GH cw ce i j t p)

def cUH (i j : Bool) (t : T) : Set (Pt T) := fun p => cIH cw ce i j t p ∨ p = Rel (.out i)
def cVH (i j : Bool) (t : T) : Set (Pt T) := fun p => cIH cw ce i j t p ∨ p = Tl i j t

/-- `I^V_{ij,t} = P° \ ({S_j, T_{ij,t}, d_{V_j}, g_{V_j}} ∪ G^V_{ij,t})`. -/
def cIV (i j : Bool) (t : T) : Set (Pt T) := fun p =>
  p ≠ root ∧ ¬ (p = Sel (.out j) ∨ p = Tl i j t ∨ p = shd (.V j) ∨ p = grd (.V j)
                ∨ GV cs cn i j t p)

def cUV (i j : Bool) (t : T) : Set (Pt T) := fun p => cIV cs cn i j t p ∨ p = Sel (.out j)
def cVV (i j : Bool) (t : T) : Set (Pt T) := fun p => cIV cs cn i j t p ∨ p = Tl i j t

/-- The selected domain `D_W ⊆ Up(P_W)²`. -/
def DW : Set (Pt T) → Set (Pt T) → Prop := fun U W =>
  (∃ X Y, Desig X Y ∧ U = Set.sing (rol X) ∧ W = Set.sing (rol Y))
  ∨ (∃ i : Bool, U = sU (grd (.H (!i))) (Rel (.out i)) (NH i)
               ∧ W = sV (grd (.H (!i))) (Rel (.out i)) (NH i))
  ∨ (∃ j : Bool, U = sU (grd (.V (!j))) (Sel (.out j)) (NV j)
               ∧ W = sV (grd (.V (!j))) (Sel (.out j)) (NV j))
  ∨ (∃ (i j : Bool) (t : T), U = cUH cw ce i j t ∧ W = cVH cw ce i j t)
  ∨ (∃ (i j : Bool) (t : T), U = cUV cs cn i j t ∧ W = cVV cs cn i j t)

end Cuts

/-! ## Explicit descriptions of the cuts

These are the forms actually used in §8 and §9: the union, and the two "exclusive parts".
-/

section Descriptions

variable {T C : Type} {cw ce cs cn : T → C}

theorem bool_not_ne (i : Bool) : (!i) ≠ i := by cases i <;> simp

/-! ### Serial cuts, horizontal -/

theorem sUH_iff (i : Bool) (p : Pt T) :
    sU (grd (.H (!i))) (Rel (.out i)) (NH i) p ↔
      (p ≠ root ∧ ¬ (p = Rel (.out i) ∨ p = Rel .dflt ∨ p = Rel (.out (!i)))) := by
  constructor
  · rintro (⟨h1, h2⟩ | rfl)
    · exact ⟨h1, fun h => h2 (by rcases h with h | h | h
                                 · exact Or.inr (Or.inl h)
                                 · exact Or.inr (Or.inr (Or.inl h))
                                 · exact Or.inr (Or.inr (Or.inr h)))⟩
    · exact ⟨by simp, by simp⟩
  · intro ⟨h1, h2⟩
    by_cases hg : p = grd (.H (!i))
    · exact Or.inr hg
    · exact Or.inl ⟨h1, by
        rintro (h | h | (h | h))
        · exact hg h
        · exact h2 (Or.inl h)
        · exact h2 (Or.inr (Or.inl h))
        · exact h2 (Or.inr (Or.inr h))⟩

theorem sVH_iff (i : Bool) (p : Pt T) :
    sV (grd (.H (!i))) (Rel (.out i)) (NH i) p ↔
      (p ≠ root ∧ ¬ (p = grd (.H (!i)) ∨ p = Rel (.out i))) := by
  have hne : Rel (.out (!i)) ≠ (Rel (.out i) : Pt T) := by
    intro h; injection h with h; injection h with h; exact bool_not_ne i h
  constructor
  · rintro (⟨h1, h2⟩ | (rfl | rfl))
    · exact ⟨h1, fun h => h2 (by rcases h with h | h
                                 · exact Or.inl h
                                 · exact Or.inr (Or.inl h))⟩
    · exact ⟨by simp, by simp⟩
    · exact ⟨by simp, by simp [hne]⟩
  · intro ⟨h1, h2⟩
    by_cases hN : NH i p
    · exact Or.inr hN
    · exact Or.inl ⟨h1, by
        rintro (h | h | h)
        · exact h2 (Or.inl h)
        · exact h2 (Or.inr h)
        · exact hN h⟩

/-! ### Serial cuts, vertical -/

theorem sUV_iff (j : Bool) (p : Pt T) :
    sU (grd (.V (!j))) (Sel (.out j)) (NV j) p ↔
      (p ≠ root ∧ ¬ (p = Sel (.out j) ∨ p = Sel .dflt ∨ p = Sel (.out (!j)))) := by
  constructor
  · rintro (⟨h1, h2⟩ | rfl)
    · exact ⟨h1, fun h => h2 (by rcases h with h | h | h
                                 · exact Or.inr (Or.inl h)
                                 · exact Or.inr (Or.inr (Or.inl h))
                                 · exact Or.inr (Or.inr (Or.inr h)))⟩
    · exact ⟨by simp, by simp⟩
  · intro ⟨h1, h2⟩
    by_cases hg : p = grd (.V (!j))
    · exact Or.inr hg
    · exact Or.inl ⟨h1, by
        rintro (h | h | (h | h))
        · exact hg h
        · exact h2 (Or.inl h)
        · exact h2 (Or.inr (Or.inl h))
        · exact h2 (Or.inr (Or.inr h))⟩

theorem sVV_iff (j : Bool) (p : Pt T) :
    sV (grd (.V (!j))) (Sel (.out j)) (NV j) p ↔
      (p ≠ root ∧ ¬ (p = grd (.V (!j)) ∨ p = Sel (.out j))) := by
  have hne : Sel (.out (!j)) ≠ (Sel (.out j) : Pt T) := by
    intro h; injection h with h; injection h with h; exact bool_not_ne j h
  constructor
  · rintro (⟨h1, h2⟩ | (rfl | rfl))
    · exact ⟨h1, fun h => h2 (by rcases h with h | h
                                 · exact Or.inl h
                                 · exact Or.inr (Or.inl h))⟩
    · exact ⟨by simp, by simp⟩
    · exact ⟨by simp, by simp [hne]⟩
  · intro ⟨h1, h2⟩
    by_cases hN : NV j p
    · exact Or.inr hN
    · exact Or.inl ⟨h1, by
        rintro (h | h | h)
        · exact h2 (Or.inl h)
        · exact h2 (Or.inr h)
        · exact hN h⟩

/-! ### Compatibility cuts -/

theorem GH_not_Tl_self (i j : Bool) (t : T) : ¬ GH cw ce i j t (Tl i j t) := by
  rintro ⟨t', h, -⟩
  injection h with h1 h2 h3
  exact bool_not_ne i h1.symm

theorem GV_not_Tl_self (i j : Bool) (t : T) : ¬ GV cs cn i j t (Tl i j t) := by
  rintro ⟨t', h, -⟩
  injection h with h1 h2 h3
  exact bool_not_ne j h2.symm

theorem cUH_iff (i j : Bool) (t : T) (p : Pt T) :
    cUH cw ce i j t p ↔
      (p ≠ root ∧ ¬ (p = Tl i j t ∨ p = shd (.H i) ∨ p = grd (.H i) ∨ GH cw ce i j t p)) := by
  constructor
  · rintro (⟨h1, h2⟩ | rfl)
    · exact ⟨h1, fun h => h2 (by rcases h with h | h | h | h
                                 · exact Or.inr (Or.inl h)
                                 · exact Or.inr (Or.inr (Or.inl h))
                                 · exact Or.inr (Or.inr (Or.inr (Or.inl h)))
                                 · exact Or.inr (Or.inr (Or.inr (Or.inr h))))⟩
    · refine ⟨by simp, ?_⟩
      rintro (h | h | h | ⟨t', h, -⟩) <;> simp_all
  · intro ⟨h1, h2⟩
    by_cases hR : p = Rel (.out i)
    · exact Or.inr hR
    · exact Or.inl ⟨h1, by
        rintro (h | h | h | h | h)
        · exact hR h
        · exact h2 (Or.inl h)
        · exact h2 (Or.inr (Or.inl h))
        · exact h2 (Or.inr (Or.inr (Or.inl h)))
        · exact h2 (Or.inr (Or.inr (Or.inr h)))
        ⟩

theorem cVH_iff (i j : Bool) (t : T) (p : Pt T) :
    cVH cw ce i j t p ↔
      (p ≠ root ∧ ¬ (p = Rel (.out i) ∨ p = shd (.H i) ∨ p = grd (.H i) ∨ GH cw ce i j t p)) := by
  constructor
  · rintro (⟨h1, h2⟩ | rfl)
    · exact ⟨h1, fun h => h2 (by rcases h with h | h | h | h
                                 · exact Or.inl h
                                 · exact Or.inr (Or.inr (Or.inl h))
                                 · exact Or.inr (Or.inr (Or.inr (Or.inl h)))
                                 · exact Or.inr (Or.inr (Or.inr (Or.inr h))))⟩
    · refine ⟨by simp, ?_⟩
      rintro (h | h | h | h)
      · simp_all
      · simp_all
      · simp_all
      · exact GH_not_Tl_self i j t h
  · intro ⟨h1, h2⟩
    by_cases hT : p = Tl i j t
    · exact Or.inr hT
    · exact Or.inl ⟨h1, by
        rintro (h | h | h | h | h)
        · exact h2 (Or.inl h)
        · exact hT h
        · exact h2 (Or.inr (Or.inl h))
        · exact h2 (Or.inr (Or.inr (Or.inl h)))
        · exact h2 (Or.inr (Or.inr (Or.inr h)))
        ⟩

theorem cUV_iff (i j : Bool) (t : T) (p : Pt T) :
    cUV cs cn i j t p ↔
      (p ≠ root ∧ ¬ (p = Tl i j t ∨ p = shd (.V j) ∨ p = grd (.V j) ∨ GV cs cn i j t p)) := by
  constructor
  · rintro (⟨h1, h2⟩ | rfl)
    · exact ⟨h1, fun h => h2 (by rcases h with h | h | h | h
                                 · exact Or.inr (Or.inl h)
                                 · exact Or.inr (Or.inr (Or.inl h))
                                 · exact Or.inr (Or.inr (Or.inr (Or.inl h)))
                                 · exact Or.inr (Or.inr (Or.inr (Or.inr h))))⟩
    · refine ⟨by simp, ?_⟩
      rintro (h | h | h | ⟨t', h, -⟩) <;> simp_all
  · intro ⟨h1, h2⟩
    by_cases hS : p = Sel (.out j)
    · exact Or.inr hS
    · exact Or.inl ⟨h1, by
        rintro (h | h | h | h | h)
        · exact hS h
        · exact h2 (Or.inl h)
        · exact h2 (Or.inr (Or.inl h))
        · exact h2 (Or.inr (Or.inr (Or.inl h)))
        · exact h2 (Or.inr (Or.inr (Or.inr h)))
        ⟩

theorem cVV_iff (i j : Bool) (t : T) (p : Pt T) :
    cVV cs cn i j t p ↔
      (p ≠ root ∧ ¬ (p = Sel (.out j) ∨ p = shd (.V j) ∨ p = grd (.V j) ∨ GV cs cn i j t p)) := by
  constructor
  · rintro (⟨h1, h2⟩ | rfl)
    · exact ⟨h1, fun h => h2 (by rcases h with h | h | h | h
                                 · exact Or.inl h
                                 · exact Or.inr (Or.inr (Or.inl h))
                                 · exact Or.inr (Or.inr (Or.inr (Or.inl h)))
                                 · exact Or.inr (Or.inr (Or.inr (Or.inr h))))⟩
    · refine ⟨by simp, ?_⟩
      rintro (h | h | h | h)
      · simp_all
      · simp_all
      · simp_all
      · exact GV_not_Tl_self i j t h
  · intro ⟨h1, h2⟩
    by_cases hT : p = Tl i j t
    · exact Or.inr hT
    · exact Or.inl ⟨h1, by
        rintro (h | h | h | h | h)
        · exact h2 (Or.inl h)
        · exact hT h
        · exact h2 (Or.inr (Or.inl h))
        · exact h2 (Or.inr (Or.inr (Or.inl h)))
        · exact h2 (Or.inr (Or.inr (Or.inr h)))
        ⟩

end Descriptions

/-! ## Lemma 7.1: every `U`, `V` used above is an upset -/

section Legitimacy

variable {T C : Type} {cw ce cs cn : T → C}

theorem upset_sUH (i : Bool) : IsUpset (sU (grd (.H (!i))) (Rel (.out i)) (NH i) : Set (Pt T)) := by
  have h := upset_compl (T := T)
    (fun p => p = Rel (.out i) ∨ p = Rel .dflt ∨ p = Rel (.out (!i)))
    (by
      rintro z p (rfl | rfl | rfl) hp hne <;>
        rcases (rootCover_Rel _).2 p hp with h | h
      · exact absurd h hne
      · exact Or.inl h
      · exact absurd h hne
      · exact Or.inr (Or.inl h)
      · exact absurd h hne
      · exact Or.inr (Or.inr h))
  intro p q hp hpq
  exact (sUH_iff i q).mpr (h p q ((sUH_iff i p).mp hp) hpq)

theorem upset_sVH (i : Bool) : IsUpset (sV (grd (.H (!i))) (Rel (.out i)) (NH i) : Set (Pt T)) := by
  have h := upset_compl (T := T)
    (fun p => p = grd (.H (!i)) ∨ p = Rel (.out i))
    (by
      rintro z p (rfl | rfl) hp hne
      · rcases (rootCover_grd _).2 p hp with h | h
        · exact absurd h hne
        · exact Or.inl h
      · rcases (rootCover_Rel _).2 p hp with h | h
        · exact absurd h hne
        · exact Or.inr h)
  intro p q hp hpq
  exact (sVH_iff i q).mpr (h p q ((sVH_iff i p).mp hp) hpq)

theorem upset_sUV (j : Bool) : IsUpset (sU (grd (.V (!j))) (Sel (.out j)) (NV j) : Set (Pt T)) := by
  have h := upset_compl (T := T)
    (fun p => p = Sel (.out j) ∨ p = Sel .dflt ∨ p = Sel (.out (!j)))
    (by
      rintro z p (rfl | rfl | rfl) hp hne <;>
        rcases (rootCover_Sel _).2 p hp with h | h
      · exact absurd h hne
      · exact Or.inl h
      · exact absurd h hne
      · exact Or.inr (Or.inl h)
      · exact absurd h hne
      · exact Or.inr (Or.inr h))
  intro p q hp hpq
  exact (sUV_iff j q).mpr (h p q ((sUV_iff j p).mp hp) hpq)

theorem upset_sVV (j : Bool) : IsUpset (sV (grd (.V (!j))) (Sel (.out j)) (NV j) : Set (Pt T)) := by
  have h := upset_compl (T := T)
    (fun p => p = grd (.V (!j)) ∨ p = Sel (.out j))
    (by
      rintro z p (rfl | rfl) hp hne
      · rcases (rootCover_grd _).2 p hp with h | h
        · exact absurd h hne
        · exact Or.inl h
      · rcases (rootCover_Sel _).2 p hp with h | h
        · exact absurd h hne
        · exact Or.inr h)
  intro p q hp hpq
  exact (sVV_iff j q).mpr (h p q ((sVV_iff j p).mp hp) hpq)

/-- The removal set of a horizontal compatibility cut is downward closed inside `P°`.
This is the step where the *shield* `d_X` matters: `d_{H_i}` is removed together with
`g_{H_i}`, so no retained point lies below a removed one. -/
theorem downclosed_compH (i j : Bool) (t : T) (z p : Pt T)
    (hz : z = shd (.H i) ∨ z = grd (.H i) ∨ GH cw ce i j t z ∨ z = Tl i j t ∨ z = Rel (.out i))
    (hpz : p ≤ z) (hne : p ≠ root) :
    p = shd (.H i) ∨ p = grd (.H i) ∨ GH cw ce i j t p ∨ p = Tl i j t ∨ p = Rel (.out i) := by
  rcases hz with rfl | rfl | ⟨t', rfl, ht'⟩ | rfl | rfl
  · rcases le_shd hpz with h | h | h
    · exact absurd h hne
    · exact Or.inr (Or.inl h)
    · exact Or.inl h
  · rcases (rootCover_grd _).2 p hpz with h | h
    · exact absurd h hne
    · exact Or.inr (Or.inl h)
  · rcases (rootCover_Tl _ _ _).2 p hpz with h | h
    · exact absurd h hne
    · exact Or.inr (Or.inr (Or.inl ⟨t', h, ht'⟩))
  · rcases (rootCover_Tl _ _ _).2 p hpz with h | h
    · exact absurd h hne
    · exact Or.inr (Or.inr (Or.inr (Or.inl h)))
  · rcases (rootCover_Rel _).2 p hpz with h | h
    · exact absurd h hne
    · exact Or.inr (Or.inr (Or.inr (Or.inr h)))

theorem downclosed_compV (i j : Bool) (t : T) (z p : Pt T)
    (hz : z = shd (.V j) ∨ z = grd (.V j) ∨ GV cs cn i j t z ∨ z = Tl i j t ∨ z = Sel (.out j))
    (hpz : p ≤ z) (hne : p ≠ root) :
    p = shd (.V j) ∨ p = grd (.V j) ∨ GV cs cn i j t p ∨ p = Tl i j t ∨ p = Sel (.out j) := by
  rcases hz with rfl | rfl | ⟨t', rfl, ht'⟩ | rfl | rfl
  · rcases le_shd hpz with h | h | h
    · exact absurd h hne
    · exact Or.inr (Or.inl h)
    · exact Or.inl h
  · rcases (rootCover_grd _).2 p hpz with h | h
    · exact absurd h hne
    · exact Or.inr (Or.inl h)
  · rcases (rootCover_Tl _ _ _).2 p hpz with h | h
    · exact absurd h hne
    · exact Or.inr (Or.inr (Or.inl ⟨t', h, ht'⟩))
  · rcases (rootCover_Tl _ _ _).2 p hpz with h | h
    · exact absurd h hne
    · exact Or.inr (Or.inr (Or.inr (Or.inl h)))
  · rcases (rootCover_Sel _).2 p hpz with h | h
    · exact absurd h hne
    · exact Or.inr (Or.inr (Or.inr (Or.inr h)))

theorem upset_cUH (i j : Bool) (t : T) : IsUpset (cUH cw ce i j t) := by
  have h := upset_compl (T := T)
    (fun p => p = Tl i j t ∨ p = shd (.H i) ∨ p = grd (.H i) ∨ GH cw ce i j t p)
    (by
      intro z p hz hpz hne
      have hz' : z = shd (.H i) ∨ z = grd (.H i) ∨ GH cw ce i j t z ∨ z = Tl i j t
                 ∨ z = Rel (.out i) := by
        rcases hz with h | h | h | h
        · exact Or.inr (Or.inr (Or.inr (Or.inl h)))
        · exact Or.inl h
        · exact Or.inr (Or.inl h)
        · exact Or.inr (Or.inr (Or.inl h))
      rcases downclosed_compH i j t z p hz' hpz hne with h | h | h | h | h
      · exact Or.inr (Or.inl h)
      · exact Or.inr (Or.inr (Or.inl h))
      · exact Or.inr (Or.inr (Or.inr h))
      · exact Or.inl h
      · -- `p = R_i` would force `z = R_i`, which is not in the removal set
        exfalso
        subst h
        rcases hz with h | h | h | ⟨t', h, -⟩ <;> subst h <;>
          first
          | (rcases (rootCover_Tl _ _ _).2 _ hpz with h' | h' <;> simp_all)
          | (rcases (rootCover_grd _).2 _ hpz with h' | h' <;> simp_all)
          | (rcases le_shd hpz with h' | h' | h' <;> simp_all))
  intro p q hp hpq
  exact (cUH_iff i j t q).mpr (h p q ((cUH_iff i j t p).mp hp) hpq)

theorem upset_cVH (i j : Bool) (t : T) : IsUpset (cVH cw ce i j t) := by
  have h := upset_compl (T := T)
    (fun p => p = Rel (.out i) ∨ p = shd (.H i) ∨ p = grd (.H i) ∨ GH cw ce i j t p)
    (by
      intro z p hz hpz hne
      rcases hz with rfl | rfl | rfl | ⟨t', rfl, ht'⟩
      · rcases (rootCover_Rel _).2 p hpz with h | h
        · exact absurd h hne
        · exact Or.inl h
      · rcases le_shd hpz with h | h | h
        · exact absurd h hne
        · exact Or.inr (Or.inr (Or.inl h))
        · exact Or.inr (Or.inl h)
      · rcases (rootCover_grd _).2 p hpz with h | h
        · exact absurd h hne
        · exact Or.inr (Or.inr (Or.inl h))
      · rcases (rootCover_Tl _ _ _).2 p hpz with h | h
        · exact absurd h hne
        · exact Or.inr (Or.inr (Or.inr ⟨t', h, ht'⟩)))
  intro p q hp hpq
  exact (cVH_iff i j t q).mpr (h p q ((cVH_iff i j t p).mp hp) hpq)

theorem upset_cUV (i j : Bool) (t : T) : IsUpset (cUV cs cn i j t) := by
  have h := upset_compl (T := T)
    (fun p => p = Tl i j t ∨ p = shd (.V j) ∨ p = grd (.V j) ∨ GV cs cn i j t p)
    (by
      intro z p hz hpz hne
      have hz' : z = shd (.V j) ∨ z = grd (.V j) ∨ GV cs cn i j t z ∨ z = Tl i j t
                 ∨ z = Sel (.out j) := by
        rcases hz with h | h | h | h
        · exact Or.inr (Or.inr (Or.inr (Or.inl h)))
        · exact Or.inl h
        · exact Or.inr (Or.inl h)
        · exact Or.inr (Or.inr (Or.inl h))
      rcases downclosed_compV i j t z p hz' hpz hne with h | h | h | h | h
      · exact Or.inr (Or.inl h)
      · exact Or.inr (Or.inr (Or.inl h))
      · exact Or.inr (Or.inr (Or.inr h))
      · exact Or.inl h
      · exfalso
        subst h
        rcases hz with h | h | h | ⟨t', h, -⟩ <;> subst h <;>
          first
          | (rcases (rootCover_Tl _ _ _).2 _ hpz with h' | h' <;> simp_all)
          | (rcases (rootCover_grd _).2 _ hpz with h' | h' <;> simp_all)
          | (rcases le_shd hpz with h' | h' | h' <;> simp_all))
  intro p q hp hpq
  exact (cUV_iff i j t q).mpr (h p q ((cUV_iff i j t p).mp hp) hpq)

theorem upset_cVV (i j : Bool) (t : T) : IsUpset (cVV cs cn i j t) := by
  have h := upset_compl (T := T)
    (fun p => p = Sel (.out j) ∨ p = shd (.V j) ∨ p = grd (.V j) ∨ GV cs cn i j t p)
    (by
      intro z p hz hpz hne
      rcases hz with rfl | rfl | rfl | ⟨t', rfl, ht'⟩
      · rcases (rootCover_Sel _).2 p hpz with h | h
        · exact absurd h hne
        · exact Or.inl h
      · rcases le_shd hpz with h | h | h
        · exact absurd h hne
        · exact Or.inr (Or.inr (Or.inl h))
        · exact Or.inr (Or.inl h)
      · rcases (rootCover_grd _).2 p hpz with h | h
        · exact absurd h hne
        · exact Or.inr (Or.inr (Or.inl h))
      · rcases (rootCover_Tl _ _ _).2 p hpz with h | h
        · exact absurd h hne
        · exact Or.inr (Or.inr (Or.inr ⟨t', h, ht'⟩)))
  intro p q hp hpq
  exact (cVV_iff i j t q).mpr (h p q ((cVV_iff i j t p).mp hp) hpq)

/-- **Lemma 7.1** (Legitimacy of the domain).  Every set used in `D_W` is an upset of
`P_W`; hence `D_W` is a genuine finite subset of `Up(P_W)²`. -/
theorem lemma_7_1 (U W : Set (Pt T)) (h : DW cw ce cs cn U W) : IsUpset U ∧ IsUpset W := by
  rcases h with ⟨X, Y, -, rfl, rfl⟩ | ⟨i, rfl, rfl⟩ | ⟨j, rfl, rfl⟩
              | ⟨i, j, t, rfl, rfl⟩ | ⟨i, j, t, rfl, rfl⟩
  · exact ⟨upset_sing_rol X, upset_sing_rol Y⟩
  · exact ⟨upset_sUH i, upset_sVH i⟩
  · exact ⟨upset_sUV j, upset_sVV j⟩
  · exact ⟨upset_cUH i j t, upset_cVH i j t⟩
  · exact ⟨upset_cUV i j t, upset_cVV i j t⟩

end Legitimacy

end MU
