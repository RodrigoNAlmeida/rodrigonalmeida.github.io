/-
# The whole-Medvedev-frame normalization

Formalises §4 of the paper: Lemma 4.1 (principal-cone normalization) and the resulting
equivalence between the "closed upset" form of the canonical-formula criterion
(Theorem 3.3) and the "whole frame" form used in Corollary 4.2.
-/

import MedvedevUndecidability.Frames

set_option linter.unusedVariables false
set_option linter.unusedSectionVars false

namespace MU

section Normalization

variable {V : Type} {P : Type} [Poset P]

/-- A sub-upset of a Medvedev frame, with the induced order. -/
instance subPoset (Y : Set (Face V)) : Poset {S : Face V // Y S} where
  le := fun A B => A.val ≤ B.val
  le_refl := fun A => Poset.le_refl A.val
  le_trans := fun h₁ h₂ => Poset.le_trans h₁ h₂
  le_antisymm := fun h₁ h₂ => Subtype.ext (Poset.le_antisymm h₁ h₂)

theorem subPoset_le {Y : Set (Face V)} {A B : {S : Face V // Y S}} :
    A ≤ B ↔ A.val ≤ B.val := Iff.rfl

/-- The carrier of the principal cone `↑x₀`: `↑x₀ ≅ M_{x₀}`. -/
abbrev Vcone (x₀ : Face V) : Type := {a : V // x₀.carrier a}

/-- The order isomorphism `M_{x₀} → ↑x₀ ⊆ M_V`. -/
def incl (x₀ : Face V) (T : Face (Vcone x₀)) : Face V :=
  ⟨fun a => ∃ b : Vcone x₀, b.val = a ∧ T.carrier b, by
    obtain ⟨b, hb⟩ := T.ne
    exact ⟨b.val, b, rfl, hb⟩⟩

theorem incl_ge (x₀ : Face V) (T : Face (Vcone x₀)) : x₀ ≤ incl x₀ T := by
  rintro a ⟨b, rfl, -⟩
  exact b.property

theorem incl_mono {x₀ : Face V} {T T' : Face (Vcone x₀)} (h : T ≤ T') :
    incl x₀ T ≤ incl x₀ T' := by
  rintro a ⟨b, rfl, hb⟩
  exact ⟨b, rfl, h b hb⟩

theorem incl_mono_rev {x₀ : Face V} {T T' : Face (Vcone x₀)}
    (h : incl x₀ T ≤ incl x₀ T') : T ≤ T' := by
  intro b hb
  obtain ⟨b', hb', hTb'⟩ := h b.val ⟨b, rfl, hb⟩
  have : b' = b := Subtype.ext hb'
  exact this ▸ hTb'

/-- Every face of `M_V` above `x₀` comes from a face of `M_{x₀}`. -/
theorem incl_surj {x₀ S : Face V} (h : x₀ ≤ S) : ∃ T : Face (Vcone x₀), incl x₀ T = S := by
  refine ⟨⟨fun b => S.carrier b.val, ?_⟩, ?_⟩
  · obtain ⟨a, ha⟩ := S.ne
    exact ⟨⟨a, h a ha⟩, ha⟩
  · refine Face.eq_of_carrier_eq (Set.ext fun a => ⟨?_, ?_⟩)
    · rintro ⟨b, rfl, hb⟩
      exact hb
    · intro ha
      exact ⟨⟨a, h a ha⟩, rfl, ha⟩

/-- The top face of `M_{x₀}`, whose image is `x₀` itself. -/
def coneTop (x₀ : Face V) : Face (Vcone x₀) :=
  ⟨fun _ => True, by obtain ⟨a, ha⟩ := x₀.ne; exact ⟨⟨a, ha⟩, trivial⟩⟩

theorem incl_coneTop (x₀ : Face V) : incl x₀ (coneTop x₀) = x₀ := by
  refine Face.eq_of_carrier_eq (Set.ext fun a => ⟨?_, ?_⟩)
  · rintro ⟨b, rfl, -⟩
    exact b.property
  · intro ha
    exact ⟨⟨a, ha⟩, rfl, trivial⟩

/-- **Lemma 4.1** (Principal-cone normalization).  If some closed upset `Y ⊆ M_N` carries an
onto cofinal partial Esakia morphism onto a rooted `P` satisfying `ZCDC(D)`, then some whole
Medvedev frame does. -/
theorem lemma_4_1 [FinE V] {r : P} (hr : ∀ q, r ≤ q) {D : Set P → Set P → Prop}
    {Y : Set (Face V)} (hY : IsUpset Y) {f : {S : Face V // Y S} → Option P}
    (hf : IsPEM f) (hon : POnto f) (hcof : Cofinal f) (hz : ZCDC f D) :
    EPD P D := by
  -- pick a point of the domain mapping to the root
  obtain ⟨Z, hZ⟩ := hon r
  -- the ambient cone is `↑Z.val`
  have hcone : ∀ T : Face (Vcone Z.val), Y (incl Z.val T) :=
    fun T => hY Z.val (incl Z.val T) Z.property (incl_ge _ T)
  let emb : Face (Vcone Z.val) → {S : Face V // Y S} := fun T => ⟨incl Z.val T, hcone T⟩
  have hembmono : ∀ {T T' : Face (Vcone Z.val)}, T ≤ T' → emb T ≤ emb T' :=
    fun h => incl_mono h
  have hembsurj : ∀ (T : Face (Vcone Z.val)) (W : {S : Face V // Y S}), emb T ≤ W →
      ∃ T', T ≤ T' ∧ emb T' = W := by
    intro T W hle
    obtain ⟨T', hT'⟩ := incl_surj (Poset.le_trans (incl_ge Z.val T) hle)
    refine ⟨T', incl_mono_rev (hT'.symm ▸ hle), Subtype.ext hT'⟩
  let g : Face (Vcone Z.val) → Option P := fun T => f (emb T)
  -- cone images agree
  have hcoimg : ∀ T, coneImg g T = coneImg f (emb T) := by
    intro T
    refine Set.ext fun q => ⟨?_, ?_⟩
    · rintro ⟨T', hTT', hgT'⟩
      exact ⟨emb T', hembmono hTT', hgT'⟩
    · rintro ⟨W, hW, hfW⟩
      obtain ⟨T', hTT', rfl⟩ := hembsurj T W hW
      exact ⟨T', hTT', hfW⟩
  have hgpem : IsPEM g := by
    refine ⟨?_, ?_, ?_⟩
    · intro T T' p q hTT' hp hq
      exact hf.pe1 (hembmono hTT') hp hq
    · intro T p q hp hpq
      obtain ⟨W, hW, hfW⟩ := hf.pe2 q hp hpq
      obtain ⟨T', hTT', rfl⟩ := hembsurj T W hW
      exact ⟨T', hTT', hfW⟩
    · intro T
      constructor
      · rintro ⟨p, hp⟩
        exact ⟨p, by rw [hcoimg T]; exact hf.coneImg_eq hp⟩
      · rintro ⟨y, hy⟩
        rw [hcoimg T] at hy
        exact hf.pe3.mpr ⟨y, hy⟩
  have hgroot : g (coneTop Z.val) = some r := by
    show f (emb (coneTop Z.val)) = some r
    have : emb (coneTop Z.val) = Z := Subtype.ext (incl_coneTop Z.val)
    rw [this]; exact hZ
  refine ⟨Vcone Z.val, finE_subtype _, ?_, g, hgpem, ?_, ?_, ?_⟩
  · obtain ⟨a, ha⟩ := Z.val.ne
    exact ⟨⟨a, ha⟩⟩
  · -- onto: the root is attained, so by (PE2) every point of `P` is
    intro p
    obtain ⟨T, hT, hfT⟩ := hgpem.pe2 p hgroot (hr p)
    exact ⟨T, hfT⟩
  · -- cofinal
    intro T
    obtain ⟨W, hW, p, hp⟩ := hcof (emb T)
    obtain ⟨T', hTT', rfl⟩ := hembsurj T W hW
    exact ⟨T', hTT', p, hp⟩
  · -- ZCDC
    intro T hT
    rw [hcoimg T]
    exact hz (emb T) hT

/-- The "closed upset" form of the criterion is equivalent to the "whole frame" form.
This is the content of Lemma 4.1 together with the trivial converse. -/
theorem upsetWitness_iff_epd {P : Type} [Poset P] {r : P} (hr : ∀ q, r ≤ q)
    (D : Set P → Set P → Prop) :
    (∃ (V : Type) (_ : FinE V) (_ : Nonempty V) (Y : Set (Face V)), IsUpset Y ∧
        ∃ f : {S : Face V // Y S} → Option P, IsPEM f ∧ POnto f ∧ Cofinal f ∧ ZCDC f D)
      ↔ EPD P D := by
  constructor
  · rintro ⟨V, instV, hne, Y, hY, f, hf, hon, hcof, hz⟩
    exact lemma_4_1 hr hY hf hon hcof hz
  · rintro ⟨V, instV, hne, f, hf, hon, hcof, hz⟩
    have hco : ∀ A : {S : Face V // (Set.univ : Set (Face V)) S},
        coneImg (fun B : {S : Face V // (Set.univ : Set (Face V)) S} => f B.val) A
          = coneImg f A.val := by
      intro A
      refine Set.ext fun q => ⟨?_, ?_⟩
      · rintro ⟨B, hB, hfB⟩
        exact ⟨B.val, hB, hfB⟩
      · rintro ⟨z, hz', hfz⟩
        exact ⟨⟨z, trivial⟩, hz', hfz⟩
    refine ⟨V, instV, hne, Set.univ, fun _ _ _ _ => trivial, fun A => f A.val, ?_, ?_, ?_, ?_⟩
    · constructor
      · intro A B p q hAB hp hq
        exact hf.pe1 hAB hp hq
      · intro A p q hp hpq
        obtain ⟨z, hz', hfz⟩ := hf.pe2 q hp hpq
        exact ⟨⟨z, trivial⟩, hz', hfz⟩
      · intro A
        constructor
        · rintro ⟨p, hp⟩
          exact ⟨p, by rw [hco A]; exact hf.coneImg_eq hp⟩
        · rintro ⟨y, hy⟩
          rw [hco A] at hy
          exact hf.pe3.mpr ⟨y, hy⟩
    · intro p
      obtain ⟨z, hz'⟩ := hon p
      exact ⟨⟨z, trivial⟩, hz'⟩
    · intro A
      obtain ⟨z, hz', hd⟩ := hcof A.val
      exact ⟨⟨z, trivial⟩, hz', hd⟩
    · intro A hA
      rw [hco A]
      exact hz A.val hA

end Normalization

end MU
