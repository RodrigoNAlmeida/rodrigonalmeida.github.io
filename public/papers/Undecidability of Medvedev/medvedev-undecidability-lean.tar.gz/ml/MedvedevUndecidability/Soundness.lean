/-
# Soundness: a partial morphism yields a torus tiling

Formalises §8 of the paper: Lemma 8.1 (support-role), Lemma 8.2 (pair filling),
Lemma 8.3 (seriality), Lemma 8.4 (compatibility), and Proposition 8.5.
-/

import MedvedevUndecidability.Domain

set_option linter.unusedVariables false
set_option linter.unusedSectionVars false

namespace MU

open Pt

section Soundness

variable {T C : Type} [FinE T] {cw ce cs cn : T → C}
variable {V : Type} [FinE V] {f : Face V → Option (Pt T)}

/-! ## §8.1  Roles of domain faces -/

/-- Every singleton face lies in the domain and takes a role point as value. -/
theorem singleton_role (hf : IsPEM f) (hcof : Cofinal f) (a : V) :
    ∃ X : Role, f (Face.pt a) = some (rol X) := by
  have hmax : ∀ S, Face.pt a ≤ S → S = Face.pt a := by
    intro S hS
    refine Face.eq_of_carrier_eq (Set.ext fun b => ⟨fun hb => hS b hb, fun hb => ?_⟩)
    obtain ⟨c, hc⟩ := S.ne
    have hca : c = a := hS c hc
    have : b = a := hb
    exact this ▸ (hca ▸ hc)
  obtain ⟨z, hz, p, hp⟩ := hcof (Face.pt a)
  have hzz : z = Face.pt a := hmax z hz
  subst hzz
  have hpm : ∀ q, p ≤ q → q = p := by
    intro q hq
    obtain ⟨S, hS, hfS⟩ := hf.pe2 q hp hq
    have : S = Face.pt a := hmax S hS
    subst this
    rw [hp] at hfS
    exact (Option.some.inj hfS).symm
  obtain ⟨X, hX⟩ := Pt.maximal_iff.mp hpm
  exact ⟨X, hX ▸ hp⟩

/-- `a` is an `X`-vertex. -/
def IsVtx (f : Face V → Option (Pt T)) (a : V) (X : Role) : Prop :=
  f (Face.pt a) = some (rol X)

theorem vtx_unique {a : V} {X Y : Role} (hX : IsVtx f a X) (hY : IsVtx f a Y) : X = Y := by
  have hX' : f (Face.pt a) = some (rol X) := hX
  have hY' : f (Face.pt a) = some (rol Y) := hY
  have h : (some (rol X) : Option (Pt T)) = some (rol Y) := hX'.symm.trans hY'
  exact Pt.rol.inj (Option.some.inj h)

/-- **Lemma 8.1** (Support-role lemma).  If `F ∈ dom(f)` and `f(F) = p`, then the set of
role labels of the vertices of `F` is exactly `Max(↑p)`. -/
theorem support_role (hf : IsPEM f) (hcof : Cofinal f) {F : Face V} {p : Pt T}
    (hF : f F = some p) (X : Role) :
    (∃ a, F.carrier a ∧ IsVtx f a X) ↔ p ≤ rol X := by
  constructor
  · rintro ⟨a, ha, hax⟩
    exact hf.pe1 (Face.le_pt ha) hF hax
  · intro hpX
    obtain ⟨G, hFG, hG⟩ := hf.pe2 (rol X) hF hpX
    obtain ⟨a, ha⟩ := G.ne
    refine ⟨a, hFG a ha, ?_⟩
    obtain ⟨Y, hY⟩ := singleton_role hf hcof a
    have h1 : (rol X : Pt T) ≤ rol Y := hf.pe1 (Face.le_pt ha) hG hY
    have h2 : (rol Y : Pt T) = rol X := rol_le h1
    show f (Face.pt a) = some (rol X)
    rw [hY, h2]

/-- A face all of whose vertices must carry role `X` is contained in the `X`-vertices. -/
theorem vertices_of_value (hf : IsPEM f) (hcof : Cofinal f) {F : Face V} {p : Pt T}
    (hF : f F = some p) {a : V} (ha : F.carrier a) : ∃ X, IsVtx f a X ∧ p ≤ rol X := by
  obtain ⟨X, hX⟩ := singleton_role hf hcof a
  exact ⟨X, hX, hf.pe1 (Face.le_pt ha) hF hX⟩

/-! ## Faces above a pair -/

theorem face_sub_pair {x y : V} {S : Face V} (h : Face.pr x y ≤ S) :
    S = Face.pt x ∨ S = Face.pt y ∨ S = Face.pr x y := by
  have h' : ∀ a, S.carrier a → (a = x ∨ a = y) := h
  by_cases hx : S.carrier x
  · by_cases hy : S.carrier y
    · refine Or.inr (Or.inr (Face.eq_of_carrier_eq (Set.ext fun a => ⟨fun ha => h' a ha, ?_⟩)))
      rintro (rfl | rfl)
      · exact hx
      · exact hy
    · refine Or.inl (Face.eq_of_carrier_eq (Set.ext fun a => ⟨fun ha => ?_, fun ha => ?_⟩))
      · rcases h' a ha with rfl | rfl
        · rfl
        · exact absurd ha hy
      · have : a = x := ha
        exact this ▸ hx
  · by_cases hy : S.carrier y
    · refine Or.inr (Or.inl (Face.eq_of_carrier_eq (Set.ext fun a => ⟨fun ha => ?_, fun ha => ?_⟩)))
      · rcases h' a ha with rfl | rfl
        · exact absurd ha hx
        · rfl
      · have : a = y := ha
        exact this ▸ hy
    · exfalso
      obtain ⟨c, hc⟩ := S.ne
      rcases h' c hc with rfl | rfl
      · exact hx hc
      · exact hy hc

/-! ## §8.2  Every mixed pair has a unique colour -/

theorem Desig_ne {X Y : Role} (h : Desig X Y) : X ≠ Y := by
  rcases h with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨i, j, rfl, rfl⟩ <;> simp

/-- **Lemma 8.2** (Pair filling).  A pair of vertices carrying a designated pair of roles
is a domain face. -/
theorem pair_filling (hf : IsPEM f) (hcof : Cofinal f) (hz : ZCDC f (DW cw ce cs cn))
    {x y : V} {X Y : Role} (hx : IsVtx f x X) (hy : IsVtx f y Y) (hd : Desig X Y) :
    PDom f (Face.pr x y) := by
  by_contra hnd
  -- the cone image of `{x,y}` is exactly `{X, Y}`
  have hcone : ∀ q : Pt T, coneImg f (Face.pr x y) q ↔ (q = rol X ∨ q = rol Y) := by
    intro q
    constructor
    · rintro ⟨S, hS, hfS⟩
      rcases face_sub_pair hS with rfl | rfl | rfl
      · rw [hx] at hfS; exact Or.inl (Option.some.inj hfS).symm
      · rw [hy] at hfS; exact Or.inr (Option.some.inj hfS).symm
      · exact absurd ⟨q, hfS⟩ hnd
    · rintro (rfl | rfl)
      · exact ⟨Face.pt x, Face.le_pt (Or.inl rfl), hx⟩
      · exact ⟨Face.pt y, Face.le_pt (Or.inr rfl), hy⟩
  have hXY : X ≠ Y := Desig_ne hd
  have hrne : (rol X : Pt T) ≠ rol Y := by
    intro h; injection h with h; exact hXY h
  -- hence its minimum is `{X, Y}`, an element of the pair-filling cut
  have hmin : ∀ q : Pt T, minSet (coneImg f (Face.pr x y)) q ↔ (q = rol X ∨ q = rol Y) := by
    intro q
    constructor
    · intro hq; exact (hcone q).mp hq.1
    · intro hq
      refine ⟨(hcone q).mpr hq, fun r hr hrq => ?_⟩
      rcases (hcone r).mp hr with rfl | rfl <;> rcases hq with rfl | rfl
      · rfl
      · exact (rol_le hrq).symm
      · exact (rol_le hrq).symm
      · rfl
  refine hz (Face.pr x y) hnd ?_
  refine ⟨Set.sing (rol X), Set.sing (rol Y), Or.inl ⟨X, Y, hd, rfl, rfl⟩, ?_, ?_, ?_, ?_⟩
  · exact minSet_antichain _
  · intro p hp
    rcases (hmin p).mp hp with rfl | rfl
    · exact Or.inl rfl
    · exact Or.inr rfl
  · exact ⟨rol X, (hmin _).mpr (Or.inl rfl), rfl, fun h => hrne h⟩
  · exact ⟨rol Y, (hmin _).mpr (Or.inr rfl), rfl, fun h => hrne h.symm⟩

/-! ### Classification of the colour of a mixed pair -/

theorem classify_HH {p : Pt T} (h : ∀ Z, p ≤ rol Z ↔ (Z = .H false ∨ Z = .H true)) :
    ∃ k, p = Rel k := by
  cases p with
  | root => exact absurd ((h (.V false)).mp trivial) (by simp)
  | rol Z => cases Z with
    | H b =>
      cases b
      · exact absurd ((h (.H true)).mpr (Or.inr rfl)) (by simp [le_def, ple])
      · exact absurd ((h (.H false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
    | V b => exact absurd ((h (.H false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
  | shd Z => cases Z with
    | H b =>
      cases b
      · exact absurd ((h (.H true)).mpr (Or.inr rfl)) (by simp [le_def, ple])
      · exact absurd ((h (.H false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
    | V b => exact absurd ((h (.H false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
  | grd Z => cases Z with
    | H b =>
      cases b
      · exact absurd ((h (.H true)).mpr (Or.inr rfl)) (by simp [le_def, ple])
      · exact absurd ((h (.H false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
    | V b => exact absurd ((h (.H false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
  | Rel k => exact ⟨k, rfl⟩
  | Sel k => exact absurd ((h (.V false)).mp (Or.inr (Or.inl rfl))) (by simp)
  | Tl i j t => exact absurd ((h (.V j)).mp (Or.inr (Or.inr rfl))) (by simp)

theorem classify_VV {p : Pt T} (h : ∀ Z, p ≤ rol Z ↔ (Z = .V false ∨ Z = .V true)) :
    ∃ k, p = Sel k := by
  cases p with
  | root => exact absurd ((h (.H false)).mp trivial) (by simp)
  | rol Z => cases Z with
    | V b =>
      cases b
      · exact absurd ((h (.V true)).mpr (Or.inr rfl)) (by simp [le_def, ple])
      · exact absurd ((h (.V false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
    | H b => exact absurd ((h (.V false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
  | shd Z => cases Z with
    | V b =>
      cases b
      · exact absurd ((h (.V true)).mpr (Or.inr rfl)) (by simp [le_def, ple])
      · exact absurd ((h (.V false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
    | H b => exact absurd ((h (.V false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
  | grd Z => cases Z with
    | V b =>
      cases b
      · exact absurd ((h (.V true)).mpr (Or.inr rfl)) (by simp [le_def, ple])
      · exact absurd ((h (.V false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
    | H b => exact absurd ((h (.V false)).mpr (Or.inl rfl)) (by simp [le_def, ple])
  | Sel k => exact ⟨k, rfl⟩
  | Rel k => exact absurd ((h (.H false)).mp (Or.inr (Or.inl rfl))) (by simp)
  | Tl i j t => exact absurd ((h (.H i)).mp (Or.inr (Or.inl rfl))) (by simp)

theorem classify_HV {p : Pt T} {i j : Bool}
    (h : ∀ Z, p ≤ rol Z ↔ (Z = .H i ∨ Z = .V j)) : ∃ t, p = Tl i j t := by
  cases p with
  | root => exact absurd ((h (.H (!i))).mp trivial) (by cases i <;> simp)
  | rol Z => cases Z with
    | H b => exact absurd ((h (.V j)).mpr (Or.inr rfl)) (by simp [le_def, ple])
    | V b => exact absurd ((h (.H i)).mpr (Or.inl rfl)) (by simp [le_def, ple])
  | shd Z => cases Z with
    | H b => exact absurd ((h (.V j)).mpr (Or.inr rfl)) (by simp [le_def, ple])
    | V b => exact absurd ((h (.H i)).mpr (Or.inl rfl)) (by simp [le_def, ple])
  | grd Z => cases Z with
    | H b => exact absurd ((h (.V j)).mpr (Or.inr rfl)) (by simp [le_def, ple])
    | V b => exact absurd ((h (.H i)).mpr (Or.inl rfl)) (by simp [le_def, ple])
  | Rel k =>
    exact absurd ((h (.H (!i))).mp (by cases i <;> simp [le_def, ple])) (by cases i <;> simp)
  | Sel k =>
    exact absurd ((h (.V (!j))).mp (by cases j <;> simp [le_def, ple])) (by cases j <;> simp)
  | Tl i' j' t =>
    have h1 : (Role.H i') = .H i ∨ (Role.H i') = .V j := (h (.H i')).mp (Or.inr (Or.inl rfl))
    have h2 : (Role.V j') = .H i ∨ (Role.V j') = .V j := (h (.V j')).mp (Or.inr (Or.inr rfl))
    have hi : i' = i := by rcases h1 with h | h <;> simp_all
    have hj : j' = j := by rcases h2 with h | h <;> simp_all
    subst hi; subst hj
    exact ⟨t, rfl⟩

/-- The role set of the pair `{x,y}` is exactly `{X,Y}`. -/
theorem pair_roles (hf : IsPEM f) (hcof : Cofinal f) {x y : V} {X Y : Role}
    (hx : IsVtx f x X) (hy : IsVtx f y Y) (hXY : X ≠ Y) {p : Pt T}
    (hp : f (Face.pr x y) = some p) (Z : Role) :
    p ≤ rol Z ↔ (Z = X ∨ Z = Y) := by
  rw [← support_role hf hcof hp Z]
  constructor
  · rintro ⟨a, ha, haZ⟩
    rcases ha with rfl | rfl
    · exact Or.inl (vtx_unique haZ hx)
    · exact Or.inr (vtx_unique haZ hy)
  · rintro (rfl | rfl)
    · exact ⟨x, Or.inl rfl, hx⟩
    · exact ⟨y, Or.inr rfl, hy⟩


/-! ## Colours of mixed pairs, by role type -/

theorem pair_colour_HH (hf : IsPEM f) (hcof : Cofinal f) (hz : ZCDC f (DW cw ce cs cn))
    {x y : V} {b c : Bool} (hx : IsVtx f x (.H b)) (hy : IsVtx f y (.H c)) (hbc : b ≠ c) :
    ∃ k, f (Face.pr x y) = some (Rel k) := by
  have hne : (Role.H b) ≠ (Role.H c) := fun h => hbc (Role.H.inj h)
  have hdom : PDom f (Face.pr x y) := by
    cases b <;> cases c
    · exact absurd rfl hbc
    · exact pair_filling hf hcof hz hx hy (Or.inl ⟨rfl, rfl⟩)
    · have h := pair_filling hf hcof hz hy hx (Or.inl ⟨rfl, rfl⟩)
      rw [Face.pr_comm] at h; exact h
    · exact absurd rfl hbc
  obtain ⟨p, hp⟩ := hdom
  have hroles := pair_roles hf hcof hx hy hne hp
  have hclass : ∀ Z, p ≤ rol Z ↔ (Z = .H false ∨ Z = .H true) := by
    intro Z
    rw [hroles Z]
    cases b <;> cases c
    · exact absurd rfl hbc
    · exact Iff.rfl
    · exact ⟨fun h => h.symm, fun h => h.symm⟩
    · exact absurd rfl hbc
  obtain ⟨k, hk⟩ := classify_HH hclass
  exact ⟨k, hk ▸ hp⟩

theorem pair_colour_VV (hf : IsPEM f) (hcof : Cofinal f) (hz : ZCDC f (DW cw ce cs cn))
    {x y : V} {b c : Bool} (hx : IsVtx f x (.V b)) (hy : IsVtx f y (.V c)) (hbc : b ≠ c) :
    ∃ k, f (Face.pr x y) = some (Sel k) := by
  have hne : (Role.V b) ≠ (Role.V c) := fun h => hbc (Role.V.inj h)
  have hdom : PDom f (Face.pr x y) := by
    cases b <;> cases c
    · exact absurd rfl hbc
    · exact pair_filling hf hcof hz hx hy (Or.inr (Or.inl ⟨rfl, rfl⟩))
    · have h := pair_filling hf hcof hz hy hx (Or.inr (Or.inl ⟨rfl, rfl⟩))
      rw [Face.pr_comm] at h; exact h
    · exact absurd rfl hbc
  obtain ⟨p, hp⟩ := hdom
  have hroles := pair_roles hf hcof hx hy hne hp
  have hclass : ∀ Z, p ≤ rol Z ↔ (Z = .V false ∨ Z = .V true) := by
    intro Z
    rw [hroles Z]
    cases b <;> cases c
    · exact absurd rfl hbc
    · exact Iff.rfl
    · exact ⟨fun h => h.symm, fun h => h.symm⟩
    · exact absurd rfl hbc
  obtain ⟨k, hk⟩ := classify_VV hclass
  exact ⟨k, hk ▸ hp⟩

theorem pair_colour_HV (hf : IsPEM f) (hcof : Cofinal f) (hz : ZCDC f (DW cw ce cs cn))
    {x v : V} {b c : Bool} (hx : IsVtx f x (.H b)) (hv : IsVtx f v (.V c)) :
    ∃ t, f (Face.pr x v) = some (Tl b c t) := by
  have hne : (Role.H b) ≠ (Role.V c) := by simp
  obtain ⟨p, hp⟩ := pair_filling hf hcof hz hx hv (Or.inr (Or.inr ⟨b, c, rfl, rfl⟩))
  obtain ⟨t, ht⟩ := classify_HV (pair_roles hf hcof hx hv hne hp)
  exact ⟨t, ht ▸ hp⟩

/-! ## Guard faces -/

/-- Every vertex of a `g_X`-face is an `X`-vertex (Lemma 8.1(a)). -/
theorem guard_vertices (hf : IsPEM f) (hcof : Cofinal f) {G : Face V} {X : Role}
    (hG : f G = some (grd X)) {a : V} (ha : G.carrier a) : IsVtx f a X := by
  obtain ⟨Y, hY, hle⟩ := vertices_of_value hf hcof hG ha
  have hYX : Y = X := (Pt.rolesAbove_grd X Y).mp hle
  exact hYX ▸ hY

/-! ## §8.3  Seriality: the guards force outgoing edges -/

/-- **Lemma 8.3** (Seriality), horizontal case.  For every `H_i`-vertex `x` and every guard
face `G_Y` of the opposite horizontal phase, some `y ∈ G_Y` makes `{x,y}` carry the output
colour `R_i`. -/
theorem seriality_H (hf : IsPEM f) (hcof : Cofinal f) (hz : ZCDC f (DW cw ce cs cn))
    (i : Bool) {GY : Face V} (hGY : f GY = some (grd (.H (!i))))
    {x : V} (hxv : IsVtx f x (.H i)) :
    ∃ y, GY.carrier y ∧ f (Face.pr x y) = some (Rel (.out i)) := by
  by_contra hcon
  have hcon' : ∀ y, GY.carrier y → f (Face.pr x y) ≠ some (Rel (.out i)) :=
    fun y hy h => hcon ⟨y, hy, h⟩
  have hini : (!i) ≠ i := bool_not_ne i
  have hYv : ∀ y, GY.carrier y → IsVtx f y (.H (!i)) := fun y hy => guard_vertices hf hcof hGY hy
  have hcol : ∀ y, GY.carrier y → ∃ k, f (Face.pr x y) = some (Rel k) := fun y hy =>
    pair_colour_HH hf hcof hz hxv (hYv y hy) (fun h => hini h.symm)
  have hFmem : ∀ a, (Face.cons x GY).carrier a → (a = x ∨ GY.carrier a) := fun a h => h
  have hFroles : ∀ a, (Face.cons x GY).carrier a → (IsVtx f a (.H i) ∨ IsVtx f a (.H (!i))) := by
    intro a ha
    rcases ha with rfl | ha
    · exact Or.inl hxv
    · exact Or.inr (hYv a ha)
  have hFGY : Face.cons x GY ≤ GY := fun a ha => Or.inr ha
  have hFpr : ∀ y, GY.carrier y → Face.cons x GY ≤ Face.pr x y := by
    intro y hy a ha
    rcases ha with rfl | rfl
    · exact Or.inl rfl
    · exact Or.inr hy
  -- no subface of `F` takes the root as value: `F` has no vertical vertex
  have hnoroot : ∀ K : Face V, Face.cons x GY ≤ K → f K ≠ some root := by
    intro K hK hfK
    obtain ⟨a, ha, haV⟩ := (support_role hf hcof hfK (.V false)).mpr trivial
    rcases hFroles a (hK a ha) with h | h
    · exact absurd (vtx_unique haV h) (by simp)
    · exact absurd (vtx_unique haV h) (by simp)
  -- no subface of `F` takes the output colour `Q` as value
  have hnoQ : ∀ K : Face V, Face.cons x GY ≤ K → f K ≠ some (Rel (.out i)) := by
    intro K hK hfK
    obtain ⟨a, ha, hai⟩ := (support_role hf hcof hfK (.H i)).mpr (by simp [le_def, ple])
    obtain ⟨y, hy, hyi⟩ := (support_role hf hcof hfK (.H (!i))).mpr (by simp [le_def, ple])
    have hax : a = x := by
      rcases hFmem a (hK a ha) with h | h
      · exact h
      · exact absurd (Role.H.inj (vtx_unique (hYv a h) hai)) hini
    have hyG : GY.carrier y := by
      rcases hFmem y (hK y hy) with h | h
      · subst h
        exact absurd (Role.H.inj (vtx_unique hxv hyi)) (fun e => hini e.symm)
      · exact h
    have hKpr : K ≤ Face.pr x y := by
      intro c hc
      rcases hc with rfl | rfl
      · exact hax ▸ ha
      · exact hy
    obtain ⟨k, hk⟩ := hcol y hyG
    have hle : (Rel (.out i) : Pt T) ≤ Rel k := hf.pe1 hKpr hfK hk
    rcases hle with h | h | h
    · exact hcon' y hyG (by rw [hk, h])
    · exact absurd h (by simp)
    · exact absurd h (by simp)
  -- `F` itself is not a domain face
  have hFnd : ¬ PDom f (Face.cons x GY) := by
    rintro ⟨p, hp⟩
    obtain ⟨y₀, hy₀⟩ := GY.ne
    obtain ⟨k, hk⟩ := hcol y₀ hy₀
    have h1 : p ≤ grd (.H (!i)) := hf.pe1 hFGY hp hGY
    have h2 : p ≤ (Rel k : Pt T) := hf.pe1 (hFpr y₀ hy₀) hp hk
    have hproot : p = root := by
      rcases (rootCover_grd (.H (!i))).2 p h1 with h | h
      · exact h
      · rcases (rootCover_Rel k).2 p h2 with h' | h'
        · exact h'
        · exact absurd (h.symm.trans h') (by simp)
    exact hnoroot _ (Poset.le_refl _) (by rw [hp, hproot])
  -- assemble the forbidden antichain for the serial cut
  obtain ⟨y₀, hy₀⟩ := GY.ne
  obtain ⟨k₀, hk₀⟩ := hcol y₀ hy₀
  have hne0 : (Rel k₀ : Pt T) ≠ Rel (.out i) := fun h => hcon' y₀ hy₀ (by rw [hk₀, h])
  have hk₀N : NH i (Rel k₀ : Pt T) := by
    cases k₀ with
    | dflt => exact Or.inl rfl
    | out b =>
      have hbi : b ≠ i := fun h => hne0 (by rw [h])
      have hb : b = !i := by cases b <;> cases i <;> simp_all
      exact Or.inr (by rw [hb])
  refine hz (Face.cons x GY) hFnd
    ⟨sU (grd (.H (!i))) (Rel (.out i)) (NH i), sV (grd (.H (!i))) (Rel (.out i)) (NH i),
     Or.inr (Or.inl ⟨i, rfl, rfl⟩), minSet_antichain _, ?_, ?_, ?_⟩
  · -- the antichain is contained in `U ∪ V`
    intro q hq
    obtain ⟨K, hK, hfK⟩ := hq.1
    have hqroot : q ≠ root := fun h => hnoroot K hK (by rw [hfK, h])
    have hqQ : q ≠ Rel (.out i) := fun h => hnoQ K hK (by rw [hfK, h])
    by_cases hN : NH i q
    · refine Or.inr ((sVH_iff i q).mpr ⟨hqroot, ?_⟩)
      rintro (h | h)
      · rcases hN with h' | h' <;> exact absurd (h.symm.trans h') (by simp)
      · exact hqQ h
    · refine Or.inl ((sUH_iff i q).mpr ⟨hqroot, ?_⟩)
      rintro (h | h | h)
      · exact hqQ h
      · exact hN (Or.inl h)
      · exact hN (Or.inr h)
  · -- the guard `g_Y` is in `U \ V`
    refine ⟨grd (.H (!i)), ⟨⟨GY, hFGY, hGY⟩, ?_⟩, ?_, ?_⟩
    · intro r hr hrle
      obtain ⟨K, hK, hfK⟩ := hr
      rcases (rootCover_grd (.H (!i))).2 r hrle with h | h
      · exact absurd (show f K = some (root : Pt T) by rw [hfK, h]) (hnoroot K hK)
      · exact h
    · exact (sUH_iff i _).mpr ⟨by simp, by simp⟩
    · exact fun h => ((sVH_iff i _).mp h).2 (Or.inl rfl)
  · -- the actual (nonoutput) colour is in `V \ U`
    refine ⟨Rel k₀, ⟨⟨Face.pr x y₀, hFpr y₀ hy₀, hk₀⟩, ?_⟩, ?_, ?_⟩
    · intro r hr hrle
      obtain ⟨K, hK, hfK⟩ := hr
      rcases (rootCover_Rel k₀).2 r hrle with h | h
      · exact absurd (show f K = some (root : Pt T) by rw [hfK, h]) (hnoroot K hK)
      · exact h
    · refine (sVH_iff i _).mpr ⟨by simp, ?_⟩
      rintro (h | h)
      · exact absurd h (by simp)
      · exact hne0 h
    · intro h
      have h2 := ((sUH_iff i _).mp h).2
      rcases hk₀N with h' | h'
      · exact h2 (Or.inr (Or.inl h'))
      · exact h2 (Or.inr (Or.inr h'))

/-- **Lemma 8.3** (Seriality), vertical case. -/
theorem seriality_V (hf : IsPEM f) (hcof : Cofinal f) (hz : ZCDC f (DW cw ce cs cn))
    (j : Bool) {GY : Face V} (hGY : f GY = some (grd (.V (!j))))
    {v : V} (hvv : IsVtx f v (.V j)) :
    ∃ u, GY.carrier u ∧ f (Face.pr v u) = some (Sel (.out j)) := by
  by_contra hcon
  have hcon' : ∀ u, GY.carrier u → f (Face.pr v u) ≠ some (Sel (.out j)) :=
    fun u hu h => hcon ⟨u, hu, h⟩
  have hinj : (!j) ≠ j := bool_not_ne j
  have hYv : ∀ u, GY.carrier u → IsVtx f u (.V (!j)) := fun u hu => guard_vertices hf hcof hGY hu
  have hcol : ∀ u, GY.carrier u → ∃ k, f (Face.pr v u) = some (Sel k) := fun u hu =>
    pair_colour_VV hf hcof hz hvv (hYv u hu) (fun h => hinj h.symm)
  have hFmem : ∀ a, (Face.cons v GY).carrier a → (a = v ∨ GY.carrier a) := fun a h => h
  have hFroles : ∀ a, (Face.cons v GY).carrier a → (IsVtx f a (.V j) ∨ IsVtx f a (.V (!j))) := by
    intro a ha
    rcases ha with rfl | ha
    · exact Or.inl hvv
    · exact Or.inr (hYv a ha)
  have hFGY : Face.cons v GY ≤ GY := fun a ha => Or.inr ha
  have hFpr : ∀ u, GY.carrier u → Face.cons v GY ≤ Face.pr v u := by
    intro u hu a ha
    rcases ha with rfl | rfl
    · exact Or.inl rfl
    · exact Or.inr hu
  have hnoroot : ∀ K : Face V, Face.cons v GY ≤ K → f K ≠ some root := by
    intro K hK hfK
    obtain ⟨a, ha, haH⟩ := (support_role hf hcof hfK (.H false)).mpr trivial
    rcases hFroles a (hK a ha) with h | h
    · exact absurd (vtx_unique haH h) (by simp)
    · exact absurd (vtx_unique haH h) (by simp)
  have hnoQ : ∀ K : Face V, Face.cons v GY ≤ K → f K ≠ some (Sel (.out j)) := by
    intro K hK hfK
    obtain ⟨a, ha, haj⟩ := (support_role hf hcof hfK (.V j)).mpr (by simp [le_def, ple])
    obtain ⟨u, hu, huj⟩ := (support_role hf hcof hfK (.V (!j))).mpr (by simp [le_def, ple])
    have hav : a = v := by
      rcases hFmem a (hK a ha) with h | h
      · exact h
      · exact absurd (Role.V.inj (vtx_unique (hYv a h) haj)) hinj
    have huG : GY.carrier u := by
      rcases hFmem u (hK u hu) with h | h
      · subst h
        exact absurd (Role.V.inj (vtx_unique hvv huj)) (fun e => hinj e.symm)
      · exact h
    have hKpr : K ≤ Face.pr v u := by
      intro c hc
      rcases hc with rfl | rfl
      · exact hav ▸ ha
      · exact hu
    obtain ⟨k, hk⟩ := hcol u huG
    have hle : (Sel (.out j) : Pt T) ≤ Sel k := hf.pe1 hKpr hfK hk
    rcases hle with h | h | h
    · exact hcon' u huG (by rw [hk, h])
    · exact absurd h (by simp)
    · exact absurd h (by simp)
  have hFnd : ¬ PDom f (Face.cons v GY) := by
    rintro ⟨p, hp⟩
    obtain ⟨u₀, hu₀⟩ := GY.ne
    obtain ⟨k, hk⟩ := hcol u₀ hu₀
    have h1 : p ≤ grd (.V (!j)) := hf.pe1 hFGY hp hGY
    have h2 : p ≤ (Sel k : Pt T) := hf.pe1 (hFpr u₀ hu₀) hp hk
    have hproot : p = root := by
      rcases (rootCover_grd (.V (!j))).2 p h1 with h | h
      · exact h
      · rcases (rootCover_Sel k).2 p h2 with h' | h'
        · exact h'
        · exact absurd (h.symm.trans h') (by simp)
    exact hnoroot _ (Poset.le_refl _) (by rw [hp, hproot])
  obtain ⟨u₀, hu₀⟩ := GY.ne
  obtain ⟨k₀, hk₀⟩ := hcol u₀ hu₀
  have hne0 : (Sel k₀ : Pt T) ≠ Sel (.out j) := fun h => hcon' u₀ hu₀ (by rw [hk₀, h])
  have hk₀N : NV j (Sel k₀ : Pt T) := by
    cases k₀ with
    | dflt => exact Or.inl rfl
    | out b =>
      have hbj : b ≠ j := fun h => hne0 (by rw [h])
      have hb : b = !j := by cases b <;> cases j <;> simp_all
      exact Or.inr (by rw [hb])
  refine hz (Face.cons v GY) hFnd
    ⟨sU (grd (.V (!j))) (Sel (.out j)) (NV j), sV (grd (.V (!j))) (Sel (.out j)) (NV j),
     Or.inr (Or.inr (Or.inl ⟨j, rfl, rfl⟩)), minSet_antichain _, ?_, ?_, ?_⟩
  · intro q hq
    obtain ⟨K, hK, hfK⟩ := hq.1
    have hqroot : q ≠ root := fun h => hnoroot K hK (by rw [hfK, h])
    have hqQ : q ≠ Sel (.out j) := fun h => hnoQ K hK (by rw [hfK, h])
    by_cases hN : NV j q
    · refine Or.inr ((sVV_iff j q).mpr ⟨hqroot, ?_⟩)
      rintro (h | h)
      · rcases hN with h' | h' <;> exact absurd (h.symm.trans h') (by simp)
      · exact hqQ h
    · refine Or.inl ((sUV_iff j q).mpr ⟨hqroot, ?_⟩)
      rintro (h | h | h)
      · exact hqQ h
      · exact hN (Or.inl h)
      · exact hN (Or.inr h)
  · refine ⟨grd (.V (!j)), ⟨⟨GY, hFGY, hGY⟩, ?_⟩, ?_, ?_⟩
    · intro r hr hrle
      obtain ⟨K, hK, hfK⟩ := hr
      rcases (rootCover_grd (.V (!j))).2 r hrle with h | h
      · exact absurd (show f K = some (root : Pt T) by rw [hfK, h]) (hnoroot K hK)
      · exact h
    · exact (sUV_iff j _).mpr ⟨by simp, by simp⟩
    · exact fun h => ((sVV_iff j _).mp h).2 (Or.inl rfl)
  · refine ⟨Sel k₀, ⟨⟨Face.pr v u₀, hFpr u₀ hu₀, hk₀⟩, ?_⟩, ?_, ?_⟩
    · intro r hr hrle
      obtain ⟨K, hK, hfK⟩ := hr
      rcases (rootCover_Sel k₀).2 r hrle with h | h
      · exact absurd (show f K = some (root : Pt T) by rw [hfK, h]) (hnoroot K hK)
      · exact h
    · refine (sVV_iff j _).mpr ⟨by simp, ?_⟩
      rintro (h | h)
      · exact absurd h (by simp)
      · exact hne0 h
    · intro h
      have h2 := ((sUV_iff j _).mp h).2
      rcases hk₀N with h' | h'
      · exact h2 (Or.inr (Or.inl h'))
      · exact h2 (Or.inr (Or.inr h'))

/-! ## §8.4  Compatibility on cycle products -/

theorem face_eq_pt {K : Face V} {x : V} (h : ∀ a, K.carrier a → a = x) : K = Face.pt x := by
  refine Face.eq_of_carrier_eq (Set.ext fun a => ⟨fun ha => h a ha, fun ha => ?_⟩)
  obtain ⟨c, hc⟩ := K.ne
  have hcx : c = x := h c hc
  have hax : a = x := ha
  exact hax ▸ (hcx ▸ hc)

theorem face_eq_pr {K : Face V} {y v : V} (hsub : ∀ a, K.carrier a → (a = y ∨ a = v))
    (hy : K.carrier y) (hv : K.carrier v) : K = Face.pr y v := by
  refine Face.eq_of_carrier_eq (Set.ext fun a => ⟨fun ha => hsub a ha, fun ha => ?_⟩)
  rcases ha with rfl | rfl
  · exact hy
  · exact hv

/-- **Lemma 8.4** (Horizontal compatibility). -/
theorem compat_H (hf : IsPEM f) (hcof : Cofinal f) (hz : ZCDC f (DW cw ce cs cn))
    (i j : Bool) {x y v : V} {t t' : T}
    (hx : IsVtx f x (.H i)) (hy : IsVtx f y (.H (!i))) (hv : IsVtx f v (.V j))
    (hxy : f (Face.pr x y) = some (Rel (.out i)))
    (hxv : f (Face.pr x v) = some (Tl i j t))
    (hyv : f (Face.pr y v) = some (Tl (!i) j t')) :
    ce t = cw t' := by
  by_contra hbad
  have hini : (!i) ≠ i := bool_not_ne i
  have hinj : (!j) ≠ j := bool_not_ne j
  have hx' : f (Face.pt x) = some (rol (.H i)) := hx
  have hmem : ∀ a, (Face.cons x (Face.pr y v)).carrier a → (a = x ∨ a = y ∨ a = v) :=
    fun a h => h
  have hFroles : ∀ a, (Face.cons x (Face.pr y v)).carrier a →
      (IsVtx f a (.H i) ∨ IsVtx f a (.H (!i)) ∨ IsVtx f a (.V j)) := by
    intro a ha
    rcases ha with rfl | rfl | rfl
    · exact Or.inl hx
    · exact Or.inr (Or.inl hy)
    · exact Or.inr (Or.inr hv)
  have hFxy : Face.cons x (Face.pr y v) ≤ Face.pr x y := by
    intro a ha; rcases ha with rfl | rfl
    · exact Or.inl rfl
    · exact Or.inr (Or.inl rfl)
  have hFxv : Face.cons x (Face.pr y v) ≤ Face.pr x v := by
    intro a ha; rcases ha with rfl | rfl
    · exact Or.inl rfl
    · exact Or.inr (Or.inr rfl)
  have hFyv : Face.cons x (Face.pr y v) ≤ Face.pr y v := by
    intro a ha; rcases ha with rfl | rfl
    · exact Or.inr (Or.inl rfl)
    · exact Or.inr (Or.inr rfl)
  have hnoroot : ∀ K : Face V, Face.cons x (Face.pr y v) ≤ K → f K ≠ some root := by
    intro K hK hfK
    obtain ⟨a, ha, haV⟩ := (support_role hf hcof hfK (.V (!j))).mpr trivial
    rcases hFroles a (hK a ha) with h | h | h
    · exact absurd (vtx_unique haV h) (by simp)
    · exact absurd (vtx_unique haV h) (by simp)
    · exact hinj (Role.V.inj (vtx_unique haV h))
  have hFnd : ¬ PDom f (Face.cons x (Face.pr y v)) := by
    rintro ⟨p, hp⟩
    have h1 : p ≤ (Rel (.out i) : Pt T) := hf.pe1 hFxy hp hxy
    have h2 : p ≤ (Tl i j t : Pt T) := hf.pe1 hFxv hp hxv
    have hproot : p = root := by
      rcases (rootCover_Rel (.out i)).2 p h1 with h | h
      · exact h
      · rcases (rootCover_Tl i j t).2 p h2 with h' | h'
        · exact h'
        · exact absurd (h.symm.trans h') (by simp)
    exact hnoroot _ (Poset.le_refl _) (by rw [hp, hproot])
  -- a `d_{H_i}`- or `g_{H_i}`-labelled subface would have to be the singleton `{x}`
  have hnoshd : ∀ K : Face V, Face.cons x (Face.pr y v) ≤ K → f K ≠ some (shd (.H i)) := by
    intro K hK hfK
    have hall : ∀ a, K.carrier a → a = x := by
      intro a ha
      obtain ⟨Z, hZ, hle⟩ := vertices_of_value hf hcof hfK ha
      have hZi : Z = Role.H i := (Pt.rolesAbove_shd (.H i) Z).mp hle
      rcases hmem a (hK a ha) with rfl | rfl | rfl
      · rfl
      · exact absurd (Role.H.inj ((vtx_unique hy hZ).trans hZi)) hini
      · exact absurd ((vtx_unique hv hZ).trans hZi) (by simp)
    rw [face_eq_pt hall, hx'] at hfK
    exact absurd (Option.some.inj hfK) (by simp)
  have hnogrd : ∀ K : Face V, Face.cons x (Face.pr y v) ≤ K → f K ≠ some (grd (.H i)) := by
    intro K hK hfK
    have hall : ∀ a, K.carrier a → a = x := by
      intro a ha
      obtain ⟨Z, hZ, hle⟩ := vertices_of_value hf hcof hfK ha
      have hZi : Z = Role.H i := (Pt.rolesAbove_grd (.H i) Z).mp hle
      rcases hmem a (hK a ha) with rfl | rfl | rfl
      · rfl
      · exact absurd (Role.H.inj ((vtx_unique hy hZ).trans hZi)) hini
      · exact absurd ((vtx_unique hv hZ).trans hZi) (by simp)
    rw [face_eq_pt hall, hx'] at hfK
    exact absurd (Option.some.inj hfK) (by simp)
  -- a `G^H`-labelled subface would have to be the pair `{y,v}`, forcing compatibility
  have hnoG : ∀ K : Face V, Face.cons x (Face.pr y v) ≤ K →
      ∀ q, f K = some q → ¬ GH cw ce i j t q := by
    intro K hK q hfK hG
    obtain ⟨t'', rfl, ht''⟩ := hG
    have hsub : ∀ a, K.carrier a → (a = y ∨ a = v) := by
      intro a ha
      obtain ⟨Z, hZ, hle⟩ := vertices_of_value hf hcof hfK ha
      have hZi : Z = Role.H (!i) ∨ Z = Role.V j := (Pt.rolesAbove_Tl (!i) j t'' Z).mp hle
      rcases hmem a (hK a ha) with rfl | rfl | rfl
      · rcases hZi with h' | h'
        · exact absurd (Role.H.inj ((vtx_unique hx hZ).trans h')) (fun e => hini e.symm)
        · exact absurd ((vtx_unique hx hZ).trans h') (by simp)
      · exact Or.inl rfl
      · exact Or.inr rfl
    have hyK : K.carrier y := by
      obtain ⟨a, ha, haZ⟩ := (support_role hf hcof hfK (.H (!i))).mpr (by simp [le_def, ple])
      rcases hsub a ha with rfl | rfl
      · exact ha
      · exact absurd (vtx_unique haZ hv) (by simp)
    have hvK : K.carrier v := by
      obtain ⟨a, ha, haZ⟩ := (support_role hf hcof hfK (.V j)).mpr (by simp [le_def, ple])
      rcases hsub a ha with rfl | rfl
      · exact absurd (vtx_unique haZ hy) (by simp)
      · exact ha
    rw [face_eq_pr hsub hyK hvK, hyv] at hfK
    have htt : t' = t'' := by
      have h : (Tl (!i) j t' : Pt T) = Tl (!i) j t'' := Option.some.inj hfK
      first
        | injection h
        | (injection h with h1 h2 h3; exact h3)
    exact hbad (by rw [htt]; exact ht'')
  have hclean : ∀ q, coneImg f (Face.cons x (Face.pr y v)) q →
      (q ≠ root ∧ q ≠ shd (.H i) ∧ q ≠ grd (.H i) ∧ ¬ GH cw ce i j t q) := by
    rintro q ⟨K, hK, hfK⟩
    exact ⟨fun h => hnoroot K hK (by rw [hfK, h]),
           fun h => hnoshd K hK (by rw [hfK, h]),
           fun h => hnogrd K hK (by rw [hfK, h]),
           hnoG K hK q hfK⟩
  refine hz (Face.cons x (Face.pr y v)) hFnd
    ⟨cUH cw ce i j t, cVH cw ce i j t,
     Or.inr (Or.inr (Or.inr (Or.inl ⟨i, j, t, rfl, rfl⟩))), minSet_antichain _, ?_, ?_, ?_⟩
  · intro q hq
    obtain ⟨hqr, hqs, hqg, hqG⟩ := hclean q hq.1
    by_cases hqT : q = Tl i j t
    · exact Or.inr ((cVH_iff i j t q).mpr ⟨hqr, by
        rintro (h | h | h | h)
        · exact absurd (hqT.symm.trans h) (by simp)
        · exact hqs h
        · exact hqg h
        · exact hqG h⟩)
    · exact Or.inl ((cUH_iff i j t q).mpr ⟨hqr, by
        rintro (h | h | h | h)
        · exact hqT h
        · exact hqs h
        · exact hqg h
        · exact hqG h⟩)
  · refine ⟨Rel (.out i), ⟨⟨Face.pr x y, hFxy, hxy⟩, ?_⟩, ?_, ?_⟩
    · intro r hr hrle
      obtain ⟨K, hK, hfK⟩ := hr
      rcases (rootCover_Rel (.out i)).2 r hrle with h | h
      · exact absurd (show f K = some (root : Pt T) by rw [hfK, h]) (hnoroot K hK)
      · exact h
    · refine (cUH_iff i j t _).mpr ⟨by simp, ?_⟩
      rintro (h | h | h | ⟨t'', h, -⟩) <;> simp_all
    · exact fun h => ((cVH_iff i j t _).mp h).2 (Or.inl rfl)
  · refine ⟨Tl i j t, ⟨⟨Face.pr x v, hFxv, hxv⟩, ?_⟩, ?_, ?_⟩
    · intro r hr hrle
      obtain ⟨K, hK, hfK⟩ := hr
      rcases (rootCover_Tl i j t).2 r hrle with h | h
      · exact absurd (show f K = some (root : Pt T) by rw [hfK, h]) (hnoroot K hK)
      · exact h
    · refine (cVH_iff i j t _).mpr ⟨by simp, ?_⟩
      rintro (h | h | h | h)
      · exact absurd h (by simp)
      · exact absurd h (by simp)
      · exact absurd h (by simp)
      · exact GH_not_Tl_self i j t h
    · exact fun h => ((cUH_iff i j t _).mp h).2 (Or.inl rfl)

/-- **Lemma 8.4** (Vertical compatibility). -/
theorem compat_V (hf : IsPEM f) (hcof : Cofinal f) (hz : ZCDC f (DW cw ce cs cn))
    (i j : Bool) {x v u : V} {t t' : T}
    (hx : IsVtx f x (.H i)) (hv : IsVtx f v (.V j)) (hu : IsVtx f u (.V (!j)))
    (hvu : f (Face.pr v u) = some (Sel (.out j)))
    (hxv : f (Face.pr x v) = some (Tl i j t))
    (hxu : f (Face.pr x u) = some (Tl i (!j) t')) :
    cn t = cs t' := by
  by_contra hbad
  have hini : (!i) ≠ i := bool_not_ne i
  have hinj : (!j) ≠ j := bool_not_ne j
  have hv' : f (Face.pt v) = some (rol (.V j)) := hv
  have hmem : ∀ a, (Face.cons x (Face.pr v u)).carrier a → (a = x ∨ a = v ∨ a = u) :=
    fun a h => h
  have hFroles : ∀ a, (Face.cons x (Face.pr v u)).carrier a →
      (IsVtx f a (.H i) ∨ IsVtx f a (.V j) ∨ IsVtx f a (.V (!j))) := by
    intro a ha
    rcases ha with rfl | rfl | rfl
    · exact Or.inl hx
    · exact Or.inr (Or.inl hv)
    · exact Or.inr (Or.inr hu)
  have hFvu : Face.cons x (Face.pr v u) ≤ Face.pr v u := by
    intro a ha; rcases ha with rfl | rfl
    · exact Or.inr (Or.inl rfl)
    · exact Or.inr (Or.inr rfl)
  have hFxv : Face.cons x (Face.pr v u) ≤ Face.pr x v := by
    intro a ha; rcases ha with rfl | rfl
    · exact Or.inl rfl
    · exact Or.inr (Or.inl rfl)
  have hFxu : Face.cons x (Face.pr v u) ≤ Face.pr x u := by
    intro a ha; rcases ha with rfl | rfl
    · exact Or.inl rfl
    · exact Or.inr (Or.inr rfl)
  have hnoroot : ∀ K : Face V, Face.cons x (Face.pr v u) ≤ K → f K ≠ some root := by
    intro K hK hfK
    obtain ⟨a, ha, haH⟩ := (support_role hf hcof hfK (.H (!i))).mpr trivial
    rcases hFroles a (hK a ha) with h | h | h
    · exact hini (Role.H.inj (vtx_unique haH h))
    · exact absurd (vtx_unique haH h) (by simp)
    · exact absurd (vtx_unique haH h) (by simp)
  have hFnd : ¬ PDom f (Face.cons x (Face.pr v u)) := by
    rintro ⟨p, hp⟩
    have h1 : p ≤ (Sel (.out j) : Pt T) := hf.pe1 hFvu hp hvu
    have h2 : p ≤ (Tl i j t : Pt T) := hf.pe1 hFxv hp hxv
    have hproot : p = root := by
      rcases (rootCover_Sel (.out j)).2 p h1 with h | h
      · exact h
      · rcases (rootCover_Tl i j t).2 p h2 with h' | h'
        · exact h'
        · exact absurd (h.symm.trans h') (by simp)
    exact hnoroot _ (Poset.le_refl _) (by rw [hp, hproot])
  have hnoshd : ∀ K : Face V, Face.cons x (Face.pr v u) ≤ K → f K ≠ some (shd (.V j)) := by
    intro K hK hfK
    have hall : ∀ a, K.carrier a → a = v := by
      intro a ha
      obtain ⟨Z, hZ, hle⟩ := vertices_of_value hf hcof hfK ha
      have hZj : Z = Role.V j := (Pt.rolesAbove_shd (.V j) Z).mp hle
      rcases hmem a (hK a ha) with rfl | rfl | rfl
      · exact absurd ((vtx_unique hx hZ).trans hZj) (by simp)
      · rfl
      · exact absurd (Role.V.inj ((vtx_unique hu hZ).trans hZj)) hinj
    rw [face_eq_pt hall, hv'] at hfK
    exact absurd (Option.some.inj hfK) (by simp)
  have hnogrd : ∀ K : Face V, Face.cons x (Face.pr v u) ≤ K → f K ≠ some (grd (.V j)) := by
    intro K hK hfK
    have hall : ∀ a, K.carrier a → a = v := by
      intro a ha
      obtain ⟨Z, hZ, hle⟩ := vertices_of_value hf hcof hfK ha
      have hZj : Z = Role.V j := (Pt.rolesAbove_grd (.V j) Z).mp hle
      rcases hmem a (hK a ha) with rfl | rfl | rfl
      · exact absurd ((vtx_unique hx hZ).trans hZj) (by simp)
      · rfl
      · exact absurd (Role.V.inj ((vtx_unique hu hZ).trans hZj)) hinj
    rw [face_eq_pt hall, hv'] at hfK
    exact absurd (Option.some.inj hfK) (by simp)
  have hnoG : ∀ K : Face V, Face.cons x (Face.pr v u) ≤ K →
      ∀ q, f K = some q → ¬ GV cs cn i j t q := by
    intro K hK q hfK hG
    obtain ⟨t'', rfl, ht''⟩ := hG
    have hsub : ∀ a, K.carrier a → (a = x ∨ a = u) := by
      intro a ha
      obtain ⟨Z, hZ, hle⟩ := vertices_of_value hf hcof hfK ha
      have hZi : Z = Role.H i ∨ Z = Role.V (!j) := (Pt.rolesAbove_Tl i (!j) t'' Z).mp hle
      rcases hmem a (hK a ha) with rfl | rfl | rfl
      · exact Or.inl rfl
      · rcases hZi with h' | h'
        · exact absurd ((vtx_unique hv hZ).trans h') (by simp)
        · exact absurd (Role.V.inj ((vtx_unique hv hZ).trans h')) (fun e => hinj e.symm)
      · exact Or.inr rfl
    have hxK : K.carrier x := by
      obtain ⟨a, ha, haZ⟩ := (support_role hf hcof hfK (.H i)).mpr (by simp [le_def, ple])
      rcases hsub a ha with rfl | rfl
      · exact ha
      · exact absurd (vtx_unique haZ hu) (by simp)
    have huK : K.carrier u := by
      obtain ⟨a, ha, haZ⟩ := (support_role hf hcof hfK (.V (!j))).mpr (by simp [le_def, ple])
      rcases hsub a ha with rfl | rfl
      · exact absurd (vtx_unique haZ hx) (by simp)
      · exact ha
    rw [face_eq_pr hsub hxK huK, hxu] at hfK
    have htt : t' = t'' := by
      have h : (Tl i (!j) t' : Pt T) = Tl i (!j) t'' := Option.some.inj hfK
      first
        | injection h
        | (injection h with h1 h2 h3; exact h3)
    exact hbad (by rw [htt]; exact ht'')
  have hclean : ∀ q, coneImg f (Face.cons x (Face.pr v u)) q →
      (q ≠ root ∧ q ≠ shd (.V j) ∧ q ≠ grd (.V j) ∧ ¬ GV cs cn i j t q) := by
    rintro q ⟨K, hK, hfK⟩
    exact ⟨fun h => hnoroot K hK (by rw [hfK, h]),
           fun h => hnoshd K hK (by rw [hfK, h]),
           fun h => hnogrd K hK (by rw [hfK, h]),
           hnoG K hK q hfK⟩
  refine hz (Face.cons x (Face.pr v u)) hFnd
    ⟨cUV cs cn i j t, cVV cs cn i j t,
     Or.inr (Or.inr (Or.inr (Or.inr ⟨i, j, t, rfl, rfl⟩))), minSet_antichain _, ?_, ?_, ?_⟩
  · intro q hq
    obtain ⟨hqr, hqs, hqg, hqG⟩ := hclean q hq.1
    by_cases hqT : q = Tl i j t
    · exact Or.inr ((cVV_iff i j t q).mpr ⟨hqr, by
        rintro (h | h | h | h)
        · exact absurd (hqT.symm.trans h) (by simp)
        · exact hqs h
        · exact hqg h
        · exact hqG h⟩)
    · exact Or.inl ((cUV_iff i j t q).mpr ⟨hqr, by
        rintro (h | h | h | h)
        · exact hqT h
        · exact hqs h
        · exact hqg h
        · exact hqG h⟩)
  · refine ⟨Sel (.out j), ⟨⟨Face.pr v u, hFvu, hvu⟩, ?_⟩, ?_, ?_⟩
    · intro r hr hrle
      obtain ⟨K, hK, hfK⟩ := hr
      rcases (rootCover_Sel (.out j)).2 r hrle with h | h
      · exact absurd (show f K = some (root : Pt T) by rw [hfK, h]) (hnoroot K hK)
      · exact h
    · refine (cUV_iff i j t _).mpr ⟨by simp, ?_⟩
      rintro (h | h | h | ⟨t'', h, -⟩) <;> simp_all
    · exact fun h => ((cVV_iff i j t _).mp h).2 (Or.inl rfl)
  · refine ⟨Tl i j t, ⟨⟨Face.pr x v, hFxv, hxv⟩, ?_⟩, ?_, ?_⟩
    · intro r hr hrle
      obtain ⟨K, hK, hfK⟩ := hr
      rcases (rootCover_Tl i j t).2 r hrle with h | h
      · exact absurd (show f K = some (root : Pt T) by rw [hfK, h]) (hnoroot K hK)
      · exact h
    · refine (cVV_iff i j t _).mpr ⟨by simp, ?_⟩
      rintro (h | h | h | h)
      · exact absurd h (by simp)
      · exact absurd h (by simp)
      · exact absurd h (by simp)
      · exact GV_not_Tl_self i j t h
    · exact fun h => ((cUV_iff i j t _).mp h).2 (Or.inl rfl)

/-! ## §8.3–8.5  Guard cycles and the resulting torus -/

/-- Alternating phase: `altB n b` is `b` for even `n` and `!b` for odd `n`. -/
def altB : Nat → Bool → Bool
  | 0,     b => b
  | n + 1, b => !(altB n b)

theorem altB_add (m n : Nat) (b : Bool) : altB (m + n) b = altB n (altB m b) := by
  induction n with
  | zero => rfl
  | succ k ih =>
    have h1 : altB (m + (k + 1)) b = !(altB (m + k) b) := rfl
    have h2 : altB (k + 1) (altB m b) = !(altB k (altB m b)) := rfl
    rw [h1, h2, ih]

theorem altB_not (n : Nat) (b : Bool) : altB n (!b) = !(altB n b) := by
  induction n with
  | zero => rfl
  | succ k ih =>
    have h1 : altB (k + 1) (!b) = !(altB k (!b)) := rfl
    have h2 : altB (k + 1) b = !(altB k b) := rfl
    rw [h1, h2, ih]

theorem altB_invol (n : Nat) (b : Bool) : altB n (altB n b) = b := by
  induction n with
  | zero => rfl
  | succ k ih =>
    have h1 : altB (k + 1) (altB (k + 1) b) = !(altB k (!(altB k b))) := rfl
    rw [h1, altB_not, ih]
    simp

/-- **Proposition 8.5** (Soundness).  If `E(P_W, D_W)` is witnessed by `f`, then `W` has a
finite torus tiling. -/
theorem prop_8_5 (hf : IsPEM f) (hcof : Cofinal f) (hon : POnto f)
    (hz : ZCDC f (DW cw ce cs cn)) : HasTorusTiling cw ce cs cn := by
  -- horizontal successor, from seriality
  have hstepH : ∀ a : V, ∃ b : V, ∀ i : Bool,
      IsVtx f a (.H i) → (IsVtx f b (.H (!i)) ∧ f (Face.pr a b) = some (Rel (.out i))) := by
    intro a
    by_cases h0 : IsVtx f a (.H false)
    · obtain ⟨GY, hGY⟩ := hon (grd (.H true))
      obtain ⟨y, hy, hfy⟩ := seriality_H hf hcof hz false hGY h0
      refine ⟨y, ?_⟩
      intro i
      cases i
      · intro hi; exact ⟨guard_vertices hf hcof hGY hy, hfy⟩
      · intro hi; exact absurd (vtx_unique h0 hi) (by simp)
    · by_cases h1 : IsVtx f a (.H true)
      · obtain ⟨GY, hGY⟩ := hon (grd (.H false))
        obtain ⟨y, hy, hfy⟩ := seriality_H hf hcof hz true hGY h1
        refine ⟨y, ?_⟩
        intro i
        cases i
        · intro hi; exact absurd hi h0
        · intro hi; exact ⟨guard_vertices hf hcof hGY hy, hfy⟩
      · obtain ⟨G, hG⟩ := hon (grd (.H false))
        obtain ⟨a0, ha0⟩ := G.ne
        refine ⟨a0, ?_⟩
        intro i
        cases i
        · intro hi; exact absurd hi h0
        · intro hi; exact absurd hi h1
  -- vertical successor
  have hstepV : ∀ a : V, ∃ b : V, ∀ j : Bool,
      IsVtx f a (.V j) → (IsVtx f b (.V (!j)) ∧ f (Face.pr a b) = some (Sel (.out j))) := by
    intro a
    by_cases h0 : IsVtx f a (.V false)
    · obtain ⟨GY, hGY⟩ := hon (grd (.V true))
      obtain ⟨y, hy, hfy⟩ := seriality_V hf hcof hz false hGY h0
      refine ⟨y, ?_⟩
      intro j
      cases j
      · intro hj; exact ⟨guard_vertices hf hcof hGY hy, hfy⟩
      · intro hj; exact absurd (vtx_unique h0 hj) (by simp)
    · by_cases h1 : IsVtx f a (.V true)
      · obtain ⟨GY, hGY⟩ := hon (grd (.V false))
        obtain ⟨y, hy, hfy⟩ := seriality_V hf hcof hz true hGY h1
        refine ⟨y, ?_⟩
        intro j
        cases j
        · intro hj; exact absurd hj h0
        · intro hj; exact ⟨guard_vertices hf hcof hGY hy, hfy⟩
      · obtain ⟨G, hG⟩ := hon (grd (.V false))
        obtain ⟨a0, ha0⟩ := G.ne
        refine ⟨a0, ?_⟩
        intro j
        cases j
        · intro hj; exact absurd hj h0
        · intro hj; exact absurd hj h1
  obtain ⟨sh, hsh⟩ : ∃ sh : V → V, ∀ a i, IsVtx f a (.H i) →
      (IsVtx f (sh a) (.H (!i)) ∧ f (Face.pr a (sh a)) = some (Rel (.out i))) :=
    ⟨fun a => Classical.choose (hstepH a), fun a => Classical.choose_spec (hstepH a)⟩
  obtain ⟨sv, hsv⟩ : ∃ sv : V → V, ∀ a j, IsVtx f a (.V j) →
      (IsVtx f (sv a) (.V (!j)) ∧ f (Face.pr a (sv a)) = some (Sel (.out j))) :=
    ⟨fun a => Classical.choose (hstepV a), fun a => Classical.choose_spec (hstepV a)⟩
  -- starting vertices
  obtain ⟨G0, hG0⟩ := hon (grd (.H false))
  obtain ⟨x0, hx0⟩ := G0.ne
  have hx0v : IsVtx f x0 (.H false) := guard_vertices hf hcof hG0 hx0
  obtain ⟨G0', hG0'⟩ := hon (grd (.V false))
  obtain ⟨v0, hv0⟩ := G0'.ne
  have hv0v : IsVtx f v0 (.V false) := guard_vertices hf hcof hG0' hv0
  -- forward invariance
  have hQhinv : ∀ a, (IsVtx f a (.H false) ∨ IsVtx f a (.H true)) →
      (IsVtx f (sh a) (.H false) ∨ IsVtx f (sh a) (.H true)) := by
    rintro a (h | h)
    · exact Or.inr (hsh a false h).1
    · exact Or.inl (hsh a true h).1
  have hQvinv : ∀ a, (IsVtx f a (.V false) ∨ IsVtx f a (.V true)) →
      (IsVtx f (sv a) (.V false) ∨ IsVtx f (sv a) (.V true)) := by
    rintro a (h | h)
    · exact Or.inr (hsv a false h).1
    · exact Or.inl (hsv a true h).1
  -- periodic points
  obtain ⟨xh, kh, hkh, hxhQ, hxhper⟩ :=
    exists_periodic_in sh (fun a => IsVtx f a (.H false) ∨ IsVtx f a (.H true)) hQhinv x0
      (Or.inl hx0v)
  obtain ⟨xv, kv, hkv, hxvQ, hxvper⟩ :=
    exists_periodic_in sv (fun a => IsVtx f a (.V false) ∨ IsVtx f a (.V true)) hQvinv v0
      (Or.inl hv0v)
  obtain ⟨b0, hb0⟩ : ∃ b, IsVtx f xh (.H b) := by
    rcases hxhQ with h | h
    · exact ⟨false, h⟩
    · exact ⟨true, h⟩
  obtain ⟨c0, hc0⟩ : ∃ c, IsVtx f xv (.V c) := by
    rcases hxvQ with h | h
    · exact ⟨false, h⟩
    · exact ⟨true, h⟩
  -- the two cyclic sequences
  have hph : ∀ n, IsVtx f (iter sh n xh) (.H (altB n b0)) := by
    intro n
    induction n with
    | zero => exact hb0
    | succ k ih => exact (hsh _ _ ih).1
  have hpv : ∀ n, IsVtx f (iter sv n xv) (.V (altB n c0)) := by
    intro n
    induction n with
    | zero => exact hc0
    | succ k ih => exact (hsv _ _ ih).1
  have hedgeH : ∀ n, f (Face.pr (iter sh n xh) (iter sh (n + 1) xh))
      = some (Rel (.out (altB n b0))) := fun n => (hsh _ _ (hph n)).2
  have hedgeV : ∀ n, f (Face.pr (iter sv n xv) (iter sv (n + 1) xv))
      = some (Sel (.out (altB n c0))) := fun n => (hsv _ _ (hpv n)).2
  -- periods (doubled, so that the phase also returns)
  have hperH : ∀ n, iter sh (n + (kh + kh)) xh = iter sh n xh := by
    intro n
    have h1 : iter sh (kh + kh) xh = xh := by
      rw [iter_add, hxhper]; exact hxhper
    rw [Nat.add_comm n (kh + kh), iter_add, h1]
  have hperV : ∀ n, iter sv (n + (kv + kv)) xv = iter sv n xv := by
    intro n
    have h1 : iter sv (kv + kv) xv = xv := by
      rw [iter_add, hxvper]; exact hxvper
    rw [Nat.add_comm n (kv + kv), iter_add, h1]
  have haltH : ∀ n, altB (n + (kh + kh)) b0 = altB n b0 := by
    intro n
    rw [altB_add, altB_add]
    exact altB_invol kh _
  have haltV : ∀ n, altB (n + (kv + kv)) c0 = altB n c0 := by
    intro n
    rw [altB_add, altB_add]
    exact altB_invol kv _
  -- the tile assigned to each cell of the product of the two cycles
  obtain ⟨tl, htl⟩ : ∃ tl : Nat → Nat → T, ∀ a b,
      f (Face.pr (iter sh a xh) (iter sv b xv))
        = some (Tl (altB a b0) (altB b c0) (tl a b)) := by
    have hex : ∀ a b, ∃ t : T, f (Face.pr (iter sh a xh) (iter sv b xv))
        = some (Tl (altB a b0) (altB b c0) t) := fun a b =>
      pair_colour_HV hf hcof hz (hph a) (hpv b)
    exact ⟨fun a b => Classical.choose (hex a b), fun a b => Classical.choose_spec (hex a b)⟩
  refine ⟨{ m := kh + kh, l := kv + kv, hm := by omega, hl := by omega, tile := tl,
            perH := ?_, perV := ?_, matchH := ?_, matchV := ?_ }⟩
  · intro a b
    have h1 := htl (a + (kh + kh)) b
    rw [hperH a, haltH a, htl a b] at h1
    exact ((Pt.Tl.inj (Option.some.inj h1)).2.2).symm
  · intro a b
    have h1 := htl a (b + (kv + kv))
    rw [hperV b, haltV b, htl a b] at h1
    exact ((Pt.Tl.inj (Option.some.inj h1)).2.2).symm
  · intro a b
    exact compat_H hf hcof hz (altB a b0) (altB b c0) (hph a) (hph (a + 1)) (hpv b)
      (hedgeH a) (htl a b) (htl (a + 1) b)
  · intro a b
    exact compat_V hf hcof hz (altB a b0) (altB b c0) (hph a) (hpv b) (hpv (b + 1))
      (hedgeV b) (htl a b) (htl a (b + 1))

end Soundness

end MU
