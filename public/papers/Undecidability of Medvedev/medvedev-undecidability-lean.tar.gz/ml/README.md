# A Lean 4 formalisation of the combinatorial core of *Notes on undecidability of Medvedev's logic*

This development machine-checks the mathematical content that the note itself proves,
and isolates — as explicit hypotheses, never as `axiom`s — the two results it cites.

* **Lean 4.33.0**, no Mathlib, no Batteries: the whole thing is written against Lean's
  `Init` only. (Mathlib's build cache was unreachable in the build environment, and
  building Mathlib from source was not viable there; the upside is a 4,300-line
  self-contained development that compiles from scratch in **under 8 seconds**.)
* **Zero `sorry`s, zero custom axioms.** Every headline theorem depends on exactly
  `propext`, `Classical.choice`, `Quot.sound` — Lean's three standard axioms.

```
lake build          # ~8s from scratch
```

## What is proved

| Paper | Lean | File |
|---|---|---|
| Def. 3.1 (partial Esakia morphism, finite form) | `IsPEM` | `Frames.lean` |
| (PE4)/(PE5) are automatic in the finite case | `pe4_automatic`, `pe5_automatic` | `Frames.lean` |
| Def. 3.2 (ZCDC), `𝒟_{U,V}`, `𝒟_D` | `DUV`, `DD`, `ZCDC` | `Frames.lean` |
| Prop. 5.1 (i), (ii), (iv) — face recurrence | `IsPEM.coneImg_isUpset`, `prop51_ii`, `prop51_iv` | `Frames.lean` |
| §2, the criterion `E(P,D)` | `EPD` | `Frames.lean` |
| **Lemma 4.1** (principal-cone normalization) | `lemma_4_1` | `Normalization.lean` |
| Thm 3.3 ⟹ Cor. 4.2 | `upsetWitness_iff_epd` | `Normalization.lean` |
| §6 Wang tiles, torus tilings | `TorusTiling`, `HasTorusTiling` | `PosetW.lean` |
| §7.1 the poset `P_W` | `Pt`, `Pt.ple`, `Pt.instPoset` | `PosetW.lean` |
| §7.2–7.4 the domain `D_W` | `Desig`, `sU`/`sV`, `cUH`/`cVH`/`cUV`/`cVV`, `DW` | `Domain.lean` |
| **Lemma 7.1** (legitimacy of the domain) | `lemma_7_1` | `Domain.lean` |
| **Lemma 8.1** (support-role) | `support_role` | `Soundness.lean` |
| **Lemma 8.2** (pair filling) | `pair_filling` | `Soundness.lean` |
| **Lemma 8.3** (seriality) | `seriality_H`, `seriality_V` | `Soundness.lean` |
| **Lemma 8.4** (compatibility) | `compat_H`, `compat_V` | `Soundness.lean` |
| **Prop. 8.5** (Soundness) | `prop_8_5` | `Soundness.lean` |
| §9.1 calibrated supports (S1)–(S7) | `Sg` | `Completeness.lean` |
| **Lemma 9.1** (calibration) | `calibration` | `Completeness.lean` |
| **Lemma 9.2** (support realization) | `support_realization` | `Completeness.lean` |
| **Lemma 9.3** (outside-point principle) | `outside_minimal` | `Core.lean` |
| §9.2 global ZCDC verification | `zcdc_holds` | `Completeness.lean` |
| **Prop. 9.4** (Completeness) | `prop_9_4` | `Completeness.lean` |
| **Lemma 6.1** (surjective range) | `lemma_6_1` | `Reduction.lean` |
| **Thm 10.1** (tiling equivalence) | `theorem_10_1` | `Reduction.lean` |

## The two cited inputs

They are **hypotheses**, so every theorem here is unconditionally true of any pair
`(NotML, hcrit)` satisfying them.

1. `IsCanonicalCriterion NotML` (`Reduction.lean`) is **Theorem 3.3** of the note
   (Bezhanishvili–Bezhanishvili's canonical-formula criterion), specialised to Medvedev
   frames. `NotML P D` reads "`ρ(Up(P), D) ∉ ML`". Note that **Lemma 4.1 is proved
   here**, so the hypothesis is stated in its faithful Theorem-3.3 shape (with a closed
   upset `Y`), and `corollary_4_2` derives the normalized form.

2. The undecidability of the periodic domino problem (Gurevich–Koryakov) is **not used
   at all** in this development. It enters only in the final computability step, which is
   not formalised (see below).

## What is *not* formalised

* The syntax of intuitionistic formulas, the Heyting algebras `Up(M_n)`, and Medvedev's
  logic itself. `NotML` is an opaque predicate. Consequently "`ρ ∉ ML`" is exactly as
  meaningful as the hypothesis `IsCanonicalCriterion` makes it.
* Any computability theory. §11 of the note (co-r.e.-ness of ML, non-r.e.-ness, absence of
  an r.e. axiomatization, Cor. 11.1) and the many-one reduction of Cor. 10.2 need a formal
  model of computation; `theorem_10_1` gives the mathematical equivalence that the
  reduction is built on, and stops there.
* Prop. 4.3 (the structural-completeness route) and Prop. 5.1(iii): neither is used on the
  path to the main theorem.

## Faithfulness note

The Medvedev frame is realised as `Face V` — the nonempty subsets of a finite nonempty
carrier `V`, ordered by reverse inclusion — rather than `M_n = (P*([n]), ⊇)`. Any bijection
`V ≃ Fin n` induces an order isomorphism `M_V ≅ M_n`, and every notion in the development
(`IsPEM`, `Cofinal`, `POnto`, `ZCDC`, `EPD`) is defined purely order-theoretically, so
nothing is lost; the transfer along such a bijection is not itself formalised.

## Non-vacuity

`Sanity.lean` checks both failure modes of a vacuous formalisation:

* `sanity_epd` — a one-tile set with matching colours *does* satisfy `E(P_W, D_W)`, so the
  bundle "partial Esakia morphism + onto + cofinal + `ZCDC(D_W)`" is satisfiable and
  Soundness is not vacuous;
* `sanity_not_epd` — a one-tile set with `e ≠ w` does *not*, so `ZCDC(D_W)` genuinely
  constrains and Completeness is not trivial.

## Layout

```
Core.lean           finite types, pigeonhole, posets, minimal/maximal points,
                    outside-point principle (Lemma 9.3), subtype finiteness
Frames.lean         Medvedev frames, partial Esakia morphisms, ZCDC, E(P,D), Prop. 5.1
Normalization.lean  §4: Lemma 4.1 and the Thm 3.3 ⟺ Cor 4.2 equivalence
PosetW.lean         §6 torus tilings; §7.1 the poset P_W and its finiteness
Domain.lean         §7.2–7.4 the cuts, their explicit descriptions, Lemma 7.1
Soundness.lean      §8: Lemmas 8.1–8.4, guard cycles, Prop. 8.5
Completeness.lean   §9: supports (S1)–(S7), Lemmas 9.1/9.2, §9.2 ZCDC, Prop. 9.4
Reduction.lean      §6 Lemma 6.1; §10 Theorem 10.1; the cited criterion as a hypothesis
Sanity.lean         non-vacuity checks
```

## Axiom audit

```lean
import MedvedevUndecidability
#print axioms MU.prop_8_5      -- [propext, Classical.choice, Quot.sound]
#print axioms MU.prop_9_4      -- [propext, Classical.choice, Quot.sound]
#print axioms MU.lemma_4_1     -- [propext, Classical.choice, Quot.sound]
#print axioms MU.theorem_10_1  -- [propext, Classical.choice, Quot.sound]
#print axioms MU.lemma_6_1     -- does not depend on any axioms
```
